#include "kdeversion.h"
#include "ktreewidgetsearchline.h"
#if KDE_IS_VERSION(5, 0, 0)
#include "ktreewidgetsearchlinewidget.h"
#endif
