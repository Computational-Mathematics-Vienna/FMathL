/* DynGenPar: Dynamic Generalized Parser - Naproche parser test program
   Copyright (C) 2009-2011 Kevin Kofler <kevin.kofler@chello.at>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#define DYNGENPAR_INTEGER_CATEGORIES

#include <QCoreApplication>
#include <QTextStream>
#include <QStringList>
#include <cstdio>
#include "naproche.h"
#include "naproche-cats.h"

using namespace DynGenPar;

static QCoreApplication *app;

// printing functions
QStringList categoryNames;

#define OUTPUT_MK_COMMANDS

#ifdef OUTPUT_MK_COMMANDS
static QVariant processRule(int ruleid, const QVariantList &args,
                            QTextStream &stream) {
  static int expr_id = 0;
  QVariant result;
  switch (ruleid) {
    case 5:
    case 16 ... 21:
    case 27 ... 33:
    case 60 ... 61:
    case 116:
    case 118:
    case 120:
    case 122:
    case 124:
    case 126:
      result = args.at(0);
      break;

    case 62:
    case 115:
      result = args.at(1);
      break;

    case 34:
    case 36:
    case 38:
    case 40:
    case 42:
    case 44:
    case 46:
    case 128:
    case 130:
    case 132:
      result = (args.at(0).toList() += args.at(1));
      break;

    case 35:
    case 37:
    case 39:
    case 41:
    case 43:
    case 45:
    case 133:
      result = QVariantList();
      break;

    case 47:
    case 129:
    case 131:
      result = (QVariantList() += args.at(0));
      break;

    case 1:
      {
        int i, first = 1;
        stream << "ex = mknaproche(";
        for (i=0; i<args.at(0).toList().size(); i++) {
          stream << QString(first ? "node%1" : ",node%1").arg(args.at(0).toList().at(i).toInt());
          first = 0;
        }
        for (i=0; i<args.at(1).toList().size(); i++) {
          stream << QString(first ? "node%1" : ",node%1").arg(args.at(1).toList().at(i).toInt());
          first = 0;
        }
        for (i=0; i<args.at(2).toList().size(); i++) {
          stream << QString(first ? "node%1" : ",node%1").arg(args.at(2).toList().at(i).toInt());
          first = 0;
        }
        stream << ");\n";
      }
      break;

    case 2:
      {
        int id = ++expr_id, i;
        stream << QString("node%1 = mktheorem(").arg(id);
        for (i=0; i<args.at(1).toList().size(); i++) stream << QString("node%1,").arg(args.at(1).toList().at(i).toInt());
        for (i=0; i<args.at(2).toList().size(); i++) stream << QString("node%1,").arg(args.at(2).toList().at(i).toInt());
        for (i=0; i<args.at(3).toList().size(); i++) stream << QString("node%1,").arg(args.at(3).toList().at(i).toInt());
        stream << QString("node%1);\n").arg(args.at(4).toInt());
        result = id;
      }
      break;

    case 3:
      {
        int id = ++expr_id, i;
        stream << QString("node%1 = mklemma(").arg(id);
        for (i=0; i<args.at(1).toList().size(); i++) stream << QString("node%1,").arg(args.at(1).toList().at(i).toInt());
        for (i=0; i<args.at(2).toList().size(); i++) stream << QString("node%1,").arg(args.at(2).toList().at(i).toInt());
        for (i=0; i<args.at(3).toList().size(); i++) stream << QString("node%1,").arg(args.at(3).toList().at(i).toInt());
        stream << QString("node%1);\n").arg(args.at(4).toInt());
        result = id;
      }
      break;

    case 4:
      {
        int id = ++expr_id, i;
        stream << QString("node%1 = mkproof(").arg(id);
        for (i=0; i<args.at(1).toList().size(); i++) stream << QString(i ? ",node%1" : "node%1").arg(args.at(1).toList().at(i).toInt());
        stream << ");\n";
        result = id;
      }
      break;

    case 6:
      {
        int id = ++expr_id, i;
        stream << QString("node%1 = mkcontradiction(node%2").arg(id).arg(args.at(0).toInt());
        for (i=0; i<args.at(1).toList().size(); i++) stream << QString(",node%1").arg(args.at(1).toList().at(i).toInt());
        if (args.at(2).toBool()) stream << QString(",node%1").arg(args.at(2).toInt());
        stream << ");\n";
        result = id;
      };
      break;

    case 7:
      {
        int id = ++expr_id;
        int sid = ++expr_id;
        stream << QString("node%1 = mkdefinition(node%2,[],labsearch('property'),[],node%3);\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
        stream << QString("node%1 = mksentence(node%2);\n").arg(sid).arg(id);
        result = sid;
      };
      break;

    case 8:
      {
        int id = ++expr_id;
        int sid = ++expr_id;
        switch (args.at(0).toInt()) {
          case ASSUME_THAT:
            stream << QString("node%1 = mkassumption(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case ASSUME_CONTR:
            stream << QString("node%1 = mkassumption(node%2,labsearch('indirect'));\n").arg(id).arg(args.at(1).toInt());
            break;
          case LET:
            stream << QString("node%1 = mklet(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case CONSIDER:
            stream << QString("node%1 = mkconsider(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
        }
        stream << QString("node%1 = mksentence(node%2);\n").arg(sid).arg(id);
        result = sid;
      };
      break;

    case 9:
      {
        int id = ++expr_id;
        int sid = ++expr_id;
        stream << QString("node%1 = mkassumptionclose(node%2);\n").arg(id).arg(args.at(1).toInt());
        stream << QString("node%1 = mksentence(node%2);\n").arg(sid).arg(id);
        result = sid;
      }
      break;

    case 10:
      result = 0;
      break;

    case 11 ... 15:
      {
        int sid = ++expr_id;
        stream << QString("node%1 = mksentence(node%2);\n").arg(sid).arg(args.at(0).toInt());
        result = sid;
      }
      break;

    case 22:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('FORALL',node%2,{node%3});\n").arg(id).arg(args.at(3).toInt()).arg(args.at(1).toInt());
        result = id;
      };
      break;

    case 23:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('EXISTS',node%2,{node%3});\n").arg(id).arg(args.at(3).toInt()).arg(args.at(1).toInt());
        result = id;
      };
      break;

    case 24:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('IMPLIES',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
        result = id;
      };
      break;

    case 25:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('NOT',node%2);\n").arg(id).arg(args.at(1).toInt());
        result = id;
      };
      break;

    case 26:
      {
        int id = ++expr_id;
        switch (args.at(0).toInt()) {
          case THEN:
            stream << QString("node%1 = mkinference(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case HENCE:
            stream << QString("node%1 = mkconclusion(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case RECALL_THAT:
            stream << QString("node%1 = mkrecallthat(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case BUT:
            stream << QString("node%1 = mkbut(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case IN_PARTICULAR:
            stream << QString("node%1 = mkinparticular(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case OBSERVE_THAT:
            stream << QString("node%1 = mkobservethat(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case TOGETHER_WE_HAVE:
            stream << QString("node%1 = mktogetherwehave(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
          case SO:
            stream << QString("node%1 = mkso(node%2);\n").arg(id).arg(args.at(1).toInt());
            break;
        }
        result = id;
      }
      break;

    case 48:
      result = ASSUME_THAT;
      break;

    case 49:
      result = ASSUME_CONTR;
      break;

    case 50:
      result = LET;
      break;

    case 51:
      result = CONSIDER;
      break;

    case 52:
      result = THEN;
      break;

    case 53:
      result = HENCE;
      break;

    case 54:
      result = RECALL_THAT;
      break;

    case 55:
      result = BUT;
      break;

    case 56:
      result = IN_PARTICULAR;
      break;

    case 57:
      result = OBSERVE_THAT;
      break;

    case 58:
      result = TOGETHER_WE_HAVE;
      break;

    case 59:
      result = SO;
      break;

    case 63:
      result = VAR_M;
      break;

    case 64:
      result = VAR_N;
      break;

    case 65:
      result = VAR_T;
      break;

    case 66:
      result = VAR_U;
      break;

    case 67:
      result = VAR_V;
      break;

    case 68:
      result = VAR_W;
      break;

    case 69:
      result = VAR_X;
      break;

    case 70:
      result = VAR_Y;
      break;

    case 71:
      result = VAR_Z;
      break;

    case 72:
      result = CST_EMPTYSET;
      break;

    case 73:
      result = CST_C;
      break;

    case 74:
      result = CST_0;
      break;

    case 75:
      result = CST_1;
      break;

    case 76:
      result = CST_2;
      break;

    case 77:
      result = CST_3;
      break;

    case 78:
      result = CST_4;
      break;

    case 79:
      result = CST_5;
      break;

    case 80:
      result = FUN_F;
      break;

    case 81:
      result = FUN_F2;
      break;

    case 82:
      result = FUN_G;
      break;

    case 83:
      result = FUN_H;
      break;

    case 84:
      result = FUN_STAR;
      break;

    case 85:
      result = FUN_PLUS;
      break;

    case 86:
      result = FUN_CARET;
      break;

    case 87:
      result = FUN_PRIME;
      break;

    case 88:
      result = FUN_SUCC;
      break;

    case 89:
      result = FUN_CUP;
      break;

    case 90:
      result = FUN_CAP;
      break;

    case 91:
      result = REL_EQ;
      break;

    case 92:
      result = REL_NEQ;
      break;

    case 93:
      result = REL_LT;
      break;

    case 94:
      result = REL_GT;
      break;

    case 95:
      result = REL_LEQ;
      break;

    case 96:
      result = REL_GEQ;
      break;

    case 97:
      result = REL_IN;
      break;

    case 98:
      result = REL_SUBSET;
      break;

    case 99:
      result = REL_SUPSET;
      break;

    case 100:
      result = REL_R;
      break;

    case 101:
      result = REL_SMALL_R;
      break;

    case 102:
      result = REL_M;
      break;

    case 103:
      result = REL_ORD;
      break;

    case 104:
      result = REL_TRANS;
      break;

    case 105:
      result = REL_CONTRADICTION;
      break;

    case 106:
      result = QUANT_FORALL;
      break;

    case 107:
      result = QUANT_EXISTS;
      break;

    case 108:
      {
        int id = ++expr_id;
        switch (args.at(0).toInt()) {
          case VAR_M:
            stream << QString("node%1 = var_m;\n").arg(id);
            break;
          case VAR_N:
            stream << QString("node%1 = var_n;\n").arg(id);
            break;
          case VAR_T:
            stream << QString("node%1 = var_t;\n").arg(id);
            break;
          case VAR_U:
            stream << QString("node%1 = var_u;\n").arg(id);
            break;
          case VAR_V:
            stream << QString("node%1 = var_v;\n").arg(id);
            break;
          case VAR_W:
            stream << QString("node%1 = var_w;\n").arg(id);
            break;
          case VAR_X:
            stream << QString("node%1 = var_x;\n").arg(id);
            break;
          case VAR_Y:
            stream << QString("node%1 = var_y;\n").arg(id);
            break;
          case VAR_Z:
            stream << QString("node%1 = var_z;\n").arg(id);
            break;
        }
        result = id;
      }
      break;

    case 109:
      {
        int id = ++expr_id;
        switch (args.at(0).toInt()) {
          case CST_EMPTYSET:
            stream << QString("node%1 = cst_emptyset;\n").arg(id);
            break;
          case CST_C:
            stream << QString("node%1 = cst_c;\n").arg(id);
            break;
          case CST_0:
            stream << QString("node%1 = cst_0;\n").arg(id);
            break;
          case CST_1:
            stream << QString("node%1 = cst_1;\n").arg(id);
            break;
          case CST_2:
            stream << QString("node%1 = cst_2;\n").arg(id);
            break;
          case CST_3:
            stream << QString("node%1 = cst_3;\n").arg(id);
            break;
          case CST_4:
            stream << QString("node%1 = cst_4;\n").arg(id);
            break;
          case CST_5:
            stream << QString("node%1 = cst_5;\n").arg(id);
            break;
        }
        result = id;
      }
      break;

    case 110:
      {
        int id = ++expr_id, i;
        switch (args.at(0).toInt()) {
          case FUN_F:
            stream << QString("node%1 = mkexp('OF',{fun_f").arg(id);
            break;
          case FUN_F2:
            stream << QString("node%1 = mkexp('OF',{fun_f2").arg(id);
            break;
          case FUN_G:
            stream << QString("node%1 = mkexp('OF',{fun_g").arg(id);
            break;
          case FUN_H:
            stream << QString("node%1 = mkexp('OF',{fun_h").arg(id);
            break;
          case FUN_STAR:
            stream << QString("node%1 = mkexp('OF',{fun_star").arg(id);
            break;
          case FUN_PLUS:
            stream << QString("node%1 = mkexp('OF',{fun_plus").arg(id);
            break;
          case FUN_CARET:
            stream << QString("node%1 = mkexp('OF',{fun_caret").arg(id);
            break;
          case FUN_PRIME:
            stream << QString("node%1 = mkexp('OF',{fun_prime").arg(id);
            break;
          case FUN_SUCC:
            stream << QString("node%1 = mkexp('OF',{fun_succ").arg(id);
            break;
          case FUN_CUP:
            stream << QString("node%1 = mkexp('OF',{fun_cup").arg(id);
            break;
          case FUN_CAP:
            stream << QString("node%1 = mkexp('OF',{fun_cap").arg(id);
            break;
        }
        for (i=0; i<args.at(2).toList().size(); i++) stream << QString(",node%1").arg(args.at(2).toList().at(i).toInt());
        stream << "});\n";
        result = id;
      }
      break;

    case 111:
      {
        int id = ++expr_id;
        switch (args.at(2).toInt()) {
          case FUN_F:
            stream << QString("node%1 = mkexp('OF',{fun_f,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_F2:
            stream << QString("node%1 = mkexp('OF',{fun_f2,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_G:
            stream << QString("node%1 = mkexp('OF',{fun_g,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_H:
            stream << QString("node%1 = mkexp('OF',{fun_h,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_STAR:
            stream << QString("node%1 = mkexp('OF',{fun_star,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_PLUS:
            stream << QString("node%1 = mkexp('OF',{fun_plus,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_CARET:
            stream << QString("node%1 = mkexp('OF',{fun_caret,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_PRIME:
            stream << QString("node%1 = mkexp('OF',{fun_prime,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_SUCC:
            stream << QString("node%1 = mkexp('OF',{fun_succ,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_CUP:
            stream << QString("node%1 = mkexp('OF',{fun_cup,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
          case FUN_CAP:
            stream << QString("node%1 = mkexp('OF',{fun_cap,node%2,node%3});\n").arg(id).arg(args.at(1).toInt()).arg(args.at(3).toInt());
            break;
        }
        result = id;
      }
      break;

    case 112:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('OF',{fun_prime,node%2});\n").arg(id).arg(args.at(0).toInt());
        result = id;
      };
      break;

    case 113:
      {
        int id = ++expr_id, i, first = 1;
        switch (args.at(0).toInt()) {
          case REL_EQ:
            stream << QString("node%1 = mkexp('EQ',{").arg(id);
            break;
          case REL_NEQ:
            stream << QString("node%1 = mkexp('NEQ',{").arg(id);
            break;
          case REL_LT:
            stream << QString("node%1 = mkexp('LT',{").arg(id);
            break;
          case REL_GT:
            stream << QString("node%1 = mkexp('GT',{").arg(id);
            break;
          case REL_LEQ:
            stream << QString("node%1 = mkexp('LEQ',{").arg(id);
            break;
          case REL_GEQ:
            stream << QString("node%1 = mkexp('GEQ',{").arg(id);
            break;
          case REL_IN:
            stream << QString("node%1 = mkexp('IN',{").arg(id);
            break;
          case REL_SUBSET:
            stream << QString("node%1 = mkexp('SUBSET',{").arg(id);
            break;
          case REL_SUPSET:
            stream << QString("node%1 = mkexp('SUPSET',{").arg(id);
            break;
          case REL_R:
            stream << QString("node%1 = mkexp('OF',{rel_cap_r,").arg(id);
            break;
          case REL_SMALL_R:
            stream << QString("node%1 = mkexp('OF',{rel_r,").arg(id);
            break;
          case REL_M:
            stream << QString("node%1 = mkexp('OF',{rel_cap_m,").arg(id);
            break;
          case REL_ORD:
            stream << QString("node%1 = mkexp('OF',{rel_ord,").arg(id);
            break;
          case REL_TRANS:
            stream << QString("node%1 = mkexp('OF',{rel_trans,").arg(id);
            break;
          case REL_CONTRADICTION:
            stream << QString("node%1 = mkexp('OF',{rel_contradiction,").arg(id);
            break;
        }
        for (i=0; i<args.at(2).toList().size(); i++) {
          stream << QString(first ? "node%1" : ",node%1").arg(args.at(2).toList().at(i).toInt());
          first = 0;
        }
        stream << "});\n";
        result = id;
      }
      break;

    case 114:
      {
        int id = ++expr_id;
        switch (args.at(1).toInt()) {
          case REL_EQ:
            stream << QString("node%1 = mkexp('EQ',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_NEQ:
            stream << QString("node%1 = mkexp('NEQ',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_LT:
            stream << QString("node%1 = mkexp('LT',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_GT:
            stream << QString("node%1 = mkexp('GT',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_LEQ:
            stream << QString("node%1 = mkexp('LEQ',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_GEQ:
            stream << QString("node%1 = mkexp('GEQ',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_IN:
            stream << QString("node%1 = mkexp('IN',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_SUBSET:
            stream << QString("node%1 = mkexp('SUBSET',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_SUPSET:
            stream << QString("node%1 = mkexp('SUPSET',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_R:
            stream << QString("node%1 = mkexp('OF',{rel_cap_r,node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_SMALL_R:
            stream << QString("node%1 = mkexp('OF',{rel_r,node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_M:
            stream << QString("node%1 = mkexp('OF',{rel_cap_m,node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_ORD:
            stream << QString("node%1 = mkexp('OF',{rel_ord,node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_TRANS:
            stream << QString("node%1 = mkexp('OF',{rel_trans,node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
          case REL_CONTRADICTION:
            stream << QString("node%1 = mkexp('OF',{rel_contradiction,node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
            break;
        }
        result = id;
      }
      break;

    case 117:
      {
        int id = ++expr_id, i, first = 1;
        switch (args.at(0).toInt()) {
          case QUANT_FORALL:
            stream << QString("node%1 = mkexp('FORALL',node%2,{").arg(id).arg(args.at(3).toInt());
            break;
          case QUANT_EXISTS:
            stream << QString("node%1 = mkexp('EXISTS',node%2,{").arg(id).arg(args.at(3).toInt());
            break;
        }
        for (i=0; i<args.at(1).toList().size(); i++) {
          switch (args.at(1).toList().at(i).toInt()) {
            case VAR_M:
              stream << (first ? "var_m" : ",var_m");
              break;
            case VAR_N:
              stream << (first ? "var_n" : ",var_n");
              break;
            case VAR_T:
              stream << (first ? "var_t" : ",var_t");
              break;
            case VAR_U:
              stream << (first ? "var_u" : ",var_u");
              break;
            case VAR_V:
              stream << (first ? "var_v" : ",var_v");
              break;
            case VAR_W:
              stream << (first ? "var_w" : ",var_w");
              break;
            case VAR_X:
              stream << (first ? "var_x" : ",var_x");
              break;
            case VAR_Y:
              stream << (first ? "var_y" : ",var_y");
              break;
            case VAR_Z:
              stream << (first ? "var_z" : ",var_z");
              break;
          }
          first = 0;
        }
        stream << "});\n";
        result = id;
      };
      break;

    case 119:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('NOT',node%2);\n").arg(id).arg(args.at(1).toInt());
        result = id;
      };
      break;

    case 121:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('AND',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
        result = id;
      };
      break;

    case 123:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('OR',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
        result = id;
      };
      break;

    case 125:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('IMPLIES',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
        result = id;
      };
      break;

    case 127:
      {
        int id = ++expr_id;
        stream << QString("node%1 = mkexp('EQUIVALENT',{node%2,node%3});\n").arg(id).arg(args.at(0).toInt()).arg(args.at(2).toInt());
        result = id;
      };
      break;
    default: // no result
      break;
  }
  return result;
}

static QVariant printSubtree(const Node &node, QTextStream &stream) {
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      qFatal("error node encountered");
    default: // multiple alternatives
      qWarning("multiple alternatives, only the first alternative printed");
      // fall through
    case 1: // 1 alternative, normal tree 
      {
        QVariantList args;
        foreach (const Node &child, node.children.first())
          args.append(printSubtree(child, stream));
        QVariant label = node.children.first().label();
        return processRule(node.children.first().label().toInt(), args, stream);
      }
      break;
  }
}

static void printParseTree(const Node &tree) {
  static bool first = true;
  if (first) {
    first = false;
  } else {
    qWarning("multiple matches, only the first match printed");
    return;
  }

  QTextStream stream(stdout);
  stream << "var_m=mkvar('m');\n"
            "var_n=mkvar('n');\n"
            "var_t=mkvar('t');\n"
            "var_u=mkvar('u');\n"
            "var_v=mkvar('v');\n"
            "var_w=mkvar('w');\n"
            "var_x=mkvar('x');\n"
            "var_y=mkvar('y');\n"
            "var_z=mkvar('z');\n"
            "cst_emptyset=mkcon('\\emptyset');\n"
            "cst_c=mkcon('c');\n"
            "cst_0=mkcon('0');\n"
            "cst_1=mkcon('1');\n"
            "cst_2=mkcon('2');\n"
            "cst_3=mkcon('3');\n"
            "cst_4=mkcon('4');\n"
            "cst_5=mkcon('5');\n"
            "fun_f=mkcon('f');\n"
            "fun_f2=mkcon('f2');\n"
            "fun_g=mkcon('g');\n"
            "fun_h=mkcon('h');\n"
            "fun_star=mkcon('*');\n"
            "fun_plus=mkcon('+');\n"
            "fun_caret=mkcon('^');\n"
            "fun_prime=mkcon('\\prime');\n"
            "fun_succ=mkcon('Succ');\n"
            "fun_cup=mkcon('\\cup');\n"
            "fun_cap=mkcon('\\cap');\n"
            "rel_cap_r=mkcon('R');\n"
            "rel_r=mkcon('r');\n"
            "rel_cap_m=mkcon('M');\n"
            "rel_ord=mkcon('Ord');\n"
            "rel_trans=mkcon('Trans');\n"
            "rel_contradiction=mkcon('Contradiction');" << endl;
  printSubtree(tree, stream);
}
#else
static void printLabel(const QVariant &label, QTextStream &stream) {
  if (!label.isNull())
    stream << " (rule #" << label.toInt() << ')';
}

static void printSubtree(const Node &node, int level, QTextStream &stream) {
  for (int i=0; i<level; i++) stream << ' ';
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      for (int i=0; i<=level; i++) stream << ' ';
      stream << "ERROR" << endl;
      break;
    case 1: // 1 alternative, normal tree
      stream << categoryNames.at(node.cat);
      printLabel(node.children.first().label(), stream);
      stream << endl;
      foreach (const Node &child, node.children.first())
        printSubtree(child, level+1, stream);
      break;
    default: // multiple alternatives
      stream << categoryNames.at(node.cat) << endl;
      foreach (const Alternative &alternative, node.children) {
        for (int i=0; i<=level; i++) stream << ' ';
        stream << "ALTERNATIVE";
        printLabel(alternative.label(), stream);
        stream << endl;
        foreach (const Node &child, alternative)
          printSubtree(child, level+2, stream);
      }
      break;
  }
}

static void printParseTree(const Node &tree) {
  QTextStream stream(stdout);
  printSubtree(tree, 0, stream);
}
#endif

static void printPredictions(const Predictions &predictions,
                             const Parser &parser)
{
  QTextStream stream(stderr);
  foreach (CatArg prediction, predictions) {
    stream << "expected: " << categoryNames.at(prediction) << endl;
    if (!parser.isToken(prediction)) {
      QHash<Cat, QSet<Cat> > expandedPrediction
       = parser.expandNonterminalPrediction(prediction);
      QHashIterator<Cat, QSet<Cat> > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " expected category: " << categoryNames.at(cat) << endl;
        foreach (CatArg token, it.value())
          stream << "  expected token: " << categoryNames.at(token) << endl;
      }
    }
  }
}

// main function for testing purposes
int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);
  bool accepted = false;

  {
    NaprocheParser naprocheParser;
    if (argc > 1)
      naprocheParser.setInputFile(argv[1]);
    int errorPos;
    Cat errorToken;
    QList<StackItem> stacks;
    QList<Match> matches = naprocheParser.parse(&errorPos, &errorToken, 0,
                                                &stacks);
    categoryNames = getCategoryNames();
    if (errorPos >= 0) {
      QTextStream stream(stderr);
      stream << "parse error at position " << errorPos << ": unexpected "
             << categoryNames.at(errorToken) << endl;
    } else if (matches.isEmpty()) {
      {
        QTextStream stream(stderr);
        stream << "parse error at end of input: incomplete input" << endl;
      }
      printPredictions(naprocheParser.computePredictions(stacks),
                       naprocheParser);
    } else {
      foreach (const Match &m, matches) {
        accepted = true;
        printParseTree(m.tree);
      }
    }
  }

  delete app;
  return !accepted;
}
