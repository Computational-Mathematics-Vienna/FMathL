/* DynGenPar: Dynamic Generalized Parser - Main program for testing purposes
   Copyright (C) 2010-2011 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2014 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include <QCoreApplication>
#include <QTextStream>
#include <cstdio>
#include "dyngenpar.h"

using namespace DynGenPar;

static QCoreApplication *app;

// printing functions for test main function

static void printSubtree(const Node &node, int level, QTextStream &stream) {
  for (int i=0; i<level; i++) stream << ' ';
  stream << node.cat << endl;
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      for (int i=0; i<=level; i++) stream << ' ';
      stream << "ERROR" << endl;
      break;
    case 1: // 1 alternative, normal tree
      foreach (const Node &child, node.children.first())
        printSubtree(child, level+1, stream);
      break;
    default: // multiple alternatives
      foreach (const Alternative &subtree, node.children) {
        for (int i=0; i<=level; i++) stream << ' ';
        stream << "ALTERNATIVE" << endl;
        foreach (const Node &child, subtree)
          printSubtree(child, level+2, stream);
      }
      break;
  }
}

static void printParseTree(const Node &tree) {
  QTextStream stream(stdout);
  printSubtree(tree, 0, stream);
}

#if 0
static void printPredictions(const Predictions &predictions,
                             const Parser &parser)
{
  QTextStream stream(stdout);
  foreach (CatArg prediction, predictions) {
    stream << "Prediction: " << prediction << endl;
    if (!parser.isToken(prediction)) {
      QHash<Cat, QSet<Cat> > expandedPrediction
       = parser.expandNonterminalPrediction(prediction);
      QHashIterator<Cat, QSet<Cat> > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " Predicted category: " << cat << endl;
        foreach (CatArg token, it.value())
          stream << "  Predicted token: " << token << endl;
      }
    }
  }
}
#endif

static void printMultiPredictions(const MultiPredictions &predictions,
                                  const Parser &parser)
{
  QTextStream stream(stdout);
  QHashIterator<QList<Cat>, MultiPrediction> it(predictions);
  while (it.hasNext()) {
    it.next();
    QList<Cat> key = it.key();
    if (parser.isLiteral(key)) {
      stream << "Prediction: ";
      foreach(CatArg token, key) stream << token;
      stream << endl;
      stream << " Completes: ";
      foreach(CatArg token, it.value().fullLiteral) stream << token;
      stream << endl;
      stream << " For category: " << it.value().cat << endl;
    } else {
      Cat prediction = key.first();
      stream << "Prediction: " << prediction << endl;
      QHash<Cat, QSet<QList<Cat> > > expandedPrediction
        = parser.expandNonterminalPredictionMulti(prediction);
      QHashIterator<Cat, QSet<QList<Cat> > > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " Predicted category: " << cat << endl;
        foreach (const QList<Cat> &literal, it.value()) {
          stream << "  Predicted literal: ";
          foreach (CatArg token, literal) stream << token;
          stream << endl;
        }
      }
    }
  }
}

static void printSyntaxSubtree(const Node &node, int level,
                               QTextStream &stream)
{
  for (int i=0; i<level; i++) stream << ' ';
  if (IS_EPSILON(node.cat)) {
    stream << "ERROR" << endl;
    return;
  }
  switch (node.children.size()) {
    case 0: // no alternatives = metavariable
      stream << '[' << node.cat << ']' << endl;
      break;
    case 1: // 1 alternative, normal tree
      stream << node.children.first().label().toString() << endl;
      foreach (const Node &child, node.children.first())
        printSyntaxSubtree(child, level+1, stream);
      break;
    default: // multiple alternatives
      {
        stream << "ALTERNATIVES" << endl;
        foreach (const Alternative &subtree, node.children) {
          for (int i=0; i<=level; i++) stream << ' ';
          stream << subtree.label().toString() << endl;
          foreach (const Node &child, subtree)
            printSyntaxSubtree(child, level+2, stream);
        }
      }
      break;
  }
}

// prints PMCFG syntax trees
static void printSyntaxTree(const Node &tree)
{
  QTextStream stream(stdout);
  printSyntaxSubtree(tree, 0, stream);
}

class TestAction : public Action {
  public:
    TestAction() : executed(false) {}
    virtual ~TestAction() {}
    virtual void execute(const ActionInfo &info) {
      printParseTree(info.tree);
      executed = true;
    }
    bool executed;
};

// main function for testing purposes
int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);
  bool accepted = false;

  {
    ListTokenSource tokenSource;
    Parser parser(&tokenSource);

    // initialize testcase
    parser.tokens << "a" << "b" << "c";
    parser.rules["S"] << (Rule() << "A")
                     << (Rule() << "A" << "S");
    parser.rules["A"] << (Rule() << "a")
                     << (Rule() << "b")
                     << (Rule() << "c");
    tokenSource.inputTokens << "b" << "a";
    parser.startCat = 'S';

    parser.initCaches();

    // parse, also testing incremental parsing and prediction
    int incrementalPos = -1; // must init to a negative integer
    QList<StackItem> incrementalStacks;
    QList<Match> matches = parser.parse(0, 0, &incrementalPos,
                                        &incrementalStacks);
    foreach (const Match &m, matches) {
      if (m.len != tokenSource.inputTokens.size())
        qFatal("invalid match (wrong length)");
      accepted = true;
      printParseTree(m.tree);
    }
    printMultiPredictions(parser.computeMultiPredictions(incrementalStacks),
                          parser);

    if (accepted) {
      // incrementally add the token "c"
      accepted = false;
      tokenSource.inputTokens << "c";
      QList<Match> matches = parser.parse(0, 0, &incrementalPos,
                                          &incrementalStacks);
      foreach (const Match &m, matches) {
        if (m.len != tokenSource.inputTokens.size())
          qFatal("invalid match (wrong length)");
        accepted = true;
        printParseTree(m.tree);
      }

      if (accepted) {
        // try with an added rule
        accepted = false;
        parser.addRule("S", (Rule() << "B"));
        parser.addRule("B", (Rule() << "a"));
        // get rid of the "c" we added
        tokenSource.inputTokens.removeLast();

        // parse
        QList<Match> matches = parser.parse();
        foreach (const Match &m, matches) {
          if (m.len != tokenSource.inputTokens.size())
            qFatal("invalid match (wrong length)");
          accepted = true;
          printParseTree(m.tree);
        }

        if (accepted) {
          // now try a completely different example
          accepted = false;
          parser.rules.clear();
          parser.rules["S"] << (Rule() << "A")
                            << (Rule() << "a");
          parser.rules["A"] << (Rule() << "a");
          tokenSource.inputTokens.clear();
          tokenSource.inputTokens << "a";
          parser.initCaches();

          // parse
          QList<Match> matches = parser.parse();
          foreach (const Match &m, matches) {
            if (m.len != tokenSource.inputTokens.size())
              qFatal("invalid match (wrong length)");
            accepted = true;
            printParseTree(m.tree);
          }

          if (accepted) {
            // now test error handling
            tokenSource.inputTokens << "a";
            int errorPos;
            Cat errorToken;
            QList<Match> matches = parser.parse(&errorPos, &errorToken);
            QTextStream stream(stdout);
            stream << matches.count() << " matches" << endl;
            stream << "parse error at position " << errorPos
                   << ": unexpected \"" << errorToken << '"' << endl;
            /* This one should actually not be accepted, so we accept the test
               if the input had no matches. */
            accepted = matches.isEmpty();

            if (accepted) {
              // now test PMCFG support in the internal representation
              // example 1: a^n b^n c^n grammar (MCFG)
              accepted = false;
              parser.rules.clear();
              parser.rules["S"] << (Rule() << "_A1" << "_A2" << "_A3");
              parser.rules["A1"] << (Rule() << "_A1" << "a")
                                 << (Rule() << "a");
              parser.rules["A2"] << (Rule() << "_A2" << "b")
                                 << (Rule() << "b");
              parser.rules["A3"] << (Rule() << "_A3" << "c")
                                 << (Rule() << "c");
              QList<Cat> pseudoCatGroup;
              pseudoCatGroup << "_A1" << "_A2" << "_A3";
              parser.pseudoCats.insert("_A1",
                                       qMakePair(Cat("A1"), pseudoCatGroup));
              parser.pseudoCats.insert("_A2",
                                       qMakePair(Cat("A2"), pseudoCatGroup));
              parser.pseudoCats.insert("_A3",
                                       qMakePair(Cat("A3"), pseudoCatGroup));
              parser.componentCats.insert("A1", qMakePair(Cat("A"), 0));
              parser.componentCats.insert("A2", qMakePair(Cat("A"), 1));
              parser.componentCats.insert("A3", qMakePair(Cat("A"), 2));
              parser.catComponents.insert("A",
                                          QList<Cat>() << "A1" << "A2" << "A3");
              tokenSource.inputTokens.clear();
              tokenSource.inputTokens << "a" << "a" << "a" << "b" << "b" << "b"
                                      << "c" << "c" << "c";
              parser.initCaches();
              // parse
              QList<Match> matches = parser.parse();
              foreach (const Match &m, matches) {
                if (m.len != tokenSource.inputTokens.size())
                  qFatal("invalid match (wrong length)");
                accepted = true;
                printParseTree(m.tree);
              }

              if (accepted) {
                // example 2: same grammar, invalid input
                tokenSource.inputTokens.clear();
                tokenSource.inputTokens << "a" << "a" << "a" << "b" << "b"
                                        << "c" << "c" << "c";

                QList<Match> matches = parser.parse(&errorPos, &errorToken);
                stream << matches.count() << " matches" << endl;
                stream << "parse error at position " << errorPos
                      << ": unexpected \"" << errorToken << '"' << endl;
                /* This one should actually not be accepted, so we accept the
                   test if the input had no matches. */
                accepted = matches.isEmpty();
                if (accepted) {
                  // example 3: exponential language a^(2^n) (non-MCFG PMCFG)
                  accepted = false;
                  parser.rules.clear();
                  parser.rules["S"] << (Rule() << "_S" << "_S")
                                    << (Rule() << "a");
                  QList<Cat> pseudoCatGroup;
                  pseudoCatGroup << "_S";
                  parser.pseudoCats.clear();
                  parser.pseudoCats.insert("_S",
                                           qMakePair(Cat("S"), pseudoCatGroup));
                  parser.componentCats.clear();
                  tokenSource.inputTokens.clear();
                  tokenSource.inputTokens << "a" << "a" << "a" << "a"
                                          << "a" << "a" << "a" << "a";
                  parser.initCaches();
                  // parse
                  QList<Match> matches = parser.parse();
                  foreach (const Match &m, matches) {
                    if (m.len != tokenSource.inputTokens.size())
                      qFatal("invalid match (wrong length)");
                    accepted = true;
                    printParseTree(m.tree);

                    if (accepted) {
                      // now test PMCFG support in the standard representation
                      // example 1: a^n b^n c^n grammar (MCFG)
                      // using named functions for this example
                      accepted = false;
                      Pmcfg pmcfg1;
                      pmcfg1.addFunction("f",
                        Function() << (Sequence() << Term(0,0)
                                                  << Term(0,1)
                                                  << Term(0,2)));
                      pmcfg1.addFunction("g",
                        Function() << (Sequence() << Term(0,0) << Term("a"))
                                   << (Sequence() << Term(0,1) << Term("b"))
                                   << (Sequence() << Term(0,2) << Term("c")));
                      pmcfg1.addFunction("h",
                        Function() << (Sequence() << Term("a"))
                                   << (Sequence() << Term("b"))
                                   << (Sequence() << Term("c")));
                      pmcfg1.rules["S"] << (Rule("f") << "A");
                      pmcfg1.rules["A"] << (Rule("g") << "A")
                                        << Rule("h");
                      pmcfg1.tokens << "a" << "b" << "c";
                      pmcfg1.startCat = 'S';
                      parser.loadPmcfg(pmcfg1);
                      tokenSource.inputTokens.clear();
                      tokenSource.inputTokens << "a" << "a" << "a" << "b" << "b"
                                              << "b" << "c" << "c" << "c";
                      // parse
                      QList<Match> matches = parser.parse();
                      foreach (const Match &m, matches) {
                        if (m.len != tokenSource.inputTokens.size())
                          qFatal("invalid match (wrong length)");
                        accepted = true;
                        printSyntaxTree(parseTreeToPmcfgSyntaxTree(m.tree));
                      }

                      if (accepted) {
                        // example 2: same grammar, invalid input
                        tokenSource.inputTokens.clear();
                        tokenSource.inputTokens << "a" << "a" << "a" << "b"
                                                << "b" << "c" << "c" << "c";

                        QList<Match> matches = parser.parse(&errorPos,
                                                            &errorToken);
                        stream << matches.count() << " matches" << endl;
                        stream << "parse error at position " << errorPos
                              << ": unexpected \"" << errorToken << '"' << endl;
                        /* This one should actually not be accepted, so we
                           accept the test if the input had no matches. */
                        accepted = matches.isEmpty();
                        if (accepted) {
                          // example 3: exponential language a^(2^n) (non-MCFG)
                          // using unnamed functions for this example
                          accepted = false;
                          Pmcfg pmcfg2;
                          pmcfg2.functions
                            << (Function() << (Sequence() << Term(0,0)
                                                          << Term(0,0)))
                            << (Function() << (Sequence() << Term("a")));
                          pmcfg2.rules["S"] << (Rule(0) << "S")
                                            << Rule(1);
                          pmcfg2.tokens << "a";
                          pmcfg2.startCat = 'S';
                          parser.loadPmcfg(pmcfg2);
                          tokenSource.inputTokens.clear();
                          tokenSource.inputTokens << "a" << "a" << "a" << "a"
                                                  << "a" << "a" << "a" << "a";
                          // parse
                          QList<Match> matches = parser.parse();
                          foreach (const Match &m, matches) {
                            if (m.len != tokenSource.inputTokens.size())
                              qFatal("invalid match (wrong length)");
                            accepted = true;
                            printSyntaxTree(parseTreeToPmcfgSyntaxTree(m.tree));
                          }
                          if (accepted) {
                            // now test next token constraints
                            parser.rules.clear();
                            parser.tokens.clear();
                            parser.pseudoCats.clear();
                            parser.componentCats.clear();
                            parser.catComponents.clear();
                            parser.tokens << "a" << "b" << "c";
                            parser.rules["S"] << (Rule() << "A" << "c");
                            Rule constrainedRule1;
                            constrainedRule1 << "a";
                            constrainedRule1.nextTokenConstraints.expect << "c";
                            Rule constrainedRule2;
                            constrainedRule2 << "b";
                            constrainedRule2.nextTokenConstraints.taboo << "c";
                            parser.rules["A"] << constrainedRule1
                                              << constrainedRule2;
                            parser.initCaches();
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "a" << "c";
                            if (parser.parse().isEmpty()) { // should accept
                              qWarning("next token constraints test 1 failed");
                              accepted = false;
                            }
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "b" << "c";
                            if (!parser.parse().isEmpty()) { // should reject
                              qWarning("next token constraints test 2 failed");
                              accepted = false;
                            }
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A" << "b");
                            parser.initCaches();
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "b" << "b";
                            if (parser.parse().isEmpty()) { // should accept
                              qWarning("next token constraints test 3 failed");
                              accepted = false;
                            }
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "a" << "b";
                            if (!parser.parse().isEmpty()) { // should reject
                              qWarning("next token constraints test 4 failed");
                              accepted = false;
                            }
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A");
                            parser.initCaches();
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "b";
                            if (parser.parse().isEmpty()) { // should accept
                              qWarning("next token constraints test 5 failed");
                              accepted = false;
                            }
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "a";
                            if (!parser.parse().isEmpty()) { // should reject
                              qWarning("next token constraints test 6 failed");
                              accepted = false;
                            }
                            // maximally-matched identifier tests
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A" << "c");
                            Rule constrainedRule3;
                            constrainedRule3 << "B";
                            constrainedRule3.nextTokenConstraints.taboo << "B";
                            parser.rules["A"].clear();
                            parser.rules["A"] << (Rule() << "B" << "A")
                                              << constrainedRule3;
                            parser.rules["B"] << (Rule() << "a")
                                              << (Rule() << "b");
                            parser.initCaches();
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "a" << "b" << "a" << "b"
                                                    << "c";
                            if (parser.parse().isEmpty()) { // should accept
                              qWarning("next token constraints test 7 failed");
                              accepted = false;
                            }
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A");
                            parser.initCaches();
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "a" << "b" << "a" << "b";
                            if (parser.parse().isEmpty()) { // should accept
                              qWarning("next token constraints test 8 failed");
                              accepted = false;
                            }
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A" << "A");
                            parser.initCaches();
                            if (!parser.parse().isEmpty()) { // should reject
                              qWarning("next token constraints test 9 failed");
                              accepted = false;
                            }
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A" << "A" << "A");
                            parser.initCaches();
                            if (!parser.parse().isEmpty()) { // should reject
                              qWarning("next token constraints test 10 failed");
                              accepted = false;
                            }
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A" << "A" << "A"
                                                         << "A");
                            parser.initCaches();
                            if (!parser.parse().isEmpty()) { // should reject
                              qWarning("next token constraints test 11 failed");
                              accepted = false;
                            }
                            parser.rules["S"].clear();
                            parser.rules["S"] << (Rule() << "A" << "A" << "c");
                            parser.initCaches();
                            tokenSource.inputTokens.clear();
                            tokenSource.inputTokens << "a" << "b" << "a" << "b"
                                                    << "c";
                            if (!parser.parse().isEmpty()) { // should reject
                              qWarning("next token constraints test 12 failed");
                              accepted = false;
                            }
                            if (accepted) {
                              /* now test mutual left recursion (abstracted
                                 version of BasicDefinitions grammar) */
                              accepted = false;
                              parser.rules.clear();
                              parser.tokens.clear();
                              parser.tokens << "u" << "v" << "w";
                              parser.rules["S"] << (Rule() << "A" << "w");
                              parser.rules["A"] << (Rule() << "B")
                                                << (Rule() << "C");
                              parser.rules["B"] << (Rule() << "A" << "C");
                              parser.rules["C"] << (Rule() << "u")
                                                << (Rule() << "v");
                              parser.initCaches();
                              tokenSource.inputTokens.clear();
                              tokenSource.inputTokens << "u" << "v" << "w";
                              // parse
                              QList<Match> matches = parser.parse(&errorPos,
                                                                  &errorToken);
                              foreach (const Match &m, matches) {
                                if (m.len != tokenSource.inputTokens.size())
                                  qFatal("invalid match (wrong length)");
                                accepted = true;
                                printParseTree(m.tree);
                              }
                              if (!accepted) {
                                stream << "parse error at position " << errorPos
                                       << ": unexpected \"" << errorToken << '"'
                                       << endl;
                                stream << "ERROR: THIS TESTCASE SHOULD PARSE!"
                                       << endl;
                              } else {
                                // now test parse actions
                                accepted = false;
                                parser.rules.clear();
                                parser.tokens.clear();
                                parser.tokens << "u" << "v";
                                TestAction action1, action2, action3, action4;
                                Rule rule1;
                                rule1 << "A";
                                rule1.action = &action1;
                                Rule rule2;
                                rule2 << "B";
                                rule2.action = &action2;
                                parser.rules["S"] << rule1 << rule2;
                                Rule rule3;
                                rule3 << "u";
                                rule3.action = &action3;
                                parser.rules["A"] << rule3;
                                Rule rule4;
                                rule4 << "v";
                                rule4.action = &action4;
                                parser.rules["B"] << rule4;
                                parser.initCaches();
                                tokenSource.inputTokens.clear();
                                tokenSource.inputTokens << "u";
                                // parse
                                parser.parse();
                                // We test whether the correct actions have run.
                                accepted = action1.executed
                                           && !action2.executed
                                           && action3.executed
                                           && !action4.executed;
                                if (accepted) {
                                  // Test epsilon matches at the beginning of a
                                  // rule
                                  parser.rules.clear();
                                  parser.tokens.clear();
                                  parser.tokens << "x";
                                  parser.rules["S"] << (Rule() << "A" << "B"
                                                               << "x");
                                  parser.rules["A"] << (Rule());
                                  parser.rules["B"] << (Rule());
                                  parser.initCaches();
                                  tokenSource.inputTokens.clear();
                                  tokenSource.inputTokens << "x";
                                  parser.parse();
                                  // parse
                                  QList<Match> matches = parser.parse(&errorPos,
                                                           &errorToken);
                                  if (matches.size() == 1) {
                                    const Match &m = matches.first();
                                    if (m.len != tokenSource.inputTokens.size())
                                      qFatal("invalid match (wrong length)");
                                    const QList<Alternative> &alternatives
                                      = m.tree.children;
                                    accepted = true;
                                    if (alternatives.isEmpty()) {
                                      qWarning("epsilon match test failed: "
                                               "no alternatives");
                                      accepted = false;
                                    } else {
                                      const Alternative &alternative
                                        = alternatives.first();
                                      QStringList expected;
                                      expected << "A" << "B" << "x";
                                      int l = expected.size();
                                      if (alternative.size() != l) {
                                        qWarning("epsilon match test failed: "
                                                 "%d children, %d expected",
                                                 alternative.size(), l);
                                        accepted = false;
                                      } else {
                                        for (int i=0; i<l; i++) {
                                          if (alternative.at(i).cat !=
                                                expected.at(i)) {
                                            qWarning("epsilon match test "
                                                     "failed: category %d is "
                                                     "\"%s\" instead of "
                                                     "expected \"%s\"", i,
                                                     alternative.at(i).cat
                                                       .toLocal8Bit().data(),
                                                     expected.at(i)
                                                       .toLocal8Bit().data());
                                            accepted = false;
                                          }
                                        }
                                      }
                                    }
                                    printParseTree(m.tree);
                                  } else {
                                    qWarning("epsilon match test failed: "
                                             "%d matches, 1 expected",
                                             matches.size());
                                    accepted = false;
                                  }
                                  if (matches.isEmpty()) {
                                    stream << "parse error at position "
                                           << errorPos << ": unexpected \""
                                           << errorToken << '"' << endl;
                                    stream << "ERROR: THIS TESTCASE SHOULD "
                                              "PARSE!" << endl;
                                  }
                                }
                              }
                            }
                          }
                        }
                      }
                    }
                  }
                }
              }
            }
          }
        }
      }
    }
  }

  delete app;
  return !accepted;
}
