/* DynGenPar: Dynamic Generalized Parser - Naproche categories
   Copyright (C) 2010 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#pragma once

#include <QStringList>

enum Cats {
  // dummy categories
  EPSILON, SCAN_ERROR,

  // tokens in the Naproche grammar
  FORMULA, THEOREM, PROOF, QED, LEMMA, DEFINE, IFF, ASSUME_THAT, ASSUME_CONTR,
  LET, CONSIDER, THUS, CONTRADICTION, FOR_ALL, COMMA, THERE_IS_AN, SUCH_THAT,
  IMPLIES, NOT, THEN, HENCE, RECALL_THAT, BUT, IN_PARTICULAR, OBSERVE_THAT,
  TOGETHER_WE_HAVE, SO,

  // true nonterminals in the Naproche grammar
  text, theorem, lemma, proof, lemma_OR_theorem, ext_statement_OR_lemma,
  definition, assumption_kwd, assumption, open_assumption, assumption_close,
  uni_quant, ext_quant, implication, negation, closed_assumption, statement_kwd,
  statement, sub_statement, ext_statement, simple_statement,
  assumption_OR_ext_statement, variable,

  // list nonterminals in the Naproche grammar
  open_assumption_L, definition_L, lemma_OR_theorem_L, assumption_L,
  assumption_OR_ext_statement_L, ext_statement_P, ext_statement_OR_lemma_L,

  // tokens in the formula grammar
  DOLLAR, LPAREN, RPAREN, VAR_M, VAR_N, VAR_T, VAR_U, VAR_V, VAR_W, VAR_X,
  VAR_Y, VAR_Z, CST_EMPTYSET, CST_C, CST_0, CST_1, CST_2, CST_3, CST_4, CST_5,
  FUN_F, FUN_F2, FUN_G, FUN_H, FUN_STAR, FUN_PLUS, FUN_CARET, FUN_PRIME,
  FUN_SUCC, FUN_CUP, FUN_CAP, REL_EQ, REL_NEQ, REL_LT, REL_GT, REL_LEQ, REL_GEQ,
  REL_IN, REL_R, REL_SMALL_R, REL_M, REL_ORD, REL_TRANS, REL_CONTRADICTION,
  REL_SUBSET, REL_SUPSET, QUANT_FORALL, QUANT_EXISTS, LOG_NEG, LOG_AND, LOG_OR,
  LOG_IMPLIES, LOG_EQUIVALENT,

  // true nonterminals in the formula grammar
  dollar_formula, variable_symbol, constant_symbol, function_symbol,
  relation_symbol, quantifier, term, atomic_formula, quant_formula, neg_formula,
  and_formula, or_formula, implies_formula, formula,

  // list nonterminals in the formula grammar
  term_P, term_L, variable_symbol_P
};
Q_DECLARE_TYPEINFO(Cats, Q_PRIMITIVE_TYPE);

inline QStringList getCategoryNames() {
  QStringList result;

  // dummy categories
  result << "EPSILON" << "SCAN_ERROR"

  // tokens in the Naproche grammar
  << "FORMULA" << "THEOREM" << "PROOF" << "QED" << "LEMMA" << "DEFINE" << "IFF"
  << "ASSUME_THAT" << "ASSUME_CONTR" << "LET" << "CONSIDER" << "THUS"
  << "CONTRADICTION" << "FOR_ALL" << "COMMA" << "THERE_IS_AN" << "SUCH_THAT"
  << "IMPLIES" << "NOT" << "THEN" << "HENCE" << "RECALL_THAT" << "BUT"
  << "IN_PARTICULAR" << "OBSERVE_THAT" << "TOGETHER_WE_HAVE" << "SO"

  // true nonterminals in the Naproche grammar
  << "text" << "theorem" << "lemma" << "proof" << "lemma_OR_theorem"
  << "ext_statement_OR_lemma" << "definition" << "assumption_kwd"
  << "assumption" << "open_assumption" << "assumption_close" << "uni_quant"
  << "ext_quant" << "implication" << "negation" << "closed_assumption"
  << "statement_kwd" << "statement" << "sub_statement" << "ext_statement"
  << "simple_statement" << "assumption_OR_ext_statement" << "variable"

  // list nonterminals in the Naproche grammar
  << "open_assumption_L" << "definition_L" << "lemma_OR_theorem_L"
  << "assumption_L" << "assumption_OR_ext_statement_L" << "ext_statement_P"
  << "ext_statement_OR_lemma_L"

  // tokens in the formula grammar
  << "DOLLAR" << "LPAREN" << "RPAREN" << "VAR_M" << "VAR_N" << "VAR_T"
  << "VAR_U" << "VAR_V" << "VAR_W" << "VAR_X" << "VAR_Y" << "VAR_Z"
  << "CST_EMPTYSET" << "CST_C" << "CST_0" << "CST_1" << "CST_2" << "CST_3"
  << "CST_4" << "CST_5" << "FUN_F" << "FUN_F2" << "FUN_G" << "FUN_H"
  << "FUN_STAR" << "FUN_PLUS" << "FUN_CARET" << "FUN_PRIME" << "FUN_SUCC"
  << "FUN_CUP" << "FUN_CAP" << "REL_EQ" << "REL_NEQ" << "REL_LT" << "REL_GT"
  << "REL_LEQ" << "REL_GEQ" << "REL_IN" << "REL_R" << "REL_SMALL_R" << "REL_M"
  << "REL_ORD" << "REL_TRANS" << "REL_CONTRADICTION" << "REL_SUBSET"
  << "REL_SUPSET" << "QUANT_FORALL" << "QUANT_EXISTS" << "LOG_NEG" << "LOG_AND"
  << "LOG_OR" << "LOG_IMPLIES" << "LOG_EQUIVALENT"

  // true nonterminals in the formula grammar
  << "dollar_formula" << "variable_symbol" << "constant_symbol"
  << "function_symbol" << "relation_symbol" << "quantifier" << "term"
  << "atomic_formula" << "quant_formula" << "neg_formula" << "and_formula"
  << "or_formula" << "implies_formula" << "formula"

  // list nonterminals in the formula grammar
  << "term_P" << "term_L" << "variable_symbol_P";

  return result;
}
