/* DynGenPar: Dynamic Generalized Parser - Graphical PGF import test program
   Copyright (C) 2010-2011 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2017 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include "pgfgui-mainwindow.h"
#include <QString>
#include <QTextStream>
#include <QTreeWidget>
#include <QTreeWidgetItem>
#include <QVariant>
#include <KMessageBox>
#include <KInputDialog>
#include <KMenuBar>
#include <KMenu>
#include <KAction>
#include <KStandardAction>
#include <KFileDialog>
#include <KIcon>
#include <KUrl>

using namespace DynGenPar;

MainWindow::MainWindow(QWidget* parent, Qt::WindowFlags fl)
  : KMainWindow(parent, fl), pgfParser(0)
{
  setupUi(this);

  fileMenu->addAction(KStandardAction::open(this, SLOT(open()), this));
  fileMenu->addSeparator();
  fileMenu->addAction(KStandardAction::quit(this, SLOT(close()), this));
  undoAction = KStandardAction::undo(this, SLOT(undo()), this);
  undoAction->setEnabled(false);
  editMenu->addAction(undoAction);
  editMenu->addSeparator();
  editMenu->addAction(KStandardAction::clear(this, SLOT(reset()), this));
  editMenu->addSeparator();
  KAction *generateSyntaxTreeAction=new KAction(KIcon("run-build"),
                                                "&Generate syntax tree", this);
  connect(generateSyntaxTreeAction, SIGNAL(triggered()),
          this, SLOT(generateSyntaxTree()));
  editMenu->addAction(generateSyntaxTreeAction);
  QMenu *help = helpMenu();
  menuBar()->addMenu(help);

  searchLineWidget->searchLine()->setTreeWidget(treeWidget);
  connect(treeWidget, SIGNAL(itemActivated(QTreeWidgetItem*,int)),
          this, SLOT(treeWidget_itemActivated(QTreeWidgetItem*,int)));
}

MainWindow::~MainWindow()
{
  if (pgfParser) delete pgfParser;
}

void MainWindow::loadPgf(const QString &fileName)
{
  if (pgfParser) delete pgfParser;
  pgfParser = new PgfParser(fileName);
  reset();
  textEdit->setEnabled(true);
  treeWidget->setEnabled(true);
  searchLineWidget->setEnabled(true);
}

void MainWindow::open()
{
  QString fileName = KFileDialog::getOpenFileName(KUrl(),
                                                  "*.pgf|PGF Grammars (*.pgf)",
                                                  this);
  if (!fileName.isEmpty())
    loadPgf(fileName);
}

void MainWindow::undo()
{
  if (!incrementalHistory.isEmpty()) {
    incrementalState = incrementalHistory.pop();
    textEdit->setText(QString::fromLocal8Bit(incrementalState.buffer));
    textEdit->moveCursor(QTextCursor::End);
    if (incrementalHistory.isEmpty()) undoAction->setEnabled(false);
    predict();
  }
}

void MainWindow::reset()
{
  incrementalState.buffer.clear();
  pgfParser->setInputBuffer(&incrementalState.buffer);
  textEdit->clear();
  searchLineWidget->searchLine()->clear();
  incrementalState.pos = -1;
  incrementalState.stacks.clear();
  incrementalState.lexerState.clear();
  incrementalHistory.clear();
  undoAction->setEnabled(false);
  predict();
}

void MainWindow::predict()
{
  int errorPos;
  Cat errorToken;
  treeWidget->clear();
  searchLineWidget->searchLine()->clear();
  pgfParser->parse(&errorPos, &errorToken, &incrementalState.pos,
                   &incrementalState.stacks, &incrementalState.matches,
                   &incrementalState.lexerState);
  if (errorPos >= 0) {
    KMessageBox::error(this,
                       QString("parse error at position %1: unexpected %2")
                         .arg(errorPos).arg(pgfParser->catName(errorToken)),
                       "Syntax Error");
    reset();
  } else {
    ConstrainedPredictions predictions
      = pgfParser->computeConstrainedPredictions(incrementalState.stacks);
    foreach (CatArg prediction, predictions.uniqueKeys()) {
      QTreeWidgetItem *topLevelItem = new QTreeWidgetItem(treeWidget);
      topLevelItem->setText(0, pgfParser->catName(prediction));
      if (pgfParser->isToken(prediction)) {
        topLevelItem->setData(0, Qt::UserRole, prediction);
      } else {
        topLevelItem->setData(0, Qt::UserRole, QVariant());
        QHash<Cat, QSet<Cat> > expandedPrediction
          = pgfParser->expandNonterminalPredictionC(prediction,
              predictions.values(prediction));
        if (expandedPrediction.isEmpty())
          delete topLevelItem;
        else {
          QHashIterator<Cat, QSet<Cat> > it(expandedPrediction);
          while (it.hasNext()) {
            it.next();
            Cat cat = it.key();
            QTreeWidgetItem *categoryItem = new QTreeWidgetItem(topLevelItem);
            categoryItem->setText(0, pgfParser->catName(cat));
            categoryItem->setData(0, Qt::UserRole, QVariant());
            foreach (CatArg token, it.value()) {
              QTreeWidgetItem *tokenItem = new QTreeWidgetItem(categoryItem);
              tokenItem->setText(0, pgfParser->catName(token));
              tokenItem->setData(0, Qt::UserRole, token);
            }
          }
        }
      }
    }
    treeWidget->sortItems(0, Qt::AscendingOrder);
    treeWidget->expandAll();
  }
}

template<class ParentType>
  void MainWindow::generateSyntaxSubtree(const Node &node,
                                         ParentType *parentItem)
{
  if (IS_EPSILON(node.cat)) {
    QTreeWidgetItem *errorItem = new QTreeWidgetItem(parentItem);
    errorItem->setText(0, "ERROR");
    return;
  }
  if (pgfParser->isToken(node.cat)) {
    QTreeWidgetItem *tokenItem = new QTreeWidgetItem(parentItem);
    QString tokenText = pgfParser->catName(node.cat);
    if (node.data.isValid()) {
      bool isString = (node.data.type() == QVariant::String);
      tokenText.append('(');
      if (isString) tokenText.append('"');
      tokenText.append(node.data.toString().replace('\\',"\\\\")
                                           .replace('"',"\\\""));
      if (isString) tokenText.append('"');
      tokenText.append(')');
    }
    tokenItem->setText(0, tokenText);
    return;
  }
  switch (node.children.size()) {
    case 0: // no alternatives = metavariable
      {
        QTreeWidgetItem *metavariableItem = new QTreeWidgetItem(parentItem);
        metavariableItem->setText(0, '[' + pgfParser->catName(node.cat) + ']');
      }
      break;
    case 1: // 1 alternative, normal tree
      {
        QTreeWidgetItem *functionItem = new QTreeWidgetItem(parentItem);
        QVariant label = node.children.first().label();
        functionItem->setText(0, label.isValid()
                                 ? pgfParser->functionName(label.toInt())
                                 : pgfParser->catName(node.cat));
        foreach (const Node &child, node.children.first())
          generateSyntaxSubtree(child, functionItem);
      }
      break;
    default: // multiple alternatives
      {
        QTreeWidgetItem *alternativesItem = new QTreeWidgetItem(parentItem);
        alternativesItem->setText(0, "ALTERNATIVES");
        foreach (const Alternative &subtree, node.children) {
          QTreeWidgetItem *functionItem = new QTreeWidgetItem(alternativesItem);
          QVariant label = subtree.label();
          functionItem->setText(0, label.isValid()
                                   ? pgfParser->functionName(label.toInt())
                                   : pgfParser->catName(node.cat));
          foreach (const Node &child, subtree)
            generateSyntaxSubtree(child, functionItem);
        }
      }
      break;
  }
}

void MainWindow::generateSyntaxTree()
{
  if (incrementalState.matches.isEmpty()) {
    KMessageBox::error(this, "The input is incomplete. Only complete input can "
                             "be parsed.", "Incomplete Input");
    return;
  }
  // allow going back to predictions with undo
  incrementalHistory.push(incrementalState);
  undoAction->setEnabled(true);
  treeWidget->clear();
  searchLineWidget->searchLine()->clear();
  foreach (const Match &m, incrementalState.matches) {
    Node syntaxTree = parseTreeToPmcfgSyntaxTree(m.tree);
    pgfParser->filterCoercionsFromSyntaxTree(syntaxTree);
    generateSyntaxSubtree(syntaxTree, treeWidget);
  }
  treeWidget->expandAll();
}

void MainWindow::treeWidget_itemActivated(QTreeWidgetItem *item, int column)
{
  int token = item->data(column, Qt::UserRole).toInt();
  if (token) {
    QString tokenText;
    switch (token) {
      case PgfTokenString:
        {
          bool ok = false;
          tokenText = KInputDialog::getText("Formula", "Enter formula:",
                                            QString(), &ok, this);
          if (!incrementalState.buffer.isEmpty()) tokenText.prepend(' ');
          if (!ok) return;
        }
        break;
      case PgfTokenInt:
        {
          bool ok = false;
          tokenText = QString::number(KInputDialog::getInteger("Integer",
                                                               "Enter integer:",
                                                               0, INT_MIN,
                                                               INT_MAX, 1, &ok,
                                                               this));
          if (!incrementalState.buffer.isEmpty()) tokenText.prepend(' ');
          if (!ok) return;
        }
        break;
      case PgfTokenFloat:
        {
          bool ok = false;
          tokenText = QString::number(KInputDialog::getDouble("Floating-point "
                                                              "Number",
                                                              "Enter number:",
                                                              0., DBL_MIN,
                                                              DBL_MAX, 16, &ok,
                                                              this));
          if (!incrementalState.buffer.isEmpty()) tokenText.prepend(' ');
          if (!ok) return;
        }
        break;
      default:
        {
          tokenText = item->text(column);
          QString suffixMarker = PreludeBind;
          suffixMarker.append(' ');
          if (tokenText.startsWith(suffixMarker))
            tokenText.remove(0, suffixMarker.size());
          else {
            unsigned short firstChar = tokenText.at(0).unicode();
            if (incrementalState.buffer.isEmpty()
                || incrementalState.buffer.endsWith('.'))
              tokenText[0] = tokenText.at(0).toUpper();
            if (!incrementalState.buffer.isEmpty()
                && ((firstChar >= 'a' && firstChar <= 'z')
                    || (firstChar >= 'A' && firstChar <= 'Z')
                    || (firstChar >= '0' && firstChar <= '9')
                    || (firstChar >= 128) // non-ASCII UTF-16 character
                    || firstChar == '_' || firstChar == '\''
                    || firstChar == '\\' || firstChar == '-'
                    || firstChar == '$' || firstChar == '`'
                    || firstChar == '('))
              tokenText.prepend(' ');
          }
        }
        break;
    }
    incrementalHistory.push(incrementalState);
    undoAction->setEnabled(true);
    textEdit->insertPlainText(tokenText);
    incrementalState.buffer.append(tokenText.toLocal8Bit());
    predict();
  }
}
