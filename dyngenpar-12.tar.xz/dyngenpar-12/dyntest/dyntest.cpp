/* Dynamic Test for DynGenPar using Serialized Grammars
   Copyright (C) 2015 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#ifndef DYNGENPAR_INTEGER_CATEGORIES
#define DYNGENPAR_INTEGER_CATEGORIES
#endif

#include <QCoreApplication>
#include <QStringList>
#include <QTextStream>
#include <QFile>
#include <QDataStream>

#include "dyngenpar.h"
#include "bytetokensource.h"

using namespace DynGenPar;

static QCoreApplication *app;

int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);
  const QStringList args = app->arguments();

  if (args.size() < 2 || args.size() > 3 || args.at(1) == "--help") {
    QTextStream stream(stderr);
    stream << "Usage: dyntest grammar.ser [infile.txt]\n";
    return 1;
  }

  Cfg cfg;
  {
    QFile f(args.at(1));
    f.open(QIODevice::ReadOnly);
    QDataStream in(&f);
    in >> cfg;
  }

  TextByteTokenSource tokenSource;
  if (args.size() > 2) tokenSource.setInputFile(args.at(2));

  bool accepted = false;

  {
    Parser parser(&tokenSource);
    parser.loadCfg(cfg);
    int errorPos;
    Cat errorToken;
    QList<StackItem> stacks;
    LexerState lexerState;
    QList<Match> matches = parser.parse(&errorPos, &errorToken, 0, &stacks, 0,
                                        &lexerState);
    if (errorPos >= 0) {
      QTextStream stream(stderr);
      TextPosition pos = TextByteTokenSource::textPosition(lexerState);
      stream << "parse error at line " << (pos.line + 1) << " column "
             << (pos.col + 1) << ": unexpected '" << QChar(errorToken) << '\''
             << endl;
      if (stacks.isEmpty())
        stream << "expected: end of input" << endl;
    } else if (matches.isEmpty()) {
      QTextStream stream(stderr);
      stream << "parse error at end of input: incomplete input" << endl;
    } else {
      foreach (const Match &m, matches) {
        Q_UNUSED(m);
        if (accepted)
          qWarning("warning: ignoring extra matches");
        else {
          QTextStream stream(stderr);
          stream << "input parsed successfully" << endl;
          accepted = true;
        }
      }
    }
  }

  delete app;
  return !accepted;
}
