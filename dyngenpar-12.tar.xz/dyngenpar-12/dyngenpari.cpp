/* DynGenPar: Dynamic Generalized Parser - integer version
   Copyright (C) 2010 Kevin Kofler <kevin.kofler@chello.at>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#define DYNGENPAR_INTEGER_CATEGORIES
#include "dyngenpar.cpp"
