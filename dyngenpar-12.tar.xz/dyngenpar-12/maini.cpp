/* DynGenPar: Dynamic Generalized Parser - Main program for testing purposes
   Copyright (C) 2010-2011 Kevin Kofler <kevin.kofler@chello.at>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#define DYNGENPAR_INTEGER_CATEGORIES

#include <QCoreApplication>
#include <QTextStream>
#include <QStringList>
#include <cstdio>
#include "dyngenpar.h"

using namespace DynGenPar;

static QCoreApplication *app;

// printing functions for test main function
static QStringList categoryNames;

static void printSubtree(const Node &node, int level, QTextStream &stream) {
  for (int i=0; i<level; i++) stream << ' ';
  stream << categoryNames.at(node.cat) << endl;
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      for (int i=0; i<=level; i++) stream << ' ';
      stream << "ERROR" << endl;
      break;
    case 1: // 1 alternative, normal tree
      foreach (const Node &child, node.children.first())
        printSubtree(child, level+1, stream);
      break;
    default: // multiple alternatives
      foreach (const Alternative &subtree, node.children) {
        for (int i=0; i<=level; i++) stream << ' ';
        stream << "ALTERNATIVE" << endl;
        foreach (const Node &child, subtree)
          printSubtree(child, level+2, stream);
      }
      break;
  }
}

static void printParseTree(const Node &tree) {
  QTextStream stream(stdout);
  printSubtree(tree, 0, stream);
}

#if 0
static void printPredictions(const Predictions &predictions,
                             const Parser &parser)
{
  QTextStream stream(stdout);
  foreach (CatArg prediction, predictions) {
    stream << "Prediction: " << categoryNames.at(prediction) << endl;
    if (!parser.isToken(prediction)) {
      QHash<Cat, QSet<Cat> > expandedPrediction
       = parser.expandNonterminalPrediction(prediction);
      QHashIterator<Cat, QSet<Cat> > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " Predicted category: " << categoryNames.at(cat) << endl;
        foreach (CatArg token, it.value())
          stream << "  Predicted token: " << categoryNames.at(token) << endl;
      }
    }
  }
}
#endif

static void printMultiPredictions(const MultiPredictions &predictions,
                                  const Parser &parser)
{
  QTextStream stream(stdout);
  QHashIterator<QList<Cat>, MultiPrediction> it(predictions);
  while (it.hasNext()) {
    it.next();
    QList<Cat> key = it.key();
    if (parser.isLiteral(key)) {
      stream << "Prediction: ";
      foreach(CatArg token, key) stream << categoryNames.at(token);
      stream << endl;
      stream << " Completes: ";
      foreach(CatArg token, it.value().fullLiteral)
        stream << categoryNames.at(token);
      stream << endl;
      stream << " For category: " << categoryNames.at(it.value().cat) << endl;
    } else {
      Cat prediction = key.first();
      stream << "Prediction: " << categoryNames.at(prediction) << endl;
      QHash<Cat, QSet<QList<Cat> > > expandedPrediction
        = parser.expandNonterminalPredictionMulti(prediction);
      QHashIterator<Cat, QSet<QList<Cat> > > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " Predicted category: " << categoryNames.at(cat) << endl;
        foreach (const QList<Cat> &literal, it.value()) {
          stream << "  Predicted literal: ";
          foreach (CatArg token, literal) stream << categoryNames.at(token);
          stream << endl;
        }
      }
    }
  }
}

// main function for testing purposes
int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);
  bool accepted = false;

  categoryNames << "EPSILON" << "a" << "b" << "c" << "S" << "A";

  {
    ListTokenSource tokenSource;
    Parser parser(&tokenSource);

    // initialize testcase
    parser.tokens << 1 << 2 << 3;
    parser.rules[4] << (Rule() << 5)
                    << (Rule() << 5 << 4);
    parser.rules[5] << (Rule() << 1)
                    << (Rule() << 2)
                    << (Rule() << 3);
    tokenSource.inputTokens << 2 << 1;
    parser.startCat = 4;

    parser.initCaches();

    // parse, also testing incremental parsing and prediction
    int incrementalPos = -1; // must init to a negative integer
    QList<StackItem> incrementalStacks;
    QList<Match> matches = parser.parse(0, 0, &incrementalPos,
                                        &incrementalStacks);
    foreach (const Match &m, matches) {
      if (m.len != tokenSource.inputTokens.size())
        qFatal("invalid match (wrong length)");
      accepted = true;
      printParseTree(m.tree);
    }
    printMultiPredictions(parser.computeMultiPredictions(incrementalStacks),
                          parser);

    if (accepted) {
      // incrementally add the token 3
      accepted = false;
      tokenSource.inputTokens << 3;
      QList<Match> matches = parser.parse(0, 0, &incrementalPos,
                                          &incrementalStacks);
      foreach (const Match &m, matches) {
        if (m.len != tokenSource.inputTokens.size())
          qFatal("invalid match (wrong length)");
        accepted = true;
        printParseTree(m.tree);
      }
    }
  }

  delete app;
  return !accepted;
}
