/* Export Optimization Problems as text-based COCONUT DAGs
   Copyright (C) 2013 Kevin Kofler <kevin.kofler@chello.at>

   Support by the Austrian Science Fund FWF under contract number P22239
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include <QTextStream>
#include <QTextCodec>
#include <QFile>
#include <QHash>
#include <cstdio>
#include "optprobl.h"

using DynGenPar::Node;
using DynGenPar::Alternative;

/* In order to ensure reentrancy, we use a class to store global state in. The
   class is private to this file. */
namespace {
  class DagExporter {
    public:
      DagExporter() : nVariables(0), nConstraints(0), currNode(0) {}
      void printDag(const Node &node, QTextStream &stream);
    private:
      void collectVariables(const Node &node);
      int printExpr(const Node &node, QTextStream &stream);
      void printConstraint(const Node &node, QTextStream &stream);
      void printConstraints(const Node &node, QTextStream &stream);
      QHash<QString, int> variables;
      QStringList varNames;
      int nVariables;
      int nConstraints;
      int currNode;
  };

  void DagExporter::collectVariables(const Node& node)
  {
    if (node.cat == Var) {
      QString varName = node.data.toString();
      if (!variables.contains(varName)) {
        variables.insert(varName, nVariables++);
        varNames.append(varName);
      }
    }
    foreach (const Alternative &alternative, node.children)
      foreach (const Node &child, alternative)
        collectVariables(child);
  }

  int DagExporter::printExpr(const Node& node, QTextStream &stream)
  {
    int id = currNode++;
    stream << '<' << id << "> ";
    switch (node.cat) {
      case Var:
        {
          QString varName = node.data.toString();
          int varId = variables.value(varName);
          stream << "V " << varId << endl;
        }
        break;
      case PosNum:
        stream << "C " << node.data.toString() << endl;
        break;
      case Interval:
        qFatal("intervals in expressions not supported");
        break;
      // binary operators
      case CaretExpr:
      case TimesExpr:
      case DivExpr:
      case PlusExpr:
      case MinusExpr:
        {
          switch (node.cat) {
            case CaretExpr:
              stream << "^" << endl;
              break;
            case TimesExpr:
              stream << "*" << endl;
              break;
            case DivExpr:
              stream << "/" << endl;
              break;
            default:
              stream << "+" << endl;
              break;
          }
          int op1 = printExpr(node.children.first().first(), stream);
          int op2 = printExpr(node.children.first().at(1), stream);
          stream << "<E> " << id << ' ' << op1 << " 1" << endl;
          stream << "<E> " << id << ' ' << op2
                << ((node.cat == MinusExpr) ? " -1" : " 1") << endl;
        }
        break;
      // unary operator
      case UnaryMinusExpr:
        {
          stream << "+" << endl;
          int op1 = printExpr(node.children.first().first(), stream);
          stream << "<E> " << id << ' ' << op1 << " -1" << endl;
        }
        break;
      default:
        qFatal("unknown expression node");
    };
    return id;
  }

  void DagExporter::printConstraint(const Node& node, QTextStream& stream)
  {
    int id = currNode++;
    stream << '<' << id << "> ";
    bool needNegation = false;
    bool isBound = false;
    if (node.children.first().count() == 2) {
      // set constraint
      isBound = (node.children.first().first().cat == Var);
      Node intervalNode = node.children.first().at(1).children.first().first();
      Node lowerNode = intervalNode.children.first().first();
      QString lower = (lowerNode.cat == NegNum)
        ? ("-" + lowerNode.children.first().first().data.toString())
        : lowerNode.data.toString();
      Node upperNode = intervalNode.children.first().at(1);
      QString upper = (upperNode.cat == NegNum)
        ? ("-" + upperNode.children.first().first().data.toString())
        : upperNode.data.toString();
      if (isBound) {
        QString varName = node.children.first().first().data.toString();
        int varId = variables.value(varName);
        stream << "b [" << lower << ',' << upper << "]: V " << varId << endl;
      } else {
        stream << "i [" << lower << ',' << upper << "]: in" << endl;
        int op1 = printExpr(node.children.first().first(), stream);
        stream << "<E> " << id << ' ' << op1 << " 1" << endl;
      }
    } else {
      // relation constraint
      /* We could output fake relation operations and let the DAG import handle
         it, but it is probably nicer to output the actual internal
         representation, so we will do that here. */
      switch (node.children.first().at(1).cat) {
        case Neq:
          needNegation = true;
          // fall through
        case Eq:
          stream << "i [0,0]: in" << endl;
          break;
        case Lt:
          needNegation = true;
          // fall through
        case Geq:
          stream << "i [0,I]: in" << endl;
          break;
        case Gt:
          needNegation = true;
          // fall through
        case Leq:
          stream << "i [-I,0]: in" << endl;
          break;
        default:
          qFatal("unknown relation node");
      }
      int diffId = currNode++;
      stream << '<' << diffId << "> +" << endl;
      int op1 = printExpr(node.children.first().first(), stream);
      int op2 = printExpr(node.children.first().at(2), stream);
      stream << "<E> " << diffId << ' ' << op1 << " 1" << endl;
      stream << "<E> " << diffId << ' ' << op2 << " -1" << endl;
      stream << "<E> " << id << ' ' << diffId << " 1" << endl;
    }
    if (needNegation) {
      int notId = currNode++;
      stream << '<' << notId << "> not" << endl
             << "<E> " << notId << ' ' << id << " 1" << endl;
      id = notId;
    }
    if (!isBound) {
      int cid = nConstraints++;
      stream << "<N> c " << cid << ' ' << id << endl;
    }
  }

  void DagExporter::printConstraints(const Node& node, QTextStream& stream)
  {
    if (node.children.first().count() > 1) {
      printConstraints(node.children.first().first(), stream);
      printConstraint(node.children.first().at(1), stream);
    } else
      printConstraint(node.children.first().first(), stream);
  }

  void DagExporter::printDag(const Node &node, QTextStream &stream)
  {
    collectVariables(node);
    stream << "<N> V " << nVariables << endl;
    Node objNode = node.children.first().first();
    int objId = printExpr(objNode.children.first().at(1), stream);
    stream << "<N> M " << objId
                       << ((objNode.children.first().first().cat == Max)
                           ? " max"
                           : " min")
                       << endl;
    if (node.children.first().count() > 1)
      printConstraints(node.children.first().at(1), stream);
    for (int i = 0; i < nVariables; i++)
      stream << "<N> N " << i << " '" << varNames[i] << '\'' << endl;
    for (int i = 0; i < nConstraints; i++)
      stream << "<N> C " << i << " 'c" << i << '\'' << endl;
    stream << "<N> O 'obj'" << endl;
  }
}

void exportDag(const Node &tree, const QString &fileName)
{
  DagExporter exporter;
  if (fileName.isEmpty()) {
    QTextStream stream(stdout);
    exporter.printDag(tree, stream);
  } else {
    QFile file(fileName);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&file);
    exporter.printDag(tree, stream);
  }
}
