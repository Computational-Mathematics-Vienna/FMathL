/* Parser for Optimization Problems for COCONUT based on DynGenPar
   Copyright (C) 2013 Kevin Kofler <kevin.kofler@chello.at>

   Support by the Austrian Science Fund FWF under contract number P22239
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include <QCoreApplication>
#include <QTextStream>
#include <QTextCodec>
#include <QFile>
#include <cstdio>
#include "optprobl.h"
#include "dagexport.h"

using namespace DynGenPar;

static QCoreApplication *app;

QStringList categoryNames;

#define OUTPUT_DEBUG_TREE

#ifdef OUTPUT_DEBUG_TREE
/* Printing functions for testing purposes */
static void printLabel(const QVariant &label, QTextStream &stream)
{
  if (!label.isNull())
    stream << " (rule #" << label.toInt() << ')';
}

static void printData(const QVariant &data, QTextStream &stream)
{
  if (!data.isNull())
    stream << " \"" << data.toString() << '"';
}

static void printSubtree(const Node &node, int level, QTextStream &stream)
{
  for (int i=0; i<level; i++) stream << ' ';
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      stream << " ERROR" << endl;
      break;
    case 1: // 1 alternative, normal tree
      stream << categoryNames.at(node.cat);
      printData(node.data, stream);
      printLabel(node.children.first().label(), stream);
      stream << endl;
      foreach (const Node &child, node.children.first())
        printSubtree(child, level+1, stream);
      break;
    default: // multiple alternatives
      stream << categoryNames.at(node.cat);
      printData(node.data, stream);
      stream << endl;
      foreach (const DynGenPar::Alternative &alternative, node.children) {
        for (int i=0; i<=level; i++) stream << ' ';
        stream << "ALTERNATIVE";
        printLabel(alternative.label(), stream);
        stream << endl;
        foreach (const Node &child, alternative)
          printSubtree(child, level+2, stream);
      }
      break;
  }
}

static void printParseTree(const Node &tree, const QString &fileName)
{
  if (fileName.isEmpty()) {
    QTextStream stream(stderr);
    printSubtree(tree, 0, stream);
  } else {
    QFile file(fileName);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&file);
    printSubtree(tree, 0, stream);
  }
}
#endif

static void printPredictions(const ConstrainedMultiPredictions &predictions,
                             Parser &parser)
{
  QTextStream stream(stderr);
  QHashIterator<QList<Cat>, ConstrainedMultiPrediction> it(predictions);
  while (it.hasNext()) {
    it.next();
    QList<Cat> key = it.key();
    if (parser.isLiteral(key)) {
      stream << "expected: ";
      foreach(CatArg token, key) stream << categoryNames.at(token);
      stream << endl;
      stream << " completes: ";
      foreach(CatArg token, it.value().fullLiteral)
        stream << categoryNames.at(token);
      stream << endl;
      stream << " in: " << categoryNames.at(it.value().cat) << endl;
    } else {
      Cat prediction = key.first();
      stream << "expected: " << categoryNames.at(prediction) << endl;
      QHash<Cat, QSet<QList<Cat> > > expandedPrediction
        = parser.expandNonterminalPredictionMultiC(prediction,
            it.value().nextTokenConstraints);
      QHashIterator<Cat, QSet<QList<Cat> > > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " expected category: " << categoryNames.at(cat) << endl;
        foreach (const QList<Cat> &literal, it.value()) {
          stream << "  expected literal: ";
          foreach (CatArg token, literal) stream << categoryNames.at(token);
          stream << endl;
        }
      }
    }
  }
}

int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);
  QStringList args = app->arguments();
  bool accepted = false;

  {
    OptProblParser optProblParser;
#ifdef OUTPUT_DEBUG_TREE
    QString debugOutputFile, debugOutputFileAST;
#endif
    QString dagOutputFile;
    if (args.size() > 1) {
      optProblParser.setInputFile(args[1]);
#ifdef OUTPUT_DEBUG_TREE
      debugOutputFile = args[1] + ".tree";
      debugOutputFileAST = args[1] + ".ast";
#endif
      dagOutputFile = args[1] + ".dag";
    }
    int errorPos;
    Cat errorToken;
    QList<StackItem> stacks;
    LexerState lexerState;
    QList<Match> matches = optProblParser.parse(&errorPos, &errorToken, 0,
                                                &stacks, 0, &lexerState);
    categoryNames = optProblParser.categoryNames;
    if (errorPos >= 0) {
      QTextStream stream(stderr);
      TextPosition pos = TextByteTokenSource::textPosition(lexerState);
      stream << "parse error at line " << (pos.line + 1) << " column "
             << (pos.col + 1) << ": unexpected " << categoryNames.at(errorToken)
             << endl;
      if (stacks.isEmpty())
        stream << "expected: end of input" << endl;
      else
        printPredictions(
          optProblParser.computeConstrainedMultiPredictions(stacks),
          optProblParser);
    } else if (matches.isEmpty()) {
      {
        QTextStream stream(stderr);
        stream << "parse error at end of input: incomplete input" << endl;
      }
      printPredictions(
        optProblParser.computeConstrainedMultiPredictions(stacks),
        optProblParser);
    } else {
      foreach (const Match &m, matches) {
        if (accepted) {
          qWarning("warning: ignoring extra matches");
        } else {
          accepted = true;
#ifdef OUTPUT_DEBUG_TREE
          printParseTree(m.tree, debugOutputFile);
#endif
          Node ast = optProblParser.parseTreeToSyntaxTree(m.tree);
#ifdef OUTPUT_DEBUG_TREE
          printParseTree(ast, debugOutputFileAST);
#endif
          exportDag(ast, dagOutputFile);
        }
      }
    }
  }

  delete app;
  return !accepted;
}
