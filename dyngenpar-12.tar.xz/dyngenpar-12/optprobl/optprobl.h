/* Parser for Optimization Problems for COCONUT based on DynGenPar
   Copyright (C) 2013 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P22239
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#pragma once

#ifndef DYNGENPAR_INTEGER_CATEGORIES
#define DYNGENPAR_INTEGER_CATEGORIES
#endif

#include "dyngenpar.h"
#include "bytetokensource.h"

#include <QStringList>

// nonterminals only, tokens are defined in ByteTokens
enum Cats {
  Whitespace = 258,
  Whitespace1,
  Letter,
  Digit,
  WordChar,
  WordChars,
  TagEndTaboo,
  TagEnd,
  Expr,
  BracketedExpr,
  Var,
  NumChar,
  NumChars,
  PosNum,
  NegNum,
  Num,
  Interval,
  Placeholder,
  AtomicExpr,
  CaretExpr,
  PowerExpr,
  TimesExpr,
  DivExpr,
  ProductExpr,
  PlusExpr,
  MinusExpr,
  UnaryMinusExpr,
  Min,
  Max,
  Goal,
  Objective,
  Set,
  Eq,
  Gt,
  Lt,
  Geq,
  Leq,
  Neq,
  Relation,
  Constraint,
  Constraints,
  NewCommand,
  NewCommands,
  OptProbl
};
Q_DECLARE_TYPEINFO(Cats, Q_PRIMITIVE_TYPE);


inline QStringList staticCategoryNames() {
  QStringList result;

  // dummy category
  result << "EPSILON"

  // tokens
  << "SOH" << "STX" << "ETX" << "EOT" << "ENQ" << "ACK" << "BEL" << "BS" << "HT"
  << "LF" << "VT" << "FF" << "CR" << "SO" << "SI" << "DLE" << "DC1" << "DC2"
  << "DC3" << "DC4" << "NAK" << "SYN" << "ETB" << "CAN" << "EM" << "SUB"
  << "ESC" << "FS" << "GS" << "RS" << "US" << "SP";
  for (int i=33; i<127; i++) result << QChar(i);
  result << "DEL";
  for (int i=128; i<256; i++) result << ("\\x" + QString::number(i, 16));
  result << "NUL"

  // dummy category
  << "ERROR"

  // nonterminals
  << "Whitespace"
  << "Whitespace1"
  << "Letter"
  << "Digit"
  << "WordChar"
  << "WordChars"
  << "TagEndTaboo"
  << "TagEnd"
  << "Expr"
  << "BracketedExpr"
  << "Var"
  << "NumChar"
  << "NumChars"
  << "PosNum"
  << "NegNum"
  << "Num"
  << "Interval"
  << "Placeholder"
  << "AtomicExpr"
  << "CaretExpr"
  << "PowerExpr"
  << "TimesExpr"
  << "DivExpr"
  << "ProductExpr"
  << "PlusExpr"
  << "MinusExpr"
  << "UnaryMinusExpr"
  << "Min"
  << "Max"
  << "Goal"
  << "Objective"
  << "Set"
  << "Eq"
  << "Gt"
  << "Lt"
  << "Geq"
  << "Leq"
  << "Neq"
  << "Relation"
  << "Constraint"
  << "Constraints"
  << "NewCommand"
  << "NewCommands"
  << "OptProbl";

  return result;
}

class OptProblParser : public DynGenPar::Parser {
  private:
    class NewCommandAction;
    friend class NewCommandAction;
  public:
    OptProblParser() : Parser(new DynGenPar::TextByteTokenSource),
                       categoryNames(staticCategoryNames()),
                       currentDynamicRule(FIRST_DYNAMIC_RULE),
                       newCommandAction(new NewCommandAction(this)) {init();}
    OptProblParser(const QString &fileName)
      : Parser(new DynGenPar::TextByteTokenSource(fileName)),
        categoryNames(staticCategoryNames()),
        currentDynamicRule(FIRST_DYNAMIC_RULE),
        newCommandAction(new NewCommandAction(this)) {init();}
    virtual ~OptProblParser() {
      delete inputSource;
      delete newCommandAction;
    }
    void setInputFile(const QString &fileName) {
      static_cast<DynGenPar::TextByteTokenSource *>(inputSource)
        ->setInputFile(fileName);
    }
    QStringList categoryNames;
    DynGenPar::Node parseTreeToSyntaxTree(const DynGenPar::Node &tree) const;
  private:
    void init();
    static const int FIRST_DYNAMIC_RULE = 1000;
    int currentDynamicRule;
    class NewCommandAction : public DynGenPar::Action {
      public:
        NewCommandAction(OptProblParser *p) : parent(p) {}
        virtual void execute (const DynGenPar::ActionInfo& info);
      private:
        OptProblParser *parent;
    };
    NewCommandAction *newCommandAction;
    QHash<DynGenPar::Cat, DynGenPar::Node> newCommandTrees;
    void collectCharLeaves(const DynGenPar::Node &tree, QString &leaves) const;
    DynGenPar::Node replacePlaceholders(const DynGenPar::Node &placeholderExpr,
      const DynGenPar::Node &commandExpr) const;
};
Q_DECLARE_TYPEINFO(OptProblParser, Q_MOVABLE_TYPE);
