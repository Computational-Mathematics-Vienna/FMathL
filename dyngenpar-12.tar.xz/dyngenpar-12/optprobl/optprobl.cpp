/* Parser for Optimization Problems for COCONUT based on DynGenPar
   Copyright (C) 2013 Kevin Kofler <kevin.kofler@chello.at>

   Support by the Austrian Science Fund FWF under contract number P22239
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include "optprobl.h"

using DynGenPar::Rule;
using DynGenPar::Node;
using DynGenPar::Cat;
using DynGenPar::Alternative;

void OptProblParser::init()
{
  for (int i=1; i<257; i++) tokens << i;

  rules[Whitespace] << (Rule(1))
                    << (Rule(2) << Whitespace << Whitespace1);

  rules[Whitespace1] << (Rule(3) << ' ')
                     << (Rule(4) << '\\' << '\\')
                     << (Rule(5) << '\n');

  QList<Rule> &letterRules = rules[Letter];
  for (int i=0; i<26; i++) letterRules << (Rule(6+i) << ('A'+i));
  for (int i=0; i<26; i++) letterRules << (Rule(32+i) << ('a'+i));
  // rules 6 ... 58

  QList<Rule> &digitRules = rules[Digit];
  for (int i=0; i<10; i++) digitRules << (Rule(59+i) << ('0'+i));
  // rules 59 ... 68

  rules[WordChar] << (Rule(69) << Letter)
                  << (Rule(70) << Digit);

  rules[WordChars] << (Rule(131) << WordChar)
                   << (Rule(132) << WordChar << WordChars);

  rules[TagEndTaboo] << (Rule(71) << WordChar)
                     << (Rule(72) << ' ');

  Rule rule73(73);
  rule73.nextTokenConstraints.taboo << TagEndTaboo;
  rules[TagEnd] << rule73
                << (Rule(74) << ' ');

  rules[BracketedExpr] << (Rule(75) << '(' << Whitespace << Expr << Whitespace
                                    << ')');

  rules[Var] << (Rule(76) << Letter)
             << (Rule(77) << '\\' << 'l' << 'a' << 'm' << 'b' << 'd' << 'a'
                          << TagEnd);

  rules[NumChar] << (Rule(78) << Digit)
                 << (Rule(79) << '.');

  rules[NumChars] << (Rule(80) << NumChar)
                  << (Rule(81) << NumChar << NumChars);

  rules[PosNum] << (Rule(82) << NumChars)
                << (Rule(83) << NumChars << 'e' << NumChars)
                << (Rule(84) << NumChars << 'e' << '-' << NumChars);

  rules[NegNum] << (Rule(118) << '-' << Whitespace << PosNum);

  rules[Num] << (Rule(109) << PosNum)
             << (Rule(110) << NegNum);

  rules[Interval] << (Rule(111) << '[' << Whitespace << Num << Whitespace << ','
                                << Whitespace << Num << Whitespace << ']');

  rules[Placeholder] << (Rule(138) << '#' << Digit);

  rules[AtomicExpr] << (Rule(85) << BracketedExpr)
                    << (Rule(86) << Var)
                    << (Rule(87) << PosNum)
                    << (Rule(112) << Interval)
                    << (Rule(137) << Placeholder);

  rules[CaretExpr] << (Rule(88) << PowerExpr << Whitespace << '^' << '{'
                                << Whitespace << Expr << Whitespace << '}');

  rules[PowerExpr] << (Rule(89) << AtomicExpr)
                   << (Rule(90) << CaretExpr);

  rules[TimesExpr] << (Rule(91) << ProductExpr << Whitespace << '*'
                                << Whitespace << PowerExpr);

  rules[DivExpr] << (Rule(92) << ProductExpr << Whitespace << '/'
                              << Whitespace << PowerExpr);

  rules[ProductExpr] << (Rule(93) << PowerExpr)
                     << (Rule(94) << TimesExpr)
                     << (Rule(95) << DivExpr);

  rules[PlusExpr] << (Rule(96) << Expr << Whitespace << '+'
                               << Whitespace << ProductExpr);

  rules[MinusExpr] << (Rule(97) << Expr << Whitespace << '-'
                                << Whitespace << ProductExpr);

  rules[UnaryMinusExpr] << (Rule(98) << '-' << Whitespace << ProductExpr);

  rules[Expr] << (Rule(99) << ProductExpr)
              << (Rule(100) << PlusExpr)
              << (Rule(101) << MinusExpr)
              << (Rule(102) << UnaryMinusExpr);

  rules[Min] << (Rule(103) << '\\' << 'm' << 'i' << 'n' << TagEnd);

  rules[Max] << (Rule(104) << '\\' << 'm' << 'a' << 'x' << TagEnd);

  rules[Goal] << (Rule(105) << Min)
              << (Rule(106) << Max);

  rules[Objective] << (Rule(107) << Goal << Whitespace << Expr);

  rules[Set] << (Rule(113) << Interval);

  rules[Eq] << (Rule(118) << '=');

  rules[Gt] << (Rule(119) << '>');

  rules[Lt] << (Rule(120) << '<');

  rules[Geq] << (Rule(121) << '\\' << 'g' << 'e' << 'q' << TagEnd);

  rules[Leq] << (Rule(122) << '\\' << 'l' << 'e' << 'q' << TagEnd);

  rules[Neq] << (Rule(123) << '\\' << 'n' << 'e' << 'q' << TagEnd);

  rules[Relation] << (Rule(124) << Eq)
                  << (Rule(125) << Gt)
                  << (Rule(126) << Lt)
                  << (Rule(127) << Geq)
                  << (Rule(128) << Leq)
                  << (Rule(129) << Neq);

  Rule rule133(133);
  rule133 << '\\' << 'n' << 'e' << 'w' << 'c' << 'o' << 'm' << 'm' << 'a' << 'n'
          << 'd' << '{' << WordChars << '}' << '[' << Digit << ']' << '{'
          << '}';
  rule133.action = newCommandAction;
  Rule rule136(136);
  rule136 << '\\' << 'n' << 'e' << 'w' << 'c' << 'o' << 'm' << 'm' << 'a' << 'n'
          << 'd' << '{' << WordChars << '}' << '[' << Digit << ']' << '{'
          << Whitespace << Expr << Whitespace << '}';
  rule136.action = newCommandAction;
  rules[NewCommand] << rule133 << rule136;

  rules[NewCommands] << Rule(134)
                     << (Rule(135) << NewCommand << Whitespace << NewCommands);

  rules[Constraint] << (Rule(114) << Expr << Whitespace << '\\' << 'i' << 'n'
                        << TagEnd << Whitespace << Set)
                    << (Rule(130) << Expr << Whitespace << Relation
                                  << Whitespace << Expr);

  rules[Constraints] << (Rule(115) << Constraint)
                     << (Rule(116) << Constraints << Whitespace << ','
                                   << Whitespace << Constraint);

  rules[OptProbl] << (Rule(108) << Whitespace << NewCommands << Objective
                                << Whitespace)
                  << (Rule(117) << Whitespace << NewCommands << Objective
                                << Whitespace << '\\' << 's' << 't' << TagEnd
                                << Whitespace << Constraints << Whitespace);

  startCat = OptProbl;

  initCaches();
}

void OptProblParser::NewCommandAction::execute(
  const DynGenPar::ActionInfo& info)
{
  Node tree = info.tree;
  QList<Node> children = tree.children.first();
  Node wordChars = children.at(12);
  Node digit = children.at(15);
  Cat newCat = parent->currentDynamicRule++;
  Rule newRule(newCat);
  newRule << '\\';
  QString newCatName = "Command_";
  while (true) {
    QList<Node> wordCharsChildren = wordChars.children.first();
    Cat wordChar = wordCharsChildren.first().children.first().first()
                                            .children.first().first().cat;
    newRule << wordChar;
    newCatName.append(QChar(wordChar));
    if (wordCharsChildren.size() < 2) break;
    wordChars = wordCharsChildren.at(1);
  }
  int numArgs = digit.children.first().first().cat - '0';
  if (numArgs) {
    for (int i=0; i<numArgs; i++) {
      newRule << '{' << Whitespace << Expr << Whitespace << '}';
    }
  } else newRule << TagEnd;
  parent->addRule(newCat, newRule);
  if (parent->categoryNames.length() <= newCat) {
    parent->categoryNames.reserve(newCat + 1);
    int nMissing = newCat + 1 - parent->categoryNames.length();
    for (int i=0; i<nMissing; i++) parent->categoryNames.append(QString());
  }
  parent->categoryNames[newCat] = newCatName;
  Rule exprRule(parent->currentDynamicRule++);
  exprRule << newCat;
  parent->addRule(AtomicExpr, exprRule);
  if (children.count() > 19) {
    Node expr = children.at(19);
    parent->newCommandTrees.insert(newCat, parent->parseTreeToSyntaxTree(expr));
  }
}

void OptProblParser::collectCharLeaves(const Node &tree, QString &leaves) const
{
  if (isToken(tree.cat)) {
    if (tree.cat >= 32 && tree.cat < 128)
      leaves.append((QChar) tree.cat);
  } else {
    // consider only the first alternative - they must all match the same tokens
    foreach (const Node &node, tree.children.first())
      collectCharLeaves(node, leaves);
  }
}

Node OptProblParser::replacePlaceholders(const Node& placeholderExpr,
                                         const Node& commandExpr) const
{
  Node result = placeholderExpr;
  if (result.cat == Placeholder)
    result = commandExpr.children.first().at(result.data.toInt() - 1);
  else {
    int nAlternatives = result.children.count();
    for (int iAlternative = 0; iAlternative < nAlternatives; iAlternative++) {
      Alternative &alternative = result.children[iAlternative];
      int nChildren = alternative.count();
      for (int iChild = 0; iChild < nChildren; iChild++) {
        Node &child = alternative[iChild];
        child = replacePlaceholders(child, commandExpr);
      }
    }
  }
  return result;
}


Node OptProblParser::parseTreeToSyntaxTree(const Node& tree) const
{
  Node result = tree;
  switch (result.cat) {
    case Var:
    case PosNum:
      {
        QString charLeaves;
        collectCharLeaves(result, charLeaves);
        int nAlternatives = result.children.count();
        for (int iAlternative = nAlternatives - 1; iAlternative > 0;
             iAlternative--)
          result.children.removeAt(iAlternative);
        result.children.first().clear();
        result.data = charLeaves;
      }
      break;
    case Expr:
    case PowerExpr:
    case ProductExpr:
    case AtomicExpr:
    case Num:
      result = parseTreeToSyntaxTree(result.children.first().first());
      break;
    case BracketedExpr:
      result = parseTreeToSyntaxTree(result.children.first().at(2));
      break;
    case Placeholder:
      {
        int digit = result.children.first().at(1).children.first().first().cat
                    - '0';
        int nAlternatives = result.children.count();
        for (int iAlternative = nAlternatives - 1; iAlternative > 0;
             iAlternative--)
          result.children.removeAt(iAlternative);
        result.children.first().clear();
        result.data = digit;
      }
      break;
    default:
      int nAlternatives = result.children.count();
      for (int iAlternative = 0; iAlternative < nAlternatives; iAlternative++) {
        Alternative &alternative = result.children[iAlternative];
        int nChildren = alternative.count();
        for (int iChild = 0; iChild < nChildren; iChild++) {
          Node &child = alternative[iChild];
          switch (child.cat) {
            case 1 ... 256:
              if (result.cat == Letter || result.cat == Digit
                  || result.cat == NumChar)
                break;
              // else fall through
            case Whitespace:
            case Whitespace1:
            case TagEnd:
            case TagEndTaboo:
            case NewCommands:
            case NewCommand:
              alternative.removeAt(iChild--);
              nChildren--;
              break;
            default:
              child = parseTreeToSyntaxTree(child);
              break;
          }
        }
      }
      if (result.cat >= FIRST_DYNAMIC_RULE
          && newCommandTrees.contains(result.cat))
        result = replacePlaceholders(newCommandTrees.value(result.cat), result);
      break;
  }
  return result;
}
