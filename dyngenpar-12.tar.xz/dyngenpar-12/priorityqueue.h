/* DynGenPar: Dynamic Generalized Parser: Priority Queue Abstraction
   Copyright (C) 2015 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#pragma once

#include <QSharedData>

// for std::priority_queue
#include <queue>
#include <vector>

namespace DynGenPar {
  namespace Private {

    /// Data class for the PriorityQueue abstraction.
    template<typename T> class PriorityQueueData
      : public QSharedData, public std::priority_queue<T> {
      public:
        PriorityQueueData() : QSharedData(), std::priority_queue<T>() {}
        template<typename List> PriorityQueueData(const List &list)
          : QSharedData(),
            std::priority_queue<T>(list.constBegin(), list.constEnd()) {}
    };

    /// Implicitly-shared wrapper around std::priority_queue. Also renames the
    /// methods to a more Qt-like naming convention (matching QQueue).
    template<typename T> class PriorityQueue {
      public:
        /// Constructs a null (empty) PriorityQueue.
        PriorityQueue() : d() {}
        /// Constructs a PriorityQueue filled with the contents of @a list.
        template<typename List> PriorityQueue(const List &list)
          : d(new PriorityQueueData<T>(list)) {}
        /// Returns @c true if the queue is null (default-constructed).
        bool isNull() const { return !d.constData(); }
        /// Returns @c true if the queue is empty (including when it is null).
        bool isEmpty() const { return isNull() || d->empty(); }
        /// Returns the number of entries in the queue.
        int size() const { return isNull() ? 0 : d->size(); }
        /// Returns a reference to the first element without removing it.
        const T& head() const { return d->top(); }
        /// Adds the item @a item to the queue at the position determined by its
        /// priority.
        void enqueue(const T &item) {
          if (isNull()) d = new PriorityQueueData<T>;
          d->push(item);
        }
        /// Removes the first element from the queue and returns a copy of it.
        T dequeue() {
          T item = d->top();
          d->pop();
          return item;
        }
        /// Removes the first element from the queue without copying it.
        void removeFirst() {d->pop();}

      private:
        QSharedDataPointer<PriorityQueueData<T> > d;
    };
  } // end namespace
} // end namespace
