/* DynGenPar: Dynamic Generalized Parser
   Copyright (C) 2015-2018 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

package concise.DynGenPar.java;

import concise.DynGenPar.ActionDeserializer;
import concise.DynGenPar.Action;
import org.qtjambi.qt.core.QDataStream;
import java.io.ObjectInputStream;
import java.io.InputStream;
import java.io.IOException;

/**
 *  This class is a helper class (package-private) implementing the
 *  deserialization for ExternalizableAction.
 */

class ExternalizableActionDeserializer extends ActionDeserializer {
  @Override
  public Action readAction(final QDataStream stream) {
    try {
      ObjectInputStream ois = new ObjectInputStream(new InputStream() {
        @Override
        public int read() throws IOException {
          if (stream.atEnd()) return -1;
          int result = stream.readByte();
          switch (stream.status()) {
            case Ok:
              return result >= 0 ? result : result + 256;
            case ReadPastEnd:
              return -1;
            case ReadCorruptData:
              throw new IOException("QDataStream read corrupt data");
            case WriteFailed:
              throw new IOException("QDataStream read failed");
            default:
              throw new IOException("QDataStream unknown error");
          }
        }
      });
      return (Action) ois.readObject();
    } catch (IOException e) {
      stream.setStatus(QDataStream.Status.ReadCorruptData);
      return null;
    } catch (ClassNotFoundException e) {
      stream.setStatus(QDataStream.Status.ReadCorruptData);
      return null;
    }
  }
}
