
QT -= gui
TARGET = concise_DynGenPar
VERSION = $$QT_VERSION

QMAKE_CXXFLAGS_DEBUG += -DDYNGENPAR_INTEGER_CATEGORIES
QMAKE_CXXFLAGS_RELEASE += -DDYNGENPAR_INTEGER_CATEGORIES

DESTDIR = ../target

SOURCES += $(DYNGENPARDIR)/dyngenpar.cpp $(DYNGENPARDIR)/pgf.cpp
INCLUDEPATH += $$PWD $(DYNGENPARDIR)

include($(JAMBIDIR)/src/cpp/qtjambi/qtjambi_include.pri)
include(../cpp/concise_DynGenPar/concise_DynGenPar.pri)

INCLUDES += $(DYNGENPARDIR)/priorityqueue.h $(DYNGENPARDIR)/dyngenpar.h \
            $(DYNGENPARDIR)/pgf.h
