/* DynGenPar: Dynamic Generalized Parser - PGF import
   Copyright (C) 2010-2012 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2014-2015 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract numbers
   P20631 and P23554 is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#pragma once

/* We have to use integers as identifiers for categories and functions because
   their names are not unique (due to the transformations done to GF grammars to
   convert them to PMCFGs). */
#ifndef DYNGENPAR_INTEGER_CATEGORIES
#define DYNGENPAR_INTEGER_CATEGORIES
#endif

#include "dyngenpar.h"
#include <QString>
#include <QList>
#include <QStringList>
#include <QByteArray>
#include <QHash>
#include <QPair>

namespace DynGenPar {

enum PgfReservedTokens {
  PgfTokenEpsilon, PgfTokenLexError, PgfTokenVar, PgfTokenFloat, PgfTokenInt,
  PgfTokenString
};
DYNGENPAR_DECLARE_TYPEINFO(PgfReservedTokens, Q_PRIMITIVE_TYPE);

#define STATIC static
STATIC const char * const PreludeBind = "&+";
#undef STATIC

/// representation of the information in .pgf files in a format we can process
struct Pgf {
  /// dummy default constructor for bindings
  Pgf()
    : pmcfg(), catNames(), functionNames(), tokenHash(), suffixes(),
      componentNames(), firstFunction(0) {}
  Pgf(const QString &fileName, const QString &concreteName = QString());
  Pmcfg pmcfg; ///< the PMCFG (in (almost) standard form)
  QStringList catNames; ///< names of categories, in general not unique
  QStringList functionNames; ///< names of functions, in general not unique
  QHash<QString, int> tokenHash; ///< hash table for quick token lexing
  QList<QPair<QString, int> > suffixes; ///< list of &amp;+ suffixes with their
                                        ///  IDs
  QHash<QString, QStringList> componentNames; ///< names of category components
  int firstFunction; ///< the function ID of the first non-coercion function
};
DYNGENPAR_DECLARE_TYPEINFO(Pgf, Q_MOVABLE_TYPE);

/// parser for PGF grammars
class PgfParser : public Parser {
  public:
    PgfParser(const Pgf &p);
    PgfParser(const QString &fileName, const QString &concreteName = QString());
    virtual ~PgfParser() {delete inputSource;}
    void setInputStdin();
    void setInputFile(const QString &fileName);
    void setInputBytes(const QByteArray &bytes);
    void setInputString(const QString &string);
    void setInputBuffer(QByteArray *buffer);
    QString catName(int cat) const;
    QString functionName(int id) const {return pgf.functionNames.at(id);}
    void filterCoercionsFromSyntaxTree(Node &tree) const;
    Pgf pgf;
  private:
    void init() {if (!loadPmcfg(pgf.pmcfg)) qFatal("invalid PMCFG");}
};
DYNGENPAR_DECLARE_TYPEINFO(PgfParser, Q_MOVABLE_TYPE);

} // end namespace
