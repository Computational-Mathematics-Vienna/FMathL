cmake -DCMAKE_BUILD_TYPE:STRING="Release" -G "MinGW Makefiles" ..
mingw32-make
strip cnttoxml\cnttoxml.exe
