/* DynGenPar: Dynamic Generalized Parser - Naproche formula parser
   Copyright (C) 2010 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#pragma once

#ifndef DYNGENPAR_INTEGER_CATEGORIES
#define DYNGENPAR_INTEGER_CATEGORIES
#endif

#include "dyngenpar.h"
#include <string>

class NaprocheFormulaParser : public DynGenPar::Parser {
  public:
    NaprocheFormulaParser();
    virtual ~NaprocheFormulaParser() {delete inputSource;}
    void setInput(const std::string &input);
};
Q_DECLARE_TYPEINFO(NaprocheFormulaParser, Q_MOVABLE_TYPE);
