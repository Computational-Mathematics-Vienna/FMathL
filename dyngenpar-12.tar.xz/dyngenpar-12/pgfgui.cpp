/* DynGenPar: Dynamic Generalized Parser - Graphical PGF import test program
   Copyright (C) 2010 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2017-2018 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include "kdeversion.h"
#include <KApplication>
#include <KAboutData>
#if KDE_IS_VERSION(5, 0, 0)
#include <K4AboutData>
#else
#define K4AboutData KAboutData
#endif
#include <KCmdLineArgs>
#include "pgfgui-mainwindow.h"

static KApplication *app;

// main function for testing purposes
int main(int argc, char **argv)
{
  K4AboutData aboutData("pgfgui", QByteArray(),
                        ki18n("DynGenPar PGF GUI"),
                        "0.0.1", ki18n("Graphical Demo App for Prediction on "
                                       "PGF Grammars"),
                        K4AboutData::License_GPL_V2,
                        ki18n("Copyright (C) 2010-2011 Kevin Kofler "
                              "&lt;<a href=\"mailto:kevin.kofler@chello.at\">"
                              "kevin.kofler@chello.at</a>&gt;\n"
                              "Copyright (C) 2015-2018 DAGOPT Optimization "
                              "Technologies GmbH, written by Kevin Kofler "
                              "&lt;<a href=\"mailto:kofler@dagopt.com\">"
                              "kofler@dagopt.com</a>&gt;"),
                        ki18n("Demonstrates the prediction functionality of the "
                              "dynamic parser on compiled Grammatical Framework "
                              "grammars"),
                        "http://www.mat.univie.ac.at/~neum/FMathL.html",
                        "kevin.kofler@chello.at");
  aboutData.addLicense(K4AboutData::License_GPL_V3);
  aboutData.addAuthor(ki18n("Kevin Kofler"), ki18n("Author"),
                      "kevin.kofler@chello.at");
  aboutData.addCredit(ki18n("Support by the Austrian Science Fund FWF under "
                            "contract number P20631 is gratefully "
                            "acknowledged."));

  KCmdLineArgs::init(argc, argv, &aboutData);
  KCmdLineOptions options;
  options.add("+[pgf]", ki18n("PGF file to load"));
  KCmdLineArgs::addCmdLineOptions(options);

  app = new KApplication();
  KCmdLineArgs *args = KCmdLineArgs::parsedArgs();
#if KDE_IS_VERSION(5, 0, 0)
  // Workaround: K4AboutData fails to do this.
  KAboutData aboutData5 = KAboutData::applicationData();
  if (aboutData5.credits().isEmpty()) // do not duplicate if fixed upstream
    aboutData5.addCredit(aboutData.credits().first().name());
  KAboutData::setApplicationData(aboutData5);
#endif
  MainWindow *mainWindow = new MainWindow;
  if (args->count())
    mainWindow->loadPgf(args->arg(0));
  mainWindow->show();
  int status = app->exec();

  args->clear();
  delete app;
  return status;
}
