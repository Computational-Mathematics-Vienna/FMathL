#!/bin/sh
TARGET=~/Homepage/fmathl/dyngenpar
VERSION=12
mkdir -p $TARGET
cp -pf index.html ChangeLog $TARGET/
rm -rf $TARGET/dyngenpar-$VERSION
svn export . $TARGET/dyngenpar-$VERSION
pushd $TARGET >/dev/null
tar cJf dyngenpar-$VERSION.tar.xz dyngenpar-$VERSION
popd >/dev/null
rm -rf $TARGET/dyngenpar-$VERSION
rm -rf $TARGET/doc
cp -prf build/doc/html $TARGET/doc
rm -f $TARGET/doc/*.md5
mv -f $TARGET/doc/dyngenpar.qch $TARGET/
cp -pf build/doc/latex/refman.pdf $TARGET/dyngenpar.pdf
