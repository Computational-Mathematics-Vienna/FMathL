/* GFResGE: GF (Grammatical Framework) Resource Grammar Exporter
   Exports the dictionary from a PGF using the PGF import code from DynGenPar
   Copyright (C) 2016 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include <cstdio>
#include <QCoreApplication>
#include <QFile>
#include <QTextStream>
#include "pgf.h"

using namespace DynGenPar;

static QCoreApplication *app;

int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);

  if (argc < 2 || argc > 3) {
    QTextStream stream(stderr);
    stream << "usage: gfresge pgf_file [output_file]" << endl;
    return 1;
  }

  Pgf pgf(QString::fromLocal8Bit(argv[1]));
  QFile file;
  if (argc > 2) {
    QString fileName = QString::fromLocal8Bit(argv[2]);
    file.setFileName(fileName);
    if (!file.open(QFile::WriteOnly)) {
      QTextStream stream(stderr);
      stream << "failed to open " << fileName << endl;
      return 1;
    }
  } else {
    file.open(stdout, QFile::WriteOnly);
  }
  QTextStream stream(&file);
  int l = pgf.functionNames.length();
  for (int i=0; i<l; i++) {
    const QString &functionName = pgf.functionNames.at(i);
    if (functionName.contains('_')) {
      int idx = functionName.lastIndexOf('_');
      QString cat = functionName.mid(idx+1);
      QString name = functionName.mid(0, idx);
      if (cat.length() == 1 && cat[0].isDigit()) continue;
      const Function &function = pgf.pmcfg.functions.at(i);
      QStringList sequences;
      foreach (const Sequence &sequence, function) {
        QStringList tokens;
        foreach (const Term &term, sequence) {
          if (term.isToken()) {
            tokens << pgf.catNames.at(term.token);
          } else {
            tokens << ('%' + QString::number(term.arg));
          }
        }
        sequences << tokens.join(" ");
      }
      QString line = sequences.join(", ");
      // filter out more complex constructs (optional)
      // if (line.contains("&+") || line.contains('%')) continue;
      stream << name << " [" << cat << "] = " << line << endl;
    }
  }
  file.close();

  return 0;
}
