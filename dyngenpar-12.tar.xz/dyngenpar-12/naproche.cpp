/* DynGenPar: Dynamic Generalized Parser - Naproche parser
   Copyright (C) 2009-2010 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015-2016 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#define DYNGENPAR_INTEGER_CATEGORIES

#define yyFlexLexer NaprocheFlexLexer
#include <FlexLexer.h>
#undef yyFlexLexer
#include <fstream>
#include "dyngenpar.h"
#include "flexlexertokensource.h"
#include "naproche-cats.h"
#include "naproche-formulas.h"

#include "naproche.h"

using namespace DynGenPar;

class NaprocheTokenSource : public FlexLexerTokenSource {
  public:
    NaprocheTokenSource()
      : FlexLexerTokenSource(new NaprocheFlexLexer), stream(0) {}
    virtual ~NaprocheTokenSource() {
      if (stream)
        delete stream;
      delete flexLexer;
    }
    void setInputFile(const char *fileName) {
      if (stream)
        delete stream;
      stream = new std::ifstream(fileName);
      flexLexer->switch_streams(stream, static_cast<std::ostream *>(0));
    }
  protected:
    virtual Cat readToken() {
      Cat result = FlexLexerTokenSource::readToken();
      if (result == FORMULA) {
        formulaParser.setInput(flexLexer->YYText());
        QList<Match> matches = formulaParser.parse();
        switch (matches.size()) {
          case 0:
            return SCAN_ERROR;
          default:
            qWarning("ambiguous parses not properly unified");
            // fall through
          case 1:
            tree = matches.first().tree;
            break;
        }
      }
      return result;
    }
  private:
    NaprocheFormulaParser formulaParser;
    std::ifstream *stream;
};
Q_DECLARE_TYPEINFO(NaprocheTokenSource, Q_MOVABLE_TYPE);

NaprocheParser::NaprocheParser()
  : Parser(new NaprocheTokenSource) {
  tokens << FORMULA << THEOREM << PROOF << QED << LEMMA << DEFINE << IFF
    << ASSUME_THAT << ASSUME_CONTR << LET << CONSIDER << THUS << CONTRADICTION
    << FOR_ALL << COMMA << THERE_IS_AN << SUCH_THAT << IMPLIES << NOT << THEN
    << HENCE << RECALL_THAT << BUT << IN_PARTICULAR << OBSERVE_THAT
    << TOGETHER_WE_HAVE << SO;

  rules[text] << (Rule(1) << open_assumption_L << definition_L << lemma_OR_theorem_L);

  rules[theorem] << (Rule(2) << THEOREM << definition_L << assumption_L << ext_statement_P << proof);
  rules[lemma] << (Rule(3) << LEMMA << definition_L << assumption_L << ext_statement_P << proof);
  rules[proof] << (Rule(4) << PROOF << assumption_OR_ext_statement_L << QED);
  rules[open_assumption] << (Rule(5) << assumption);
  rules[closed_assumption] << (Rule(6) << assumption << ext_statement_OR_lemma_L << assumption_close);
  rules[definition] << (Rule(7) << DEFINE << sub_statement << IFF << sub_statement);
  rules[assumption] << (Rule(8) << assumption_kwd << simple_statement);
  rules[assumption_close] << (Rule(9) << THUS << simple_statement)
                          << (Rule(10) << CONTRADICTION);
  rules[ext_statement] << (Rule(11) << uni_quant)
                       << (Rule(12) << ext_quant)
                       << (Rule(13) << implication)
                       << (Rule(14) << negation)
                       << (Rule(15) << statement)
                       << (Rule(16) << closed_assumption);
  rules[simple_statement] << (Rule(17) << uni_quant)
                        << (Rule(18) << ext_quant)
                        << (Rule(19) << implication)
                        << (Rule(20) << negation)
                        << (Rule(21) << sub_statement);
  rules[uni_quant] << (Rule(22) << FOR_ALL << variable << COMMA << simple_statement);
  rules[ext_quant] << (Rule(23) << THERE_IS_AN << variable << SUCH_THAT << simple_statement);
  rules[implication] << (Rule(24) << sub_statement << IMPLIES << sub_statement);
  rules[negation] << (Rule(25) << NOT << sub_statement);
  rules[statement] << (Rule(26) << statement_kwd << sub_statement)
                   << (Rule(27) << sub_statement);

  rules[lemma_OR_theorem] << (Rule(28) << lemma)
                          << (Rule(29) << theorem);
  rules[assumption_OR_ext_statement] << (Rule(30) << assumption)
                                     << (Rule(31) << ext_statement);
  rules[ext_statement_OR_lemma] << (Rule(32) << ext_statement)
                                << (Rule(33) << lemma);

  rules[open_assumption_L] << (Rule(34) << open_assumption_L << open_assumption)
                           << Rule(35);
  rules[definition_L] << (Rule(36) << definition_L << definition)
                      << Rule(37);
  rules[lemma_OR_theorem_L] << (Rule(38) << lemma_OR_theorem_L << lemma_OR_theorem)
                            << Rule(39);
  rules[assumption_L] << (Rule(40) << assumption_L << assumption)
                      << Rule(41);
  rules[assumption_OR_ext_statement_L] << (Rule(42) << assumption_OR_ext_statement_L << assumption_OR_ext_statement)
                                       << Rule(43);
  rules[ext_statement_OR_lemma_L] << (Rule(44) << ext_statement_OR_lemma_L << ext_statement_OR_lemma)
                                  << Rule(45);

  rules[ext_statement_P] << (Rule(46) << ext_statement_P << ext_statement)
                         << (Rule(47) << ext_statement);

  rules[assumption_kwd] << (Rule(48) << ASSUME_THAT)
                        << (Rule(49) << ASSUME_CONTR)
                        << (Rule(50) << LET)
                        << (Rule(51) << CONSIDER);
  rules[statement_kwd] << (Rule(52) << THEN)
                       << (Rule(53) << HENCE)
                       << (Rule(54) << RECALL_THAT)
                       << (Rule(55) << BUT)
                       << (Rule(56) << IN_PARTICULAR)
                       << (Rule(57) << OBSERVE_THAT)
                       << (Rule(58) << TOGETHER_WE_HAVE)
                       << (Rule(59) << SO);
  rules[sub_statement] << (Rule(60) << FORMULA);
  rules[variable] << (Rule(61) << FORMULA);

  startCat = text;

  initCaches();
}

void NaprocheParser::setInputFile(const char *fileName)
{
  static_cast<NaprocheTokenSource *>(inputSource)->setInputFile(fileName);
}
