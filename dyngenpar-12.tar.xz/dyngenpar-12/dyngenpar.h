/* DynGenPar: Dynamic Generalized Parser
   Copyright (C) 2010-2012 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015-2018 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract numbers
   P20631 and P23554 is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

// Don't use pragma once here, Qt Jambi doesn't support it.
#ifndef DYNGENPAR_H
#define DYNGENPAR_H

#include <QString>
#include <QList>
#include <QStringList>
#include <QHash>
#include <QMultiHash>
#include <QSet>
#include <QPair>
#include <QQueue>
#include <QSharedData>
#include <QVariant>
#include <QVector>
#include <QDataStream>

#include "priorityqueue.h"

// Tell GCC that qFatal does not return.
// (In Qt 5, qFatal is already a macro and already gets this right.)
#if defined(__GNUC__) \
    && (__GNUC__ > 4 || (__GNUC__ == 4 && __GNUC_MINOR__ > 4)) \
    && QT_VERSION < QT_VERSION_CHECK(5, 0, 0)
#define qFatal(x...) (qFatal(x), __builtin_unreachable())
#endif

// Convenience macro to avoid copying&pasting namespace boilerplate
#define DYNGENPAR_DECLARE_TYPEINFO(type, typeclass) \
  } /* end namespace DynGenPar */ \
  Q_DECLARE_TYPEINFO(DynGenPar::type, typeclass); \
  namespace DynGenPar {

namespace DynGenPar {

// --- general data structures (both context-free grammars and PMCFGs) ---

#ifdef DYNGENPAR_INTEGER_CATEGORIES
typedef int Cat;
#define IS_EPSILON(cat) (!(cat))
typedef int CatArg;
#else
/// Category type: string or integer depending on DYNGENPAR_INTEGER_CATEGORIES.
/** If DYNGENPAR_INTEGER_CATEGORIES is defined, this typedef is defined as:
 *  @code
 *  typedef int Cat;
 *  @endcode
 *  instead.
 */
typedef QString Cat;
#define IS_EPSILON(cat) ((cat).isNull())
/// Category type (string or integer) when passed as an argument.
/** If DYNGENPAR_INTEGER_CATEGORIES is defined, this typedef is defined as:
 *  @code
 *  typedef int CatArg;
 *  @endcode
 *  instead.
 *
 *  This typedef is used for maximum efficiency, to pass strings by reference,
 *  but integers by value.
 */
typedef const Cat &CatArg;
#endif

/// rule constraints affecting the next token, for scannerless parsing
struct NextTokenConstraints {
  /// list of context-free categories the next token MUST match
  /** The categories in this list may be nonterminals or tokens. But they MUST
   *  be context-free. In other words, they must not be PMCFG pseudo-categories,
   *  and none of the rules used to derive them may contain any PMCFG
   *  pseudo-categories or next token constraints. (In particular, it is not
   *  possible to nest next token constraints.)
   */
  QList<Cat> expect;
  /// list of context-free categories the next token MUST NOT match
  /** The categories in this list may be nonterminals or tokens. But they MUST
   *  be context-free. In other words, they must not be PMCFG pseudo-categories,
   *  and none of the rules used to derive them may contain any PMCFG
   *  pseudo-categories or next token constraints. (In particular, it is not
   *  possible to nest next token constraints.)
   */
  QList<Cat> taboo;
  /// needed for hash tables
  bool operator==(const NextTokenConstraints &other) const {
    return expect == other.expect && taboo == other.taboo;
  }
  /// implementation of the QDataStream operator<<
  QDataStream &writeExternal(QDataStream &stream) const {
    return stream << expect << taboo;
  }
  /// implementation of the QDataStream operator>>
  QDataStream &readExternal(QDataStream &stream) {
    return stream >> expect >> taboo;
  }
};
uint qHash(const NextTokenConstraints &nextTokenConstraints);
DYNGENPAR_DECLARE_TYPEINFO(NextTokenConstraints, Q_MOVABLE_TYPE);

/// parser rule
class Action;
} // end namespace

inline QDataStream &operator<<(QDataStream &stream,
                               const DynGenPar::Action *data);
inline QDataStream &operator>>(QDataStream &stream, DynGenPar::Action *&data);

namespace DynGenPar {
class Rule : public QList<Cat> {
  public:
    static bool serializeLabels;
    static bool serializeActions;
    Rule() : QList<Cat>(), action(0) {}
    explicit Rule(const QVariant &label)
      : QList<Cat>(), action(0), lbl(label) {}
    explicit Rule(const QList<Cat> &list)
      : QList<Cat>(list), action(0), lbl() {}
    Rule(const QList<Cat> &list, const QVariant &label)
      : QList<Cat>(list), action(0), lbl(label) {}
    QVariant label() const {return lbl;}
    void setLabel(const QVariant &label) {lbl = label;}
    NextTokenConstraints nextTokenConstraints;
    Action *action;
    Rule &operator+=(const QList<Cat> &other) {
      QList<Cat>::operator+=(other);
      return *this;
    }
    Rule &operator+=(const Cat &value) { // QList always wants a const &
      QList<Cat>::operator+=(value);
      return *this;
    }
    Rule &operator<<(const QList<Cat> &other) {
      QList<Cat>::operator<<(other);
      return *this;
    }
    Rule &operator<<(const Cat &value) { // QList always wants a const &
      QList<Cat>::operator<<(value);
      return *this;
    }
    /// Java-style + the binding generator doesn't detect the inherited append
    void add(const Cat &value) { // QList always wants a const &
      append(value);
    }
    /// for bindings
    QList<Cat> &toList() { return (QList<Cat> &) *this; }
    /// implementation of the QDataStream operator<<
    QDataStream &writeExternal(QDataStream &stream, bool writeLabel = true,
                               bool writeAction = true) const {
      return nextTokenConstraints.writeExternal(stream
                                                << * (const QList<Cat> *) this
                                                << (writeLabel ? lbl
                                                               : QVariant()))
             << (writeAction ? action : static_cast<Action *>(0));
    }
    /// implementation of the QDataStream operator>>
    QDataStream &readExternal(QDataStream &stream) {
      return nextTokenConstraints.readExternal(stream >> * (QList<Cat> *) this
                                                      >> lbl) >> action;
    }

  private:
    QVariant lbl;
};
DYNGENPAR_DECLARE_TYPEINFO(Rule, Q_MOVABLE_TYPE);

typedef QHash<Cat, QList<Rule> > RuleSet;
typedef QSet<Cat> TokenSet;

/// An object representing a CFG (or a PMCFG in our internal representation)
/** This allows passing it around more easily and loading it into the parser in
 *  one step.
 */
struct Cfg {
  /// dummy default constructor for bindings
  Cfg() : rules(), tokens(), startCat() {}
  Cfg(const RuleSet &r, const TokenSet &t, CatArg sc)
    : rules(r), tokens(t), startCat(sc) {}
  RuleSet rules;
  TokenSet tokens;
  Cat startCat;
  bool isToken(CatArg cat) const {return tokens.contains(cat);}
  void addToken(CatArg cat) {tokens.insert(cat);}
  /// implementation of the QDataStream operator<<
  QDataStream &writeExternal(QDataStream &stream) const {
    return stream << rules << tokens << startCat;
  }
  /// implementation of the QDataStream operator>>
  QDataStream &readExternal(QDataStream &stream) {
    return stream >> rules >> tokens >> startCat;
  }
};
DYNGENPAR_DECLARE_TYPEINFO(Cfg, Q_MOVABLE_TYPE);

typedef QSet<Cat> Predictions;

/// multi-token predictions
struct MultiPrediction {
  /// dummy default constructor for bindings
  MultiPrediction() : fullLiteral(), cat() {}
  MultiPrediction(const QList<Cat> &fullLit, CatArg c)
    : fullLiteral(fullLit), cat(c) {}
  QList<Cat> fullLiteral; ///< the entire literal completed by the prediction
  Cat cat; ///< the nonterminal generating the literal

  /// needed for QList, QMultiHash
  bool operator==(const MultiPrediction &other) const {
    return fullLiteral == other.fullLiteral && cat == other.cat;
  }
};
DYNGENPAR_DECLARE_TYPEINFO(MultiPrediction, Q_MOVABLE_TYPE);

typedef QMultiHash<QList<Cat>, MultiPrediction> MultiPredictions;
typedef QMultiHash<Cat, NextTokenConstraints> ConstrainedPredictions;

/// multi-token predictions with next token constraints
struct ConstrainedMultiPrediction {
  /// dummy default constructor for bindings
  ConstrainedMultiPrediction()
    : fullLiteral(), cat(), nextTokenConstraints() {}
  ConstrainedMultiPrediction(const QList<Cat> &fullLit, CatArg c)
    : fullLiteral(fullLit), cat(c), nextTokenConstraints() {}
  ConstrainedMultiPrediction(const QList<Cat> &fullLit, CatArg c,
                             NextTokenConstraints ntc)
    : fullLiteral(fullLit), cat(c), nextTokenConstraints(ntc) {}
  QList<Cat> fullLiteral; ///< the entire literal completed by the prediction
  Cat cat; ///< the nonterminal generating the literal / the nonterminal itself
  NextTokenConstraints nextTokenConstraints; ///< only for nonterminals

  /// needed for QList, QMultiHash
  bool operator==(const ConstrainedMultiPrediction &other) const {
    return fullLiteral == other.fullLiteral && cat == other.cat
           && nextTokenConstraints == other.nextTokenConstraints;
  }
};
DYNGENPAR_DECLARE_TYPEINFO(ConstrainedMultiPrediction, Q_MOVABLE_TYPE);

typedef QMultiHash<QList<Cat>, ConstrainedMultiPrediction>
  ConstrainedMultiPredictions;

/// full rule as found in the initial graph
struct FullRule {
  /// dummy default constructor for bindings
  FullRule() : cat(), rule(), epsilonsSkipped(0), ruleno(0) {}
  FullRule(CatArg c, const Rule &r, int epsSkipped, int n)
    : cat(c), rule(r), epsilonsSkipped(epsSkipped), ruleno(n) {}
  Cat cat;
  Rule rule;
  int epsilonsSkipped;
  /// needed for PMCFGs (to match components of rules to each other)
  /** always set to 0 for context-free (1-dimensional) categories
   */
  int ruleno;
};
DYNGENPAR_DECLARE_TYPEINFO(FullRule, Q_MOVABLE_TYPE);

/// alternative for the expansion of a parse tree node
struct Node;
class Alternative : public QList<Node> {
  public:
    Alternative() : QList<DynGenPar::Node>() {}
    explicit Alternative(const QVariant &label)
      : QList<DynGenPar::Node>(), lbl(label) {}
    explicit Alternative(const QList<DynGenPar::Node> &list)
      : QList<DynGenPar::Node>(list), lbl() {}
    Alternative(const QList<DynGenPar::Node> &list, const QVariant &label)
      : QList<DynGenPar::Node>(list), lbl(label) {}
    QVariant label() const {return lbl;}
    void setLabel(const QVariant &label) {lbl = label;}
    Alternative &operator+=(const QList<DynGenPar::Node> &other) {
      QList<DynGenPar::Node>::operator+=(other);
      return *this;
    }
    Alternative &operator+=(const DynGenPar::Node &value) {
      QList<DynGenPar::Node>::operator+=(value);
      return *this;
    }
    Alternative &operator<<(const QList<DynGenPar::Node> &other) {
      QList<DynGenPar::Node>::operator<<(other);
      return *this;
    }
    Alternative &operator<<(const DynGenPar::Node &value) {
      QList<DynGenPar::Node>::operator<<(value);
      return *this;
    }
    /// Java-style + the binding generator doesn't detect the inherited append
    void add(const DynGenPar::Node &value) {
      append(value);
    }
    /// for bindings
    QList<DynGenPar::Node> &toList() {
      return (QList<DynGenPar::Node> &) *this;
    }

  private:
    QVariant lbl;
};
DYNGENPAR_DECLARE_TYPEINFO(Alternative, Q_MOVABLE_TYPE);

/// node in the parse tree
struct Node {
  Node() {} ///< error node
  Node(CatArg c) : cat(c) {children.append(Alternative());}
  Node(CatArg c, const QVariant &d) : cat(c), data(d) {
    children.append(Alternative());
  }
  Cat cat;
  QVariant data;
  QList<Alternative> children;
  /// needed for QList
  bool operator==(const Node &other) const {
    return cat == other.cat && data == other.data && children == other.children;
  }
};
DYNGENPAR_DECLARE_TYPEINFO(Node, Q_MOVABLE_TYPE);

/// context in which pseudo-categories are matched against each other
class PseudoCatScope;
class PseudoCatScopeData : public QSharedData {
  public:
    /// hash table recording parallel constraints
    /** record the tree for each pseudo-category and, for efficiency, the length
     *  of the matched string so we can match the exact same token string if the
     *  exact same pseudo-category is used again: this is the "parallel" in
     *  PMCFGs; also record the next token constraints
     */
    QHash<Cat, QPair<QPair<Node, NextTokenConstraints>, int> > pConstraints;
    /// hash table recording MCFG constraints
    /** record the rule number to use for a pseudo-category to match the one
     *  used for the first encountered pseudo-category, and the scope to reuse
     */
    QHash<Cat, QPair<int, PseudoCatScope> > mcfgConstraints;
};
DYNGENPAR_DECLARE_TYPEINFO(PseudoCatScopeData, Q_MOVABLE_TYPE);

class PseudoCatScope {
  public:
    PseudoCatScope() : d() {}
    QHash<Cat, QPair<QPair<Node, NextTokenConstraints>, int> > &pConstraints() {
      ensureNonNull();
      return d->pConstraints;
    };
    QHash<Cat, QPair<int, PseudoCatScope> > &mcfgConstraints() {
      ensureNonNull();
      return d->mcfgConstraints;
    };
    bool hasPConstraint(CatArg cat) const {
      return d ? d->pConstraints.contains(cat) : false;
    };
    bool hasMcfgConstraint(CatArg cat) const {
      return d ? d->mcfgConstraints.contains(cat) : false;
    };
    QPair<QPair<Node, NextTokenConstraints>, int> pConstraint(CatArg cat) const
    {
      return d ? d->pConstraints.value(cat)
               : QPair<QPair<Node, NextTokenConstraints>, int>();
    };
    QPair<int, PseudoCatScope> mcfgConstraint(CatArg cat) const {
      return d ? d->mcfgConstraints.value(cat) : QPair<int, PseudoCatScope>();
    };
    bool isNull() const { return !d.constData(); }
    /// needed for hash tables
    const PseudoCatScopeData *data() const { return d.constData(); }
    bool operator==(const PseudoCatScope &other) const { return d == other.d; }
  private:
    QSharedDataPointer<PseudoCatScopeData> d;
    void ensureNonNull() {
      if (!d.constData()) d = new PseudoCatScopeData;
    }
};
DYNGENPAR_DECLARE_TYPEINFO(PseudoCatScope, Q_MOVABLE_TYPE);

inline uint qHash(const PseudoCatScope &scope) {
  return qHash(scope.data());
}

/// (possibly partial) match
struct Match {
  /// dummy default constructor for bindings
  Match() : len(0), tree(), ruleno(0), scope(), nextTokenConstraints() {}
  Match(int l, Node t, int n, PseudoCatScope s)
    : len(l), tree(t), ruleno(n), scope(s), nextTokenConstraints() {}
  Match(int l, Node t, int n, PseudoCatScope s, const NextTokenConstraints &nt)
    : len(l), tree(t), ruleno(n), scope(s), nextTokenConstraints(nt) {}
  int len;
  Node tree;
  int ruleno; ///< used for PMCFGs
              /**< set to 0 where not needed to allow unification */
  PseudoCatScope scope;
  NextTokenConstraints nextTokenConstraints;
};
DYNGENPAR_DECLARE_TYPEINFO(Match, Q_MOVABLE_TYPE);

class Parser;
/// data passed to parser actions
struct ActionInfo {
  /// dummy default constructor for bindings
  ActionInfo() : tree(), parser(0) {}
  ActionInfo(const Node &t, Parser *p) : tree(t), parser(p) {}
  Node tree;
  Parser *parser;
};
DYNGENPAR_DECLARE_TYPEINFO(ActionInfo, Q_MOVABLE_TYPE);

/// interface for parser action deserializers
class ActionDeserializer {
  public:
    virtual ~ActionDeserializer() {}
    virtual Action *readAction(QDataStream &) = 0;
};
DYNGENPAR_DECLARE_TYPEINFO(ActionDeserializer, Q_MOVABLE_TYPE);

/// interface for parser actions
class Action {
  private:
    static QHash<QString, ActionDeserializer *> deserializers;
  protected:
    static void registerDeserializer(const QString &name,
                                     ActionDeserializer *deserializer) {
      deserializers.insert(name, deserializer);
    }
  public:
    virtual ~Action() {}
    virtual void execute(const ActionInfo &info) = 0;
    /// the number of tokens to look ahead before deciding to execute the action
    /** defaults to 0, can be overridden by subclasses
     */
    virtual int lookaheadTokens() const { return 0; }
    /// implementation of the QDataStream operator<<
    virtual void writeExternal(QDataStream &stream) const {
      qWarning("action not serializable");
      stream << QString();
    }
    /// implementation of the QDataStream operator>>
    static QDataStream &constructAndRead(QDataStream &stream, Action *&data) {
      QString type;
      stream >> type;
      if (type.isEmpty()) {
        data = 0;
        return stream;
      } else if (deserializers.contains(type)) {
        data = deserializers.value(type)->readAction(stream);
        return stream;
      } else qFatal("action deserializer \"%s\" not found",
                    type.toLocal8Bit().data());
    }
};
DYNGENPAR_DECLARE_TYPEINFO(Action, Q_MOVABLE_TYPE);


// --- data structures for DAG-structured parse stacks ---

/// node in the DAG-structured parse stack
class StackItem;
class StackItemData : public QSharedData {
  public:
    StackItemData(int depth) : m_depth(depth) {}
    virtual ~StackItemData() {}
    virtual StackItemData *clone() = 0;
    virtual int type() const = 0;
    int depth() const {return m_depth;}
    virtual void addParent(const StackItem &parent) = 0;
    virtual void setParents(const QList<StackItem> &parents) = 0;
  protected:
    int m_depth;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemData, Q_MOVABLE_TYPE);

class StackItem {
  public:
    StackItem() : d() {} ///< invalid type
    StackItem(const QList<StackItem> &parents, CatArg cat, CatArg effCat,
              int pos, const PseudoCatScope &scope); ///< type 0
    StackItem(const QList<StackItem> &parents, CatArg cat, CatArg effCat,
              const PseudoCatScope &scope); ///< type 1
    StackItem(const StackItem &parent, int dummy); ///< type 2
    StackItem(const StackItem &parent, const Rule &rule, int len, int curr,
              int i, const Node &tree, int ruleno,
              const NextTokenConstraints &nextTokenConstraints); ///< type 3
    StackItem(const StackItem &parent, CatArg target, int pos, int len);
      ///< type 4
    StackItem(const StackItem &parent, CatArg cat,
              const PseudoCatScope &scope); ///< type 5
    StackItem(const StackItem &parent, const QList<Node> &leaves, int i,
              const Node &tree, const PseudoCatScope &scope,
              const NextTokenConstraints &nextTokenConstraints); ///< type 6
    int type() const {return d ? d->type() : -1;}
    int depth() const {return d ? d->depth() : -1;}
    void addParent(const StackItem &parent) {d->addParent(parent);}
    void setParents(const QList<StackItem> &parents) {d->setParents(parents);}
    const StackItemData *data() const {return d.constData();}
    bool operator<(const StackItem &other) const {
      return depth() < other.depth();
    }
  private:
    QSharedDataPointer<StackItemData> d;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItem, Q_MOVABLE_TYPE);

/// type 0 item: during match, we're waiting for a token to shift
class StackItemType0 : public StackItemData {
  public:
    StackItemType0(const QList<StackItem> &parents, CatArg cat, CatArg effCat,
                   int pos, const PseudoCatScope &scope)
      : StackItemData(0), m_parents(parents), m_cat(cat), m_effCat(effCat),
        m_pos(pos), m_scope(scope) {
          foreach(const StackItem &parent, parents) {
            int newDepth = parent.depth() + 1;
            if (m_depth < newDepth) m_depth = newDepth;
          }
        }
    virtual ~StackItemType0() {}
    virtual StackItemData *clone() {return new StackItemType0(*this);}
    virtual int type() const {return 0;}
    virtual void addParent(const StackItem &parent) {
      m_parents.append(parent);
      int newDepth = parent.depth() + 1;
      if (m_depth < newDepth) m_depth = newDepth;
    }
    virtual void setParents(const QList<StackItem> &parents) {
      m_parents = parents;
      m_depth = 0;
      foreach(const StackItem &parent, parents) {
        int newDepth = parent.depth() + 1;
        if (m_depth < newDepth) m_depth = newDepth;
      }
    }
    const QList<StackItem> &parents() const {return m_parents;}
    Cat cat() const {return m_cat;}
    Cat effCat() const {return m_effCat;}
    int pos() const {return m_pos;}
    PseudoCatScope scope() const {return m_scope;}
  private:
    QList<StackItem> m_parents;
    Cat m_cat, m_effCat;
    int m_pos;
    PseudoCatScope m_scope;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemType0, Q_MOVABLE_TYPE);

/// type 1 item: during type 0 item processing, we're executing a reduce
class StackItemType1 : public StackItemData {
  public:
    StackItemType1(const QList<StackItem> &parents, CatArg cat, CatArg effCat,
                   const PseudoCatScope &scope) :
      StackItemData(0), m_parents(parents), m_cat(cat), m_effCat(effCat),
      m_scope(scope) {
          foreach(const StackItem &parent, parents) {
            int newDepth = parent.depth() + 1;
            if (m_depth < newDepth) m_depth = newDepth;
          }
        }
    virtual ~StackItemType1() {}
    virtual StackItemData *clone() {return new StackItemType1(*this);}
    virtual int type() const {return 1;}
    virtual void addParent(const StackItem &) {
      // this could be allowed, but is not needed anywhere, so detect misuse
      qFatal("cannot call addParent on type 1 item");
    }
    virtual void setParents(const QList<StackItem> &) {
      // this could be allowed, but is not needed anywhere, so detect misuse
      qFatal("cannot call setParents on type 1 item");
    }
    const QList<StackItem> &parents() const {return m_parents;}
    Cat cat() const {return m_cat;}
    Cat effCat() const {return m_effCat;}
    PseudoCatScope scope() const {return m_scope;}
  private:
    QList<StackItem> m_parents;
    Cat m_cat, m_effCat;
    PseudoCatScope m_scope;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemType1, Q_MOVABLE_TYPE);

/// type 2 item: during reduce, we're recursively executing another reduce
/** This item forms a unification point. */
class StackItemType2 : public StackItemData {
  public:
    StackItemType2(const StackItem &parent) : StackItemData(parent.depth() + 1),
      m_parent(parent) {}
    virtual ~StackItemType2() {}
    virtual StackItemData *clone() {return new StackItemType2(*this);}
    virtual int type() const {return 2;}
    virtual void addParent(const StackItem &) {
      qFatal("cannot call addParent on type 2 item");
    }
    virtual void setParents(const QList<StackItem> &) {
      qFatal("cannot call setParents on type 2 item");
    }
    const StackItem &parent() const {return m_parent;}
  private:
    StackItem m_parent;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemType2, Q_MOVABLE_TYPE);

/// type 3 item: during matchRemaining, we're executing a match
class StackItemType3 : public StackItemData {
  public:
    StackItemType3(const StackItem &parent, const Rule &rule, int len, int curr,
                   int i, const Node &tree, int ruleno,
                   const NextTokenConstraints &nextTokenConstraints)
      : StackItemData(parent.depth() + 1), m_parent(parent), m_rule(rule),
        m_len(len), m_curr(curr), m_i(i), m_tree(tree), m_ruleno(ruleno),
        m_nextTokenConstraints(nextTokenConstraints) {}
    virtual ~StackItemType3() {}
    virtual StackItemData *clone() {return new StackItemType3(*this);}
    virtual int type() const {return 3;}
    virtual void addParent(const StackItem &) {
      qFatal("cannot call addParent on type 3 item");
    }
    virtual void setParents(const QList<StackItem> &) {
      qFatal("cannot call setParents on type 3 item");
    }
    const StackItem &parent() const {return m_parent;}
    Rule rule() const {return m_rule;}
    int len() const {return m_len;}
    int curr() const {return m_curr;}
    int i() const {return m_i;}
    Node tree() const {return m_tree;}
    int ruleno() const {return m_ruleno;}
    NextTokenConstraints nextTokenConstraints() const {
      return m_nextTokenConstraints;
    }
  private:
    StackItem m_parent;
    Rule m_rule;
    int m_len, m_curr, m_i;
    Node m_tree;
    int m_ruleno;
    NextTokenConstraints m_nextTokenConstraints;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemType3, Q_MOVABLE_TYPE);

/// type 4 item: during reduce, we're executing a matchRemaining
/** This item forms a unification point. */
class StackItemType4 : public StackItemData {
  public:
    StackItemType4(const StackItem &parent, CatArg target, int pos, int len)
      : StackItemData(parent.depth() + 1), m_parent(parent), m_target(target),
        m_pos(pos), m_len(len) {}
    virtual ~StackItemType4() {}
    virtual StackItemData *clone() {return new StackItemType4(*this);}
    virtual int type() const {return 4;}
    virtual void addParent(const StackItem &) {
      qFatal("cannot call addParent on type 4 item");
    }
    virtual void setParents(const QList<StackItem> &) {
      qFatal("cannot call setParents on type 4 item");
    }
    const StackItem &parent() const {return m_parent;}
    Cat target() const {return m_target;}
    int pos() const {return m_pos;}
    int len() const {return m_len;}
  private:
    StackItem m_parent;
    Cat m_target;
    int m_pos, m_len;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemType4, Q_MOVABLE_TYPE);

/// type 5 item: during match (of an MCFG constraint), we're executing a
/// matchRemaining
class StackItemType5 : public StackItemData {
  public:
    StackItemType5(const StackItem &parent, CatArg cat,
                   const PseudoCatScope &scope)
      : StackItemData(parent.depth() + 1), m_parent(parent), m_cat(cat),
        m_scope(scope) {}
    virtual ~StackItemType5() {}
    virtual StackItemData *clone() {return new StackItemType5(*this);}
    virtual int type() const {return 5;}
    virtual void addParent(const StackItem &) {
      qFatal("cannot call addParent on type 5 item");
    }
    virtual void setParents(const QList<StackItem> &) {
      qFatal("cannot call setParents on type 5 item");
    }
    const StackItem &parent() const {return m_parent;}
    Cat cat() const {return m_cat;}
    PseudoCatScope scope() const {return m_scope;}
  private:
    StackItem m_parent;
    Cat m_cat;
    PseudoCatScope m_scope;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemType5, Q_MOVABLE_TYPE);

/// type 6 item: during match, we're matching a P constraint
class StackItemType6 : public StackItemData {
  public:
    StackItemType6(const StackItem &parent, const QList<Node> &leaves, int i,
                   const Node &tree, const PseudoCatScope &scope,
                   const NextTokenConstraints &nextTokenConstraints)
      : StackItemData(parent.depth() + 1), m_parent(parent), m_leaves(leaves),
        m_i(i), m_tree(tree), m_scope(scope),
        m_nextTokenConstraints(nextTokenConstraints) {}
    virtual ~StackItemType6() {}
    virtual StackItemData *clone() {return new StackItemType6(*this);}
    virtual int type() const {return 6;}
    virtual void addParent(const StackItem &) {
      qFatal("cannot call addParent on type 6 item");
    }
    virtual void setParents(const QList<StackItem> &) {
      qFatal("cannot call setParents on type 6 item");
    }
    const StackItem &parent() const {return m_parent;}
    QList<Node> leaves() const {return m_leaves;}
    int i() const {return m_i;}
    Node tree() const {return m_tree;}
    PseudoCatScope scope() const {return m_scope;}
    NextTokenConstraints nextTokenConstraints() const {
      return m_nextTokenConstraints;
    }
  private:
    StackItem m_parent;
    QList<Node> m_leaves;
    int m_i;
    Node m_tree;
    PseudoCatScope m_scope;
    NextTokenConstraints m_nextTokenConstraints;
};
DYNGENPAR_DECLARE_TYPEINFO(StackItemType6, Q_MOVABLE_TYPE);

inline StackItem::StackItem(const QList<StackItem> &parents, CatArg cat,
                            CatArg effCat, int pos,
                            const PseudoCatScope &scope)
{
  d = new StackItemType0(parents, cat, effCat, pos, scope);
}

inline StackItem::StackItem(const QList<StackItem> &parents, CatArg cat,
                            CatArg effCat, const PseudoCatScope &scope)
{
  d = new StackItemType1(parents, cat, effCat, scope);
}

inline StackItem::StackItem(const StackItem &parent, int)
{
  d = new StackItemType2(parent);
}

inline StackItem::StackItem(const StackItem &parent, const Rule &rule, int len,
                            int curr, int i, const Node &tree, int ruleno,
                            const NextTokenConstraints &nextTokenConstraints)
{
  d = new StackItemType3(parent, rule, len, curr, i, tree, ruleno,
                         nextTokenConstraints);
}

inline StackItem::StackItem(const StackItem &parent, CatArg target, int pos,
                            int len)
{
  d = new StackItemType4(parent, target, pos, len);
}

inline StackItem::StackItem(const StackItem &parent, CatArg cat,
                            const PseudoCatScope &scope)
{
  d = new StackItemType5(parent, cat, scope);
}

inline StackItem::StackItem(const StackItem &parent, const QList<Node> &leaves,
                            int i, const Node &tree,
                            const PseudoCatScope &scope,
                            const NextTokenConstraints &nextTokenConstraints)
{
  d = new StackItemType6(parent, leaves, i, tree, scope, nextTokenConstraints);
}


// --- token source abstraction ---

/// API for stateful lexers to save their state for rewinding
class AbstractLexerStateData : public QSharedData {
  public:
    virtual ~AbstractLexerStateData() {}
    virtual AbstractLexerStateData *clone() = 0;
};
DYNGENPAR_DECLARE_TYPEINFO(AbstractLexerStateData, Q_MOVABLE_TYPE);

class LexerState {
  public:
    LexerState() : d() {}
    LexerState(AbstractLexerStateData *data) : d(data) {}
    void clear() { d = 0; }
    bool isNull() const { return !d.constData(); }
    const AbstractLexerStateData *data() const { return d.constData(); }
    bool operator==(const LexerState &other) const { return d == other.d; }
  private:
    QSharedDataPointer<AbstractLexerStateData> d;
};
DYNGENPAR_DECLARE_TYPEINFO(LexerState, Q_MOVABLE_TYPE);

class TokenSource {
  public:
    TokenSource() : currPos(0) {}
    virtual ~TokenSource() {}
    /// get the next token from the input, increment current position, save
    /// parse tree
    /** An epsilon token is returned and currPos is not incremented if the end
     *  of input was reached.
     */
    Cat nextToken() {
      tree = Node();
      Cat result = readToken();
      if (!IS_EPSILON(result)) {
        // If the implementation of readToken didn't create a parse tree, create
        // the default one: a leaf node.
        if (tree.children.isEmpty()) tree = Node(result);
        currPos++;
      }
      return result;
    }
    /// get the parse tree for the last shifted token
    Node parseTree() {
      return tree;
    }
    /// match the parse tree for the last shifted token against the given tree
    /** @returns @c true if they should be considered identical for the purposes
     *           of a PMCFG rule using the same variable twice, @c false
     *           otherwise
     *
     *  The default implementation compares only the category. Other token
     *  sources may want to also look at the data and children fields.
     */
    virtual bool matchParseTree(const Node &treeToMatch) {
      return treeToMatch.cat == tree.cat;
    }
    /// get the current input position
    int currentPosition() {return currPos;}
    /// rewind to an older position (requires buffering)
    /** @returns @c true if successful, @c false otherwise
     *
     * in all cases, destroys the saved parse tree
     *
     * By default, only succeeds if the position is the current one, otherwise
     * always returns @c false. Can be overridden by subclasses.
     *
     * Some subclasses (e.g., file-backed ones) can wind both forward and
     * backward, some can only rewind, some cannot wind at all. The method will
     * return @c false if seeking to the new position is not possible.
     */
    virtual bool rewindTo(int pos, const LexerState & = LexerState()) {
      tree = Node();
      return (pos == currPos);
    }
    /// rewind to an older position (requires buffering) and restore the parse
    /// tree (needed for lookahead)
    /** @returns @c true if successful, @c false otherwise
     *
     * in all cases, restores the saved parse tree to the passed @a parseTree
     *
     * Relies on the virtual #rewindTo to do its actual work.
     */
    bool rewindTo(int pos, const Node &parseTree,
                  const LexerState &lexerState = LexerState()) {
      bool ret = rewindTo(pos, lexerState);
      tree = parseTree;
      return ret;
    }
    /// saves the current lexer state, by default a null LexerState
    virtual LexerState saveState() {return LexerState();}
  protected:
    /// get the next token from the input, to be implemented by subclasses
    virtual Cat readToken() = 0;
    /// basic implementation of rewindTo for subclasses which support it
    /** some subclasses may need additional processing */
    bool simpleRewind(int pos, bool rewindOnly = false) {
      tree = Node(); // destroy saved parse tree
      if (rewindOnly && pos > currPos) // cannot rewind forward
        return false;
      currPos = pos;
      return true;
    }
    int currPos;
    /// sub-parse-tree for hierarchical parsing
    /** This variable can be set by #readToken to a subtree produced by a
     *  hierarchical parser, which will be attached to the resulting parse tree
     *  in lieu of a leaf node.
     *
     *  If this variable is left unset, a leaf node is automatically produced.
     */
    Node tree;
};
DYNGENPAR_DECLARE_TYPEINFO(TokenSource, Q_MOVABLE_TYPE);

class ListTokenSource : public TokenSource {
  public:
    ListTokenSource() : TokenSource() {}
    virtual ~ListTokenSource() {}
    QList<Cat> inputTokens;
    /// overridden because lists can be rewound
    virtual bool rewindTo(int pos, const LexerState & = LexerState()) {
      return simpleRewind(pos);
    }
  protected:
    /// just fetch the next token from the list
    virtual Cat readToken() {
      if (currPos < inputTokens.size())
        return inputTokens.at(currPos);
      return Cat();
    }
};
DYNGENPAR_DECLARE_TYPEINFO(ListTokenSource, Q_MOVABLE_TYPE);

/// text position
/** stored in the lexer state by some text-oriented token sources to allow
 *  correct error reporting
 */
struct TextPosition {
  TextPosition() : line(0), col(0) {}
  TextPosition(int l, int c) : line(l), col(c) {}

  void reset() { line = col = 0; }

  /// convenience method to count a character
  void countCharacter(unsigned char c) {
    // ignore CR
    if (c == '\r') return;

    if (c == '\n') { // LF
      line++;
      col = 0;
    } else col++; // horizontal character
  }

  int line; ///< line, zero-based
  int col; ///< column, zero-based
};
DYNGENPAR_DECLARE_TYPEINFO(TextPosition, Q_PRIMITIVE_TYPE);


// --- data structures for PMCFGs (in standard representation) ---

/// term in the expression of a component of a PMCFG function
struct Term {
  /// dummy default constructor for bindings
  Term() : arg(-1), component(0), token() {}
  Term(int a, int c) : arg(a), component(c), token() {}
  Term(CatArg t) : arg(-1), component(0), token(t) {}
  int arg, component;
  /** This is supposed to be a token in a standard PMCFG, though in the
   *  implementation, any context-free category will work.
   */
  Cat token;
  bool isComponent() const {return arg >= 0;}
  bool isToken() const {return arg < 0;}
  /// needed for QList
  bool operator==(const Term &other) const {
    return arg == other.arg && component == other.component
           && token == other.token;
  }
};
DYNGENPAR_DECLARE_TYPEINFO(Term, Q_MOVABLE_TYPE);

/// component of a PMCFG function, a sequence of terms
class Sequence : public QList<Term> {
  public:
    NextTokenConstraints nextTokenConstraints;

    Sequence() : QList<Term>(), nextTokenConstraints() {}
    explicit Sequence(const NextTokenConstraints &ntc)
      : QList<Term>(), nextTokenConstraints(ntc) {}
    explicit Sequence(const QList<Term> &list)
      : QList<Term>(list), nextTokenConstraints() {}
    Sequence(const QList<Term> &list, const NextTokenConstraints &ntc)
      : QList<Term>(list), nextTokenConstraints(ntc) {}
    Sequence &operator+=(const QList<Term> &other) {
      QList<Term>::operator+=(other);
      return *this;
    }
    Sequence &operator+=(const Term &value) {
      QList<Term>::operator+=(value);
      return *this;
    }
    Sequence &operator<<(const QList<Term> &other) {
      QList<Term>::operator<<(other);
      return *this;
    }
    Sequence &operator<<(const Term &value) {
      QList<Term>::operator<<(value);
      return *this;
    }
    /// Java-style (for consistency, even though append is detected here)
    void add(const Term &value) {
      append(value);
    }
    /// for bindings
    QList<Term> &toList() {
      return (QList<Term> &) *this;
    }
};
DYNGENPAR_DECLARE_TYPEINFO(Sequence, Q_MOVABLE_TYPE);

/// PMCFG function
class Function: public QList<Sequence> {
  public:
    Function() : QList<Sequence>() {}
    explicit Function(const QList<Sequence> &list) : QList<Sequence>(list) {}
    Function &operator+=(const QList<Sequence> &other) {
      QList<Sequence>::operator+=(other);
      return *this;
    }
    Function &operator+=(const Sequence &value) {
      QList<Sequence>::operator+=(value);
      return *this;
    }
    Function &operator<<(const QList<Sequence> &other) {
      QList<Sequence>::operator<<(other);
      return *this;
    }
    Function &operator<<(const Sequence &value) {
      QList<Sequence>::operator<<(value);
      return *this;
    }
    /// Java-style (for consistency, even though append is detected here)
    void add(const Sequence &value) {
      append(value);
    }
    /// for bindings
    QList<Sequence> &toList() {
      return (QList<Sequence> &) *this;
    }
};
DYNGENPAR_DECLARE_TYPEINFO(Function, Q_MOVABLE_TYPE);

/// PMCFG
struct Pmcfg {
  /// @name grammar
  //@{
  /// list of PMCFG functions
  /** This list does not store function names. They can be optionally used and
   *  are stored in @ref functionNames and @ref functionIndices.
   */
  QList<Function> functions;
  /// set of PMCFG rules
  /** Rules should be labeled with the index of the function in @ref functions
   *  or its name as found in @ref functionNames and @ref functionIndices. The
   *  expression of the rule is interpreted as the argument list for the
   *  function. For example:
   *  @code
   *  Rule(1) << "A" << "B"; // calls function #1 with (A, B) as parameters
   *  Rule("f") << "A" << "B"; // calls f(A, B)
   *  @endcode
   *
   *  In a standard PMCFG, the argument list may contain only PMCFG
   *  nonterminals. The syntax tree then only contains the function and the
   *  syntax trees for each argument. This implementation also allows tokens and
   *  context-free nonterminals as function arguments, in which case the syntax
   *  tree will contain the parse tree for the context-free argument. In
   *  particular, in the case of a token, the data attached to the token is
   *  retained.
   */
  RuleSet rules;
  /// set of true tokens
  /** (must NOT contain context-free nonterminals) */
  TokenSet tokens;
  /// start category
  /** The start category must be 1-dimensional. */
  Cat startCat;
  /// optional context-free rules
  /** allows specifying rules for context-free categories which can be used as
   *  "token" terms in PMCFG functions, e.g. A -> "a" | "an"
   *
   *  @warning The exact expansion used will be reflected only in the parse
   *           tree, not in the PMCFG syntax tree. Do not use this feature if
   *           you need to know which exact expression was used.
   */
  RuleSet cfRules;
  //@}

  /// @name function name tables (optional)
  //@{
  QHash<int, QString> functionNames;
  QHash<QString, int> functionIndices;
  void addFunction(const QString &name, const Function &function) {
    int index = functions.size();
    functions.append(function);
    functionNames.insert(index, name);
    functionIndices.insert(name, index);
  }
  Function lookupFunction(const QVariant &id) const {
    if (id.type() == QVariant::Int) return functions.at(id.toInt());

    QString name = id.toString();
    if (!functionIndices.contains(name)) return Function();
    return functions.at(functionIndices.value(name));
  }
  //@}
};
DYNGENPAR_DECLARE_TYPEINFO(Pmcfg, Q_MOVABLE_TYPE);

/// attached to the parse trees as rule labels to allow obtaining syntax trees
struct PmcfgComponentInfo {
  PmcfgComponentInfo() {}
  PmcfgComponentInfo(const Rule &rule)
    : pmcfgRule(rule), argPositions(rule.size()) {}
  Rule pmcfgRule;
  QVector<QVector<int> > argPositions; /**< must be the same size as
                                        *   @ref pmcfgRule (even if the last
                                        *   arguments are not used)
                                        */
};
DYNGENPAR_DECLARE_TYPEINFO(PmcfgComponentInfo, Q_MOVABLE_TYPE);

Node parseTreeToPmcfgSyntaxTree(const Node &parseTree);


// --- parse state struct, for bindings ---

/// parse state struct, for bindings
struct ParseState {
  ParseState()
    : errorPos(-1), errorToken(), incrementalPos(-1), incrementalStacks(),
      incrementalMatches(), lexerState() {}
  // explicitly implement the default copy constructor to get it bound
  ParseState(const ParseState &other)
    : errorPos(other.errorPos), errorToken(other.errorToken),
      incrementalPos(other.incrementalPos),
      incrementalStacks(other.incrementalStacks),
      incrementalMatches(other.incrementalMatches), lexerState(other.lexerState)
      {}

  int errorPos;
  Cat errorToken;
  int incrementalPos;
  QList<StackItem> incrementalStacks;
  QList<Match> incrementalMatches;
  LexerState lexerState;

  void reset() { *this = ParseState(); }
};
DYNGENPAR_DECLARE_TYPEINFO(ParseState, Q_MOVABLE_TYPE);


// --- main class ---

/// main class
class Parser {
  public:
    // interface methods
    Parser(TokenSource *tokenSource)
      : inputSource(tokenSource), lastGeneratedCat(0) {}
    virtual ~Parser() {}
    bool isToken(CatArg cat) const {return tokens.contains(cat);}
    void addToken(CatArg cat) {tokens.insert(cat);}
    bool isLiteral(const QList<Cat> &list) const;
    void initCaches();
    void addRule(CatArg cat, const Rule &rule);
    void loadCfg(const Cfg &cfg) {
      rules = cfg.rules;
      tokens = cfg.tokens;
      startCat = cfg.startCat;
      initCaches();
    }
    /// get a Cfg object back from the parser, for serialization
    Cfg getCfg() {return Cfg(rules, tokens, startCat);}
    bool loadPmcfg(const Pmcfg &pmcfg);
    bool addPmcfgRule(Pmcfg &pmcfg, CatArg cat, const Rule &rule);
    QList<Match> parse(int *errorPos = 0, Cat *errorToken = 0,
                       int *incrementalPos = 0,
                       QList<StackItem> *incrementalStacks = 0,
                       QList<Match> *incrementalMatches = 0,
                       LexerState *lexerState = 0);
    /// overloaded version using ParseState, for bindings
    QList<Match> parse(ParseState *parseState) {
      return parse(&parseState->errorPos, &parseState->errorToken,
                   &parseState->incrementalPos, &parseState->incrementalStacks,
                   &parseState->incrementalMatches, &parseState->lexerState);
    }
    /// saves the current parser state, only meaningful during a #parse
    /// operation
    /** This method is intended to be used in callbacks executed within #parse.
     *  When called with no running #parse operation, @a parseState will be
     *  reset.
     */
    void saveState(ParseState *parseState) {
      if (nextStacks.isEmpty() && currentMatches.isEmpty() && errPos < 0) {
        parseState->reset(); // no parse operation running
      } else {
        parseState->errorPos = errPos;
        parseState->errorToken = errToken;
        parseState->incrementalPos = inputSource->currentPosition();
        parseState->incrementalStacks = nextStacks;
        parseState->incrementalMatches = currentMatches;
        parseState->lexerState = inputSource->saveState();
      }
    }
    Predictions computePredictions(const QList<StackItem> &stacks) const;
    /// overloaded version using ParseState, for bindings
    Predictions computePredictions(const ParseState &parseState) const {
      return computePredictions(parseState.incrementalStacks);
    }
    QHash<Cat, QSet<Cat> > expandNonterminalPrediction(CatArg cat) const;
    QHash<Cat, QSet<Cat> > expandNonterminalPredictionC(CatArg cat);
    MultiPredictions computeMultiPredictions(const QList<StackItem> &stacks)
      const;
    /// overloaded version using ParseState, for bindings
    MultiPredictions computeMultiPredictions(const ParseState &parseState) const
    {
      return computeMultiPredictions(parseState.incrementalStacks);
    }
    QHash<Cat, QSet<QList<Cat> > >
      expandNonterminalPredictionMulti(CatArg cat) const;
    QHash<Cat, QSet<QList<Cat> > >
      expandNonterminalPredictionMultiC(CatArg cat);
    ConstrainedPredictions computeConstrainedPredictions(
      const QList<StackItem> &stacks) const;
    /// overloaded version using ParseState, for bindings
    ConstrainedPredictions computeConstrainedPredictions(
      const ParseState &parseState) const {
      return computeConstrainedPredictions(parseState.incrementalStacks);
    }
    QHash<Cat, QSet<Cat> > expandNonterminalPredictionC(CatArg cat,
      const NextTokenConstraints &nextTokenConstraints);
    QHash<Cat, QSet<Cat> > expandNonterminalPredictionC(CatArg cat,
      const QList<NextTokenConstraints> &nextTokenConstraintsList);
    ConstrainedMultiPredictions computeConstrainedMultiPredictions(
      const QList<StackItem> &stacks) const;
    /// overloaded version using ParseState, for bindings
    ConstrainedMultiPredictions computeConstrainedMultiPredictions(
      const ParseState &parseState) const
    {
      return computeConstrainedMultiPredictions(parseState.incrementalStacks);
    }
    QHash<Cat, QSet<QList<Cat> > >
      expandNonterminalPredictionMultiC(CatArg cat,
      const NextTokenConstraints &nextTokenConstraints);
    QHash<Cat, QSet<QList<Cat> > >
      expandNonterminalPredictionMultiC(CatArg cat,
      const QList<NextTokenConstraints> &nextTokenConstraintsList);

    /// @name grammar
    //@{
    /// grammar rules
    /** @warning Modifying the grammar directly requires #initCaches, use
     *           #addRule if possible.
     */
    RuleSet rules;
    /// tokens
    TokenSet tokens;
    /// start category
    Cat startCat;
    //@}

    /// @name additional information needed for PMCFGs
    //@{
    /// pseudo-categories, used to represent PMCFGs internally
    /** maps a pseudo-category to:
     *  -# the actual component of the multidimensional category this
     *     pseudo-category stands for - just substituting this for the
     *     pseudo-category results in the context-free approximation of the
     *     PMCFG
     *  -# the list of pseudo-categories resulting from the use of the SAME
     *     argument (not just the same category) in the same context - all those
     *     pseudo-categories, when used in the same context, have to be expanded
     *     using matching rules; we use top-down expansion for all except the
     *     first encountered one to guarantee the same expansion as the one
     *     obtained while reducing the first one
     *
     *  Note that, when parsing a PMCFG, the initial graph and the set of
     *  nullable categories are the ones for the context-free approximation. The
     *  PMCFG constraints are only evaluated during the matching resp. reducing
     *  steps.
     *
     *  Also note that tokens are always 1-dimensional, so tokens may not be
     *  pseudo-categories nor the actual component for a pseudo-category.
     */
    QHash<Cat, QPair<Cat, QList<Cat> > > pseudoCats;
    /// maps categories which represent components of a multi-component category
    /// to the category and component index they represent
    /** also used to look up whether a category is a component of a
     *  multi-component category
     */
    QHash<Cat, QPair<Cat, int> > componentCats;
    /// maps multi-component categories to the list of their components
    /** used during the import of PMCFG rules in the standard representation
     *
     *  can be left out if the internal representation is used
     */
    QHash<Cat, QList<Cat> > catComponents;
    //@}

  protected:
    /// input source
    TokenSource *inputSource;

  private:
    // helper methods
    Cat effectiveCat(CatArg cat) const;
    void processRule(CatArg cat, const Rule &rule, int skip, int ruleno,
                     QQueue<Cat> &nullableQueue, bool &clearEpsilonMatches);
    bool computePmcfgDimension(CatArg cat, const Rule &rule,
                               const Pmcfg &pmcfg);
    bool convertPmcfgRule(CatArg cat, const Rule &rule, const Pmcfg &pmcfg,
                          bool updateCaches);
    bool reachable(CatArg cat, CatArg target, QSet<Cat> mark);
    QList<FullRule> neighborhood(CatArg cat, CatArg target);
    void finalizeMatches(QList<Match> &matches, CatArg cat,
                         const PseudoCatScope &scope);
    void copyScope(QList<Match> &matches, const PseudoCatScope &scope);
    QList<Match> matchCFToEpsilon(CatArg cat, QSet<Cat> mark);
    QList<Match> matchEffectiveCatToEpsilon(CatArg cat, QSet<Cat> mark);
    QList<Match> matchToEpsilonRecurse(CatArg cat, QSet<Cat> mark,
                                       const PseudoCatScope &scope);
    QList<Match> matchToEpsilon(CatArg cat, const PseudoCatScope &scope);
    bool matchesTokenRecurse(CatArg cat, CatArg token, QSet<Cat> mark) const;
    bool matchesToken(CatArg cat, CatArg token) const;
    void collectLeaves(const Node &tree, QList<Node> &leaves);
    bool validateNextTokenConstraints(CatArg token,
      const NextTokenConstraints &nextTokenConstraints) const;
    QList<Match> match(CatArg cat, int pos, const PseudoCatScope &scope,
                       const StackItem &stack,
                       const NextTokenConstraints &nextTokenConstraints);
    bool verifyLookaheadRule(const Rule &rule, int i, int &curr,
                             int &remaining, QSet<Cat> &mark);
    bool verifyLookahead(const StackItem &stack, CatArg cat, int pos,
                         int nTokens);
    QList<Match> matchRemaining(const Rule &rule, int len, int curr, int i,
                                const Node &tree, const PseudoCatScope &scope,
                                int ruleno, const StackItem &stack,
                                const NextTokenConstraints
                                  &nextTokenConstraints);
    Cat findFirstToken(const Node &tree);
    void unify(QList<Match> &matches);
    QList<Match> reduce(CatArg cat, CatArg target, int pos, int len,
                        const Node &tree, const StackItem &stack,
                        const PseudoCatScope &scope, int ruleno,
                        const NextTokenConstraints &nextTokenConstraints,
                        QSet<Cat> mark = QSet<Cat>());
    QList<Match> processStackItem(const StackItem &item,
                                  const QList<Match> &matches);
    QList<Match> processStack(const StackItem &stack, CatArg token);
    bool shift(int pos);
    void expandNonterminalPredictionRecurse(CatArg cat,
                                            QHash<Cat, QSet<Cat> > &result,
                                            QSet<Cat> &mark) const;
    void expandNonterminalPredictionRecurseC(CatArg cat,
                                             QHash<Cat, QSet<Cat> > &result,
                                             QSet<Cat> mark, int ruleno,
                                             const PseudoCatScope &scope,
                                             const NextTokenConstraints
                                               &nextTokenConstraints);
    void expandNonterminalPredictionMultiRecurse(CatArg cat,
      QHash<Cat, QSet<QList<Cat> > > &result, QSet<Cat> &mark) const;
    void expandNonterminalPredictionMultiRecurseC(CatArg cat,
      QHash<Cat, QSet<QList<Cat> > > &result, QSet<Cat> mark, int ruleno,
      const PseudoCatScope &scope,
      const NextTokenConstraints &nextTokenConstraints);
    int generateCat() { return --lastGeneratedCat; }

    /// cached initial graph
    QMultiHash<Cat, FullRule> initialGraph;
    /// cached neighborhoods
    QHash<QPair<Cat, Cat>, QList<FullRule> > neighborhoods;
    /// cached nullable categories (i.e. categories that can be epsilon)
    QSet<Cat> nullable;
    /// cached matches to epsilon
    QHash<Cat, QList<Match> > epsilonMatches;

    /// parse stacks to process after the next shift
    QList<StackItem> nextStacks;
    /// matches up to the current token (accepted iff the next shift is empty)
    QList<Match> currentMatches;
    /// current lexer state
    LexerState currentLexerState;
    /// indices of type 0 items for the given category at the current position
    QHash<Cat, int> type0Indices;
    /// matches accumulated at unification points
    /** The boolean specifies whether unification needs to be run (i.e., whether
     *  we got more than one list of matches).
     *
     *  This is more efficient as a hash table than as mutable members of
     *  StackItemData because, statistically, most unification points don't
     *  actually need any unification.
     */
    QHash<const StackItemData *, QPair<bool, QList<Match> > > collectedMatches;
    /// priority queue of stacks to process
    Private::PriorityQueue<StackItem> priorityQueue;
    /// whether processStack(Item) has branched to multiple parents
    /** If true, we need to always defer processing of unification points. */
    bool branched;
    /// position of error
    int errPos;
    /// token which triggered the error
    Cat errToken;
    /// last generated category (generated categories have negative IDs)
    int lastGeneratedCat;
};
DYNGENPAR_DECLARE_TYPEINFO(Parser, Q_MOVABLE_TYPE);

} // end namespace


// --- utility functions in the global namespace ---

Q_DECLARE_METATYPE(DynGenPar::PmcfgComponentInfo)

uint qHash(const QList<DynGenPar::Cat> &list);

template<>
  inline DynGenPar::StackItemData
    *QSharedDataPointer<DynGenPar::StackItemData>::clone()
{
  return d->clone();
}

template<>
  inline DynGenPar::AbstractLexerStateData
    *QSharedDataPointer<DynGenPar::AbstractLexerStateData>::clone()
{
  return d->clone();
}

inline QDataStream &operator<<(QDataStream &stream,
                               const DynGenPar::NextTokenConstraints &data) {
  return data.writeExternal(stream);
}

inline QDataStream &operator>>(QDataStream &stream,
                               DynGenPar::NextTokenConstraints &data) {
  return data.readExternal(stream);
}

inline QDataStream &operator<<(QDataStream &stream,
                               const DynGenPar::Rule &data) {
  return data.writeExternal(stream, DynGenPar::Rule::serializeLabels,
                            DynGenPar::Rule::serializeActions);
}

inline QDataStream &operator>>(QDataStream &stream, DynGenPar::Rule &data) {
  return data.readExternal(stream);
}

inline QDataStream &operator<<(QDataStream &stream,
                               const DynGenPar::Cfg &data) {
  return data.writeExternal(stream);
}

inline QDataStream &operator>>(QDataStream &stream, DynGenPar::Cfg &data) {
  return data.readExternal(stream);
}

inline QDataStream &operator<<(QDataStream &stream,
                               const DynGenPar::Action *data) {
  if (data) {
    data->writeExternal(stream);
    return stream;
  } else return stream << QString();
}

inline QDataStream &operator>>(QDataStream &stream, DynGenPar::Action *&data) {
  return DynGenPar::Action::constructAndRead(stream, data);
}

#endif // DYNGENPAR_H
