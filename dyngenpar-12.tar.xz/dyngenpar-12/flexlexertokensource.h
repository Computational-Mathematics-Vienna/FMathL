/* DynGenPar: Dynamic Generalized Parser - Flex lexer token source
   Copyright (C) 2010 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#ifndef DYNGENPAR_INTEGER_CATEGORIES
#define DYNGENPAR_INTEGER_CATEGORIES
#endif

#include <FlexLexer.h>
#include "dyngenpar.h"

namespace DynGenPar {

class FlexLexerTokenSource : public TokenSource {
  public:
    FlexLexerTokenSource(FlexLexer *lexer) : TokenSource(), flexLexer(lexer) {}
    virtual ~FlexLexerTokenSource() {}
  protected:
    virtual Cat readToken() {
      return flexLexer->yylex();
    }
    FlexLexer *flexLexer;
};
DYNGENPAR_DECLARE_TYPEINFO(FlexLexerTokenSource, Q_MOVABLE_TYPE);

} // end namespace
