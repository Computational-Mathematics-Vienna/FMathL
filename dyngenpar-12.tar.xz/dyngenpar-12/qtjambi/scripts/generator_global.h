#define _GNU_SOURCE
#include <sys/types.h>
#define QT_NO_STL
#include <QtCore/QtCore>
#include "../../pgf.h"
#include "../../bytetokensource.h"
