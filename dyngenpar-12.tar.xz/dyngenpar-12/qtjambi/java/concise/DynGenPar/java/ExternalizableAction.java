/* DynGenPar: Dynamic Generalized Parser
   Copyright (C) 2015-2017 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

package concise.DynGenPar.java;

import concise.DynGenPar.Action;
import com.trolltech.qt.core.QDataStream;
import java.io.Externalizable;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.io.IOException;

/**
 *  This class is a wrapper around Action that implements the serialization
 *  based on the Java Externalizable interface.
 */

public abstract class ExternalizableAction extends Action
                                           implements Externalizable {
  static {
    registerDeserializer("Java", new ExternalizableActionDeserializer());
  }

  @Override
  public void writeExternal(final QDataStream stream) {
    try {
      stream.writeString("Java");
      ObjectOutputStream oos = new ObjectOutputStream(new OutputStream() {
        @Override
        public void write(int b) throws IOException {
          stream.writeByte((byte) b);
          switch (stream.status()) {
            case Ok:
              break;
            case ReadPastEnd:
              throw new IOException("QDataStream wrote past end");
            case ReadCorruptData:
              throw new IOException("QDataStream wrote corrupt data");
            case WriteFailed:
              throw new IOException("QDataStream write failed");
            default:
              throw new IOException("QDataStream unknown error");
          }
        }
      });
      oos.writeObject(this);
    } catch (IOException e) {
      stream.setStatus(QDataStream.Status.WriteFailed);
    }
  }
}
