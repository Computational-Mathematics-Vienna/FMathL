#!/bin/sh

DYNGENPAR_JAR=`echo ../target/dyngenpar-*.jar`
JAMBI_JAR=`echo "$JAMBIDIR"/qtjambi-4.*.*.jar`
PLATFORM_JAR=`echo "$JAMBIDIR"/build/qtjambi-native-*-*-4.*.*.jar`
TEST_PGF=../../../../../users/kevin/app-grammar/Math.pgf
TEST_INPUT=../../../../../users/kevin/app-grammar/example1.txt
javac -cp "$DYNGENPAR_JAR":"$PLATFORM_JAR":"$JAMBI_JAR" PgfTestJava.java
if [ -f "$TEST_PGF" -a -f "$TEST_INPUT" ] ; then
  java -cp "$DYNGENPAR_JAR":"$PLATFORM_JAR":"$JAMBI_JAR":. PgfTestJava "$TEST_PGF" "$TEST_INPUT"
else
  echo "warning: test file(s) for PgfTestJava not found"
fi
