/* DynGenPar: Dynamic Generalized Parser - PGF import test program in Java
   Copyright (C) 2010-2011 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2014 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

// compare with pgftest.cpp, the same program in C++

import concise.DynGenPar.*;
import java.util.*;
import java.io.*;

public class PgfTestJava {
  private static void printPredictions(HashMap<Integer,
                                               List<NextTokenConstraints> >
                                         predictions, PgfParser pgfParser) {
    for (int prediction : predictions.keySet()) {
      System.err.print("expected: ");
      System.err.println(pgfParser.catName(prediction));
      if (!pgfParser.isToken(prediction)) {
        HashMap<Integer, Set<Integer> > expandedPrediction
          = pgfParser.expandNonterminalPredictionC(prediction,
                                                   predictions.get(prediction));
        for (int cat : expandedPrediction.keySet()) {
          System.err.print("expected category: ");
          System.err.println(pgfParser.catName(cat));
          for (int token : expandedPrediction.get(cat)) {
            System.err.print("expected token: ");
            System.err.println(pgfParser.catName(token));
          }
        }
      }
    }
  }

  private static void printLabel(Object label, PrintStream stream,
                                 PgfParser pgfParser) {
    if (label instanceof PmcfgComponentInfo) {
      PmcfgComponentInfo componentInfo = (PmcfgComponentInfo) label;
      Object function = componentInfo.pmcfgRule().label();
      if (function != null) {
        stream.print(" (");
        stream.print(pgfParser.functionName((Integer) function));
        stream.print(')');
      }
    }
  }

  private static void printSubtree(Node node, int level, PrintStream stream,
                                   PgfParser pgfParser) {
    int cat = node.cat();
    for (int i=0; i<level; i++) stream.print(' ');
    if (pgfParser.isToken(cat)) {
      stream.print(pgfParser.catName(cat));
      Object data = node.data();
      if (data != null) {
        boolean isString = (data instanceof String);
        stream.print('(');
        if (isString) stream.print('"');
        stream.print(data.toString().replace("\\","\\\\").replace("\"","\\\""));
        if (isString) stream.print('"');
        stream.print(')');
      }
      stream.println();
      return;
    }
    List<Alternative> children = node.children();
    switch (children.size()) {
      case 0: // no alternatives = error node
        for (int i=0; i<=level; i++) stream.print(' ');
        stream.println("ERROR");
        break;
      case 1: // 1 alternative, normal tree
        stream.print(pgfParser.catName(cat));
        printLabel(children.get(0).label(), stream, pgfParser);
        stream.println();
        for (Node child : children.get(0).toList())
          printSubtree(child, level+1, stream, pgfParser);
        break;
      default: // multiple alternatives
        stream.println(pgfParser.catName(cat));
        for (Alternative alternative : children) {
          for (int i=0; i<=level; i++) stream.print(' ');
          stream.print("ALTERNATIVE");
          printLabel(alternative.label(), stream, pgfParser);
          stream.println();
          for (Node child : alternative.toList())
            printSubtree(child, level+2, stream, pgfParser);
        }
        break;
    }
  }

  private static void printParseTree(Node tree, PgfParser pgfParser) {
    printSubtree(tree, 0, System.out, pgfParser);
  }

  private static void printSyntaxSubtree(Node node, int level,
                                         PrintStream stream,
                                         PgfParser pgfParser) {
    int cat = node.cat();
    for (int i=0; i<level; i++) stream.print(' ');
    if (cat == Pgf.TokenEpsilon) {
      stream.println("ERROR");
      return;
    }
    if (pgfParser.isToken(cat)) {
      stream.print(pgfParser.catName(cat));
      Object data = node.data();
      if (data != null) {
        boolean isString = (data instanceof String);
        stream.print('(');
        if (isString) stream.print('"');
        stream.print(data.toString().replace("\\","\\\\").replace("\"","\\\""));
        if (isString) stream.print('"');
        stream.print(')');
      }
      stream.println();
      return;
    }
    List<Alternative> children = node.children();
    switch (children.size()) {
      case 0: // no alternatives = metavariable
        stream.print('[');
        stream.print(pgfParser.catName(cat));
        stream.println(']');
        break;
      case 1: // 1 alternative, normal tree
        {
          Object label = children.get(0).label();
          stream.println(label != null
                         ? pgfParser.functionName((Integer) label)
                         : pgfParser.catName(cat));
          for (Node child : children.get(0).toList())
            printSyntaxSubtree(child, level+1, stream, pgfParser);
        }
        break;
      default: // multiple alternatives
        {
          stream.println("ALTERNATIVES");
          for (Alternative subtree : children) {
            for (int i=0; i<=level; i++) stream.print(' ');
            Object label = subtree.label();
            stream.println(label != null
                           ? pgfParser.functionName((Integer) label)
                           : pgfParser.catName(cat));
            for (Node child : subtree.toList())
              printSyntaxSubtree(child, level+2, stream, pgfParser);
          }
        }
        break;
    }
  }

  // prints PMCFG syntax trees
  private static void printSyntaxTree(Node tree, PgfParser pgfParser) {
    printSyntaxSubtree(tree, 0, System.out, pgfParser);
  }

  public static void main(String[] args) {
    if (args.length < 1) {
      System.err.println("usage: pgftest pgf_file [input_file]");
      System.exit(1);
    }

    boolean accepted = false;

    {
      PgfParser pgfParser = new PgfParser(args[0]);
      if (args.length > 1)
        pgfParser.setInputFile(args[1]);
      ParseState parseState = new ParseState();
      List<Match> matches = pgfParser.parse(parseState);
      if (parseState.errorPos() >= 0) {
        System.err.print("parse error at position ");
        System.err.print(parseState.errorPos());
        System.err.print(": unexpected ");
        System.err.print(pgfParser.catName(parseState.errorToken()));
      } else if (matches.isEmpty()) {
        System.err.println("parse error at end of input: incomplete input");
        printPredictions(pgfParser.computeConstrainedPredictions(parseState),
                         pgfParser);
      } else {
        for (Match m : matches) {
          accepted = true;
          Node tree = m.tree();
          printParseTree(tree, pgfParser);
          Node syntaxTree = Util.parseTreeToPmcfgSyntaxTree(tree);
          printSyntaxTree(syntaxTree, pgfParser);
          pgfParser.filterCoercionsFromSyntaxTree(syntaxTree);
          printSyntaxTree(syntaxTree, pgfParser);
        }
      }
    }

    System.exit(accepted ? 0 : 1);
  }
}
