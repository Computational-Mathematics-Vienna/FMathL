/* DynGenPar: Dynamic Generalized Parser - PGF import test program
   Copyright (C) 2010-2011 Kevin Kofler <kevin.kofler@chello.at>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

// compare with PgfTestJava.java, the same program in Java

#include <cstdio>
#include <QCoreApplication>
#include <QTextStream>
#include "pgf.h"

using namespace DynGenPar;

static QCoreApplication *app;

static void printPredictions(const ConstrainedPredictions &predictions,
                             PgfParser &pgfParser)
{
  QTextStream stream(stderr);
  foreach (CatArg prediction, predictions.uniqueKeys()) {
    stream << "expected: " << pgfParser.catName(prediction) << endl;
    if (!pgfParser.isToken(prediction)) {
      QHash<Cat, QSet<Cat> > expandedPrediction =
        pgfParser.expandNonterminalPredictionC(prediction,
                                               predictions.values(prediction));
      QHashIterator<Cat, QSet<Cat> > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " expected category: " << pgfParser.catName(cat) << endl;
        foreach (CatArg token, it.value())
          stream << "  expected token: " << pgfParser.catName(token) << endl;
      }
    }
  }
}

static void printLabel(const QVariant &label, QTextStream &stream,
                       const PgfParser &pgfParser) {
  if (label.canConvert<PmcfgComponentInfo>()) {
    PmcfgComponentInfo componentInfo = label.value<PmcfgComponentInfo>();
    QVariant function = componentInfo.pmcfgRule.label();
    if (function.isValid())
      stream << " (" << pgfParser.functionName(function.toInt()) << ')';
  }
}

static void printSubtree(const Node &node, int level, QTextStream &stream,
                         const PgfParser &pgfParser) {
  for (int i=0; i<level; i++) stream << ' ';
  if (pgfParser.isToken(node.cat)) {
    stream << pgfParser.catName(node.cat);
    if (node.data.isValid()) {
      bool isString = (node.data.type() == QVariant::String);
      stream << '(';
      if (isString) stream << '"';
      stream << node.data.toString().replace('\\',"\\\\").replace('"',"\\\"");
      if (isString) stream << '"';
      stream << ')';
    }
    stream << endl;
    return;
  }
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      for (int i=0; i<=level; i++) stream << ' ';
      stream << "ERROR" << endl;
      break;
    case 1: // 1 alternative, normal tree
      stream << pgfParser.catName(node.cat);
      printLabel(node.children.first().label(), stream, pgfParser);
      stream << endl;
      foreach (const Node &child, node.children.first())
        printSubtree(child, level+1, stream, pgfParser);
      break;
    default: // multiple alternatives
      stream << pgfParser.catName(node.cat) << endl;
      foreach (const Alternative &alternative, node.children) {
        for (int i=0; i<=level; i++) stream << ' ';
        stream << "ALTERNATIVE";
        printLabel(alternative.label(), stream, pgfParser);
        stream << endl;
        foreach (const Node &child, alternative)
          printSubtree(child, level+2, stream, pgfParser);
      }
      break;
  }
}

static void printParseTree(const Node &tree, const PgfParser &pgfParser) {
  QTextStream stream(stdout);
  printSubtree(tree, 0, stream, pgfParser);
}

static void printSyntaxSubtree(const Node &node, int level,
                               QTextStream &stream, const PgfParser &pgfParser)
{
  for (int i=0; i<level; i++) stream << ' ';
  if (IS_EPSILON(node.cat)) {
    stream << "ERROR" << endl;
    return;
  }
  if (pgfParser.isToken(node.cat)) {
    stream << pgfParser.catName(node.cat);
    if (node.data.isValid()) {
      bool isString = (node.data.type() == QVariant::String);
      stream << '(';
      if (isString) stream << '"';
      stream << node.data.toString().replace('\\',"\\\\").replace('"',"\\\"");
      if (isString) stream << '"';
      stream << ')';
    }
    stream << endl;
    return;
  }
  switch (node.children.size()) {
    case 0: // no alternatives = metavariable
      stream << '[' << pgfParser.catName(node.cat) << ']' << endl;
      break;
    case 1: // 1 alternative, normal tree
      {
        QVariant label = node.children.first().label();
        stream << (label.isValid()
                   ? pgfParser.functionName(label.toInt())
                   : pgfParser.catName(node.cat)) << endl;
        foreach (const Node &child, node.children.first())
          printSyntaxSubtree(child, level+1, stream, pgfParser);
      }
      break;
    default: // multiple alternatives
      {
        stream << "ALTERNATIVES" << endl;
        foreach (const Alternative &subtree, node.children) {
          for (int i=0; i<=level; i++) stream << ' ';
          QVariant label = subtree.label();
          stream << (label.isValid()
                    ? pgfParser.functionName(label.toInt())
                    : pgfParser.catName(node.cat)) << endl;
          foreach (const Node &child, subtree)
            printSyntaxSubtree(child, level+2, stream, pgfParser);
        }
      }
      break;
  }
}

// prints PMCFG syntax trees
static void printSyntaxTree(const Node &tree, const PgfParser &pgfParser)
{
  QTextStream stream(stdout);
  printSyntaxSubtree(tree, 0, stream, pgfParser);
}

// main function for testing purposes
int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);

  if (argc < 2) {
    QTextStream stream(stderr);
    stream << "usage: pgftest pgf_file [input_file]" << endl;
    return 1;
  }

  bool accepted = false;

  {
    PgfParser pgfParser(argv[1]);
    if (argc > 2)
      pgfParser.setInputFile(argv[2]);
    int errorPos;
    Cat errorToken;
    QList<StackItem> stacks;
    QList<Match> matches = pgfParser.parse(&errorPos, &errorToken, 0, &stacks);
    if (errorPos >= 0) {
      QTextStream stream(stderr);
      stream << "parse error at position " << errorPos << ": unexpected "
             << pgfParser.catName(errorToken) << endl;
    } else if (matches.isEmpty()) {
      {
        QTextStream stream(stderr);
        stream << "parse error at end of input: incomplete input" << endl;
      }
      printPredictions(pgfParser.computeConstrainedPredictions(stacks),
                       pgfParser);
    } else {
      foreach (const Match &m, matches) {
        accepted = true;
        printParseTree(m.tree, pgfParser);
        Node syntaxTree = parseTreeToPmcfgSyntaxTree(m.tree);
        printSyntaxTree(syntaxTree, pgfParser);
        pgfParser.filterCoercionsFromSyntaxTree(syntaxTree);
        printSyntaxTree(syntaxTree, pgfParser);
      }
    }
  }

  delete app;
  return !accepted;
}
