/* DynGenPar: Dynamic Generalized Parser - Naproche formula parser
   Copyright (C) 2010 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015-2016 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#define DYNGENPAR_INTEGER_CATEGORIES

#define yyFlexLexer NaprocheFormulaFlexLexer
#include <FlexLexer.h>
#undef yyFlexLexer
#include <sstream>
#include "dyngenpar.h"
#include "flexlexertokensource.h"
#include "naproche-cats.h"

#include "naproche-formulas.h"

using namespace DynGenPar;

class NaprocheFormulaTokenSource : public FlexLexerTokenSource {
  public:
    NaprocheFormulaTokenSource()
      : FlexLexerTokenSource(new NaprocheFormulaFlexLexer()) {
      flexLexer->switch_streams(&stream, static_cast<std::ostream *>(0));
    }
    virtual ~NaprocheFormulaTokenSource() {delete flexLexer;}
    void setInput(const std::string &input) {
      tree = Node();
      currPos = 0;
      stream.clear();
      stream.str(input);
    }
  private:
    std::istringstream stream;
};
Q_DECLARE_TYPEINFO(NaprocheFormulaTokenSource, Q_COMPLEX_TYPE);

NaprocheFormulaParser::NaprocheFormulaParser()
  : Parser(new NaprocheFormulaTokenSource) {
  tokens << DOLLAR << LPAREN << RPAREN << VAR_M << VAR_N << VAR_T << VAR_U
    << VAR_V << VAR_W << VAR_X << VAR_Y << VAR_Z << CST_EMPTYSET << CST_C
    << CST_0 << CST_1 << CST_2 << CST_3 << CST_4 << CST_5 << FUN_F << FUN_F2
    << FUN_G << FUN_H << FUN_STAR << FUN_PLUS << FUN_CARET << FUN_PRIME
    << FUN_SUCC << FUN_CUP << FUN_CAP << REL_EQ << REL_NEQ << REL_LT << REL_GT
    << REL_LEQ << REL_GEQ << REL_IN << REL_R << REL_SMALL_R << REL_M << REL_ORD
    << REL_TRANS << REL_CONTRADICTION << REL_SUBSET << REL_SUPSET
    << QUANT_FORALL << QUANT_EXISTS << LOG_NEG << LOG_AND << LOG_OR
    << LOG_IMPLIES << LOG_EQUIVALENT;

  rules[dollar_formula] << (Rule(62) << DOLLAR << formula << DOLLAR);

  rules[variable_symbol] << (Rule(63) << VAR_M)
                         << (Rule(64) << VAR_N)
                         << (Rule(65) << VAR_T)
                         << (Rule(66) << VAR_U)
                         << (Rule(67) << VAR_V)
                         << (Rule(68) << VAR_W)
                         << (Rule(69) << VAR_X)
                         << (Rule(70) << VAR_Y)
                         << (Rule(71) << VAR_Z);
  rules[constant_symbol] << (Rule(72) << CST_EMPTYSET)
                         << (Rule(73) << CST_C)
                         << (Rule(74) << CST_0)
                         << (Rule(75) << CST_1)
                         << (Rule(76) << CST_2)
                         << (Rule(77) << CST_3)
                         << (Rule(78) << CST_4)
                         << (Rule(79) << CST_5);
  rules[function_symbol] << (Rule(80) << FUN_F)
                         << (Rule(81) << FUN_F2)
                         << (Rule(82) << FUN_G)
                         << (Rule(83) << FUN_H)
                         << (Rule(84) << FUN_STAR)
                         << (Rule(85) << FUN_PLUS)
                         << (Rule(86) << FUN_CARET)
                         << (Rule(87) << FUN_PRIME)
                         << (Rule(88) << FUN_SUCC)
                         << (Rule(89) << FUN_CUP)
                         << (Rule(90) << FUN_CAP);
  rules[relation_symbol] << (Rule(91) << REL_EQ)
                         << (Rule(92) << REL_NEQ)
                         << (Rule(93) << REL_LT)
                         << (Rule(94) << REL_GT)
                         << (Rule(95) << REL_LEQ)
                         << (Rule(96) << REL_GEQ)
                         << (Rule(97) << REL_IN)
                         << (Rule(98) << REL_SUBSET)
                         << (Rule(99) << REL_SUPSET)
                         << (Rule(100) << REL_R)
                         << (Rule(101) << REL_SMALL_R)
                         << (Rule(102) << REL_M)
                         << (Rule(103) << REL_ORD)
                         << (Rule(104) << REL_TRANS)
                         << (Rule(105) << REL_CONTRADICTION);
  rules[quantifier] << (Rule(106) << QUANT_FORALL)
                    << (Rule(107) << QUANT_EXISTS);

  rules[term] << (Rule(108) << variable_symbol)
              << (Rule(109) << constant_symbol)
              << (Rule(110) << function_symbol << LPAREN << term_P << RPAREN)
              << (Rule(111) << LPAREN << term << function_symbol << term << RPAREN)
              << (Rule(112) << term << FUN_PRIME);
  rules[atomic_formula] << (Rule(113) << relation_symbol << LPAREN << term_L << RPAREN)
                        << (Rule(114) << term << relation_symbol << term)
                        << (Rule(115) << LPAREN << formula << RPAREN);
  rules[quant_formula] << (Rule(116) << atomic_formula)
                       << (Rule(117) << quantifier << variable_symbol_P << LPAREN << formula << RPAREN);
  rules[neg_formula] << (Rule(118) << quant_formula)
                     << (Rule(119) << LOG_NEG << neg_formula);
  rules[and_formula] << (Rule(120) << neg_formula)
                     << (Rule(121) << and_formula << LOG_AND << neg_formula);
  rules[or_formula] << (Rule(122) << and_formula)
                    << (Rule(123) << or_formula << LOG_OR << and_formula);
  rules[implies_formula] << (Rule(124) << or_formula)
                         << (Rule(125) << implies_formula << LOG_IMPLIES << or_formula);
  rules[formula] << (Rule(126) << implies_formula)
                 << (Rule(127) << formula << LOG_EQUIVALENT << implies_formula);

  rules[term_P] << (Rule(128) << term_P << term)
                << (Rule(129) << term);
  rules[variable_symbol_P] << (Rule(130) << variable_symbol_P << variable_symbol)
                           << (Rule(131) << variable_symbol);

  rules[term_L] << (Rule(132) << term_L << term)
                << Rule(133);

  startCat = dollar_formula;

  initCaches();
}

void NaprocheFormulaParser::setInput(const std::string &input) {
  static_cast<NaprocheFormulaTokenSource *>(inputSource)->setInput(input);
}
