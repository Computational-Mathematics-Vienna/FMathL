/* DynGenPar: Dynamic Generalized Parser - Graphical PGF import test program
   Copyright (C) 2010 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015-2017 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract number P20631
   is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#pragma once

#include <KMainWindow>
#include "ui_pgfgui-mainwindow.h"

#include "pgf.h"
#include <QByteArray>
#include <QList>
#include <QMap>
#include <QPair>
#include <QStack>

class QAction;

struct IncrementalState {
  IncrementalState() : pos(-1) {}
  QByteArray buffer;
  int pos;
  QList<DynGenPar::StackItem> stacks;
  QList<DynGenPar::Match> matches;
  DynGenPar::LexerState lexerState;
};
Q_DECLARE_TYPEINFO(IncrementalState, Q_MOVABLE_TYPE);

class MainWindow : public KMainWindow, public Ui::MainWindow
{
  Q_OBJECT

  public:
    MainWindow(QWidget* parent = 0,
               Qt::WindowFlags fl = KDE_DEFAULT_WINDOWFLAGS);
    virtual ~MainWindow();

    void loadPgf(const QString &fileName);

  private slots:
    void treeWidget_itemActivated(QTreeWidgetItem *item, int column);
    void open();
    void undo();
    void reset();
    void generateSyntaxTree();

  private:
    void predict();
    template<class ParentType>
      void generateSyntaxSubtree(const DynGenPar::Node &node,
                                 ParentType *parentItem);

    DynGenPar::PgfParser *pgfParser;
    IncrementalState incrementalState;
    // allows going back without having to reparse everything
    QStack<IncrementalState> incrementalHistory;
    QAction *undoAction;
};
Q_DECLARE_TYPEINFO(MainWindow, Q_COMPLEX_TYPE);
