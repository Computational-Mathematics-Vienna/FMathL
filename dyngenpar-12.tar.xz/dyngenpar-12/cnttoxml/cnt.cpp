/* CNT to XML: Parses a typesheet into a record and outputs an XML recordsheet
   Copyright (C) 2011-2013 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015-2018 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract numbers
   P20631 and P23554 is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */


#include "cnt.h"

using DynGenPar::Rule;

void CntParser::init() {
  for (int i=1; i<257; i++) tokens << i;

  // lexical rules

  QList<Rule> &hcharRules = rules[L_hchar];
  hcharRules << (Rule(1) << ByteTokenNul);
  for (int i=1; i<10; i++) hcharRules << (Rule(1+i) << i);
  for (int i=11; i<13; i++) hcharRules << (Rule(i) << i);
  for (int i=14; i<256; i++) hcharRules << (Rule(-1+i) << i);
  // rules 1 ... 254

  rules[L_char] << (Rule(255) << L_hchar)
                << (Rule(256) << '\n');

  QList<Rule> &letterRules = rules[L_letter];
  for (int i=0; i<26; i++) letterRules << (Rule(257+i) << ('A'+i));
  for (int i=0; i<26; i++) letterRules << (Rule(283+i) << ('a'+i));
  // rules 257 ... 308

  QList<Rule> &digitRules = rules[L_digit];
  for (int i=0; i<10; i++) digitRules << (Rule(309+i) << ('0'+i));
  // rules 309 ... 318

  Rule rule319(319);
  rule319.nextTokenConstraints.taboo << ' ';
  rules[L_blanks] << rule319 << (Rule(320) << ' ' << L_blanks);

  Rule rule321(321);
  rule321 << '\n';
  rule321.nextTokenConstraints.taboo << '\n';
  rules[L_eol_only] << rule321 << (Rule(322) << '\n' << L_eol_only);

  rules[L_eol] << (Rule(323) << L_blanks << L_eol_only);

  rules[L_whitespace] << (Rule(324) << L_blanks)
                      << (Rule(325) << L_eol << L_blanks);

  rules[L_word_char] << (Rule(326) << L_letter) << (Rule(327) << L_digit);

  QList<Rule> &hasciiRules = rules[L_hascii];
  hasciiRules << (Rule(510) << ByteTokenNul);
  for (int i=1; i<10; i++) hasciiRules << (Rule(510+i) << i);
  for (int i=11; i<13; i++) hasciiRules << (Rule(509+i) << i);
  for (int i=14; i<128; i++) hasciiRules << (Rule(508+i) << i);
  // rules 510 ... 635

  QList<Rule> &utf8s2Rules = rules[L_utf8s2];
  for (int i=192; i<=223; i++) utf8s2Rules << (Rule(444+i) << i);
  // rules 636 ... 667

  QList<Rule> &utf8s3Rules = rules[L_utf8s3];
  for (int i=224; i<=239; i++) utf8s3Rules << (Rule(444+i) << i);
  // rules 668 ... 683

  QList<Rule> &utf8s4Rules = rules[L_utf8s4];
  for (int i=240; i<=247; i++) utf8s4Rules << (Rule(444+i) << i);
  // rules 684 ... 691

  QList<Rule> &utf8contRules = rules[L_utf8cont];
  for (int i=128; i<=191; i++) utf8contRules << (Rule(564+i) << i);
  // rules 692 ... 755

  // Optimized to be left recursive, see comment about Line below.
  rules[L_line] << Rule(330) << (Rule(331) << L_line << L_hchar);

  // Yes, L_id_word can be empty, it's only used as the second part of L_id
  Rule rule332(332);
  rule332.nextTokenConstraints.taboo << L_word_char;
  rules[L_id_word] << rule332 << (Rule(333) << L_word_char << L_id_word);

  rules[L_id] << (Rule(334) << L_letter << L_id_word);

  Rule rule501(501);
  rule501 << L_digit;
  rule501.nextTokenConstraints.taboo << L_digit;
  rules[L_digits] << rule501 << (Rule(502) << L_digit << L_digits);

  Rule rule762(762);
  rule762.nextTokenConstraints.taboo << ':';
  rules[L_foreignword_char_taboo] << rule762;

  rules[L_foreignword_char] << (Rule(763) << L_foreignword_char_taboo
                                          << L_hchar);

  rules[L_foreignword] << (Rule(764) << L_foreignword_char)
                       << (Rule(765) << L_foreignword_char << L_foreignword);

  // escape rules

  Rule rule335(335);
  rule335.nextTokenConstraints.taboo << '"';
  rules[L_outchar_taboo] << rule335;

  rules[L_outchar] << (Rule(336) << L_outchar_taboo << L_char);

  Rule rule337(337);
  rule337.nextTokenConstraints.taboo << '!' << '#' << '&' << ' ';
  rules[L_litchar_taboo] << rule337;

  rules[L_litchar] << (Rule(338) << L_litchar_taboo << L_hascii)
                   << (Rule(759) << L_utf8s2 << L_utf8cont)
                   << (Rule(760) << L_utf8s3 << L_utf8cont << L_utf8cont)
                   << (Rule(761) << L_utf8s4 << L_utf8cont << L_utf8cont
                                 << L_utf8cont)
                   << (Rule(339) << '&' << '!')
                   << (Rule(340) << '&' << '#')
                   << (Rule(341) << '&' << 'n')
                   << (Rule(342) << '&' << 'b')
                   << (Rule(477) << '&' << 't')
                   << (Rule(478) << '&' << 'c')
                   << (Rule(343) << '&' << '0')
                   << (Rule(344) << '&' << '1')
                   << (Rule(345) << '&' << '2')
                   << (Rule(346) << '&' << '3')
                   << (Rule(347) << '&' << '4')
                   << (Rule(348) << '&' << '5')
                   << (Rule(349) << '&' << '6')
                   << (Rule(350) << '&' << '7')
                   << (Rule(351) << '&' << '8')
                   << (Rule(352) << '&' << '9');


  // grammar rules

  rules[TypeSheet] << (Rule(811) << Header << EntryLink)
                   << (Rule(354) << Header << Targets << EntryLink)
                   << (Rule(812) << Header << StartCategory << EntryLink)
                   << (Rule(355) << Header << Targets << StartCategory
                                 << EntryLink)
                   << (Rule(813) << Header << EntryLink << L_eol)
                   << (Rule(356) << Header << Targets << EntryLink << L_eol)
                   << (Rule(814) << Header << StartCategory << EntryLink
                                 << L_eol)
                   << (Rule(357) << Header << Targets << StartCategory
                                 << EntryLink << L_eol)
                   << (Rule(815) << Header << EntryLink << L_eol << CommentLink)
                   << (Rule(358) << Header << Targets << EntryLink << L_eol
                                 << CommentLink)
                   << (Rule(816) << Header << StartCategory << EntryLink
                                 << L_eol << CommentLink)
                   << (Rule(359) << Header << Targets << StartCategory
                                 << EntryLink << L_eol << CommentLink)
                   << (Rule(817) << Header << EntryLink << L_eol << CommentLink
                                 << L_eol)
                   << (Rule(360) << Header << Targets << EntryLink << L_eol
                                 << CommentLink << L_eol)
                   << (Rule(818) << Header << StartCategory << EntryLink
                                 << L_eol << CommentLink << L_eol)
                   << (Rule(361) << Header << Targets << StartCategory
                                 << EntryLink << L_eol << CommentLink << L_eol);

  rules[Header] << (Rule(362) << Id << '(' << Id << ',' << L_blanks << Id
                              << ')' << ':' << ':' << L_eol << CommentLink)
                << (Rule(363) << Id << '(' << Id << ',' << L_blanks << Id
                              << ')' << ':' << ':' << L_whitespace << ImportLink
                              << L_eol << CommentLink)
                << (Rule(767) << Id << '(' << Id << ',' << L_blanks << Id
                              << ')' << ':' << ':' << L_eol << CommentLink
                              << TranslationLink)
                << (Rule(768) << Id << '(' << Id << ',' << L_blanks << Id
                              << ')' << ':' << ':' << L_whitespace << ImportLink
                              << L_eol << CommentLink << TranslationLink);

  rules[Id] << (Rule(364) << L_id);

  rules[PosInt] << (Rule(503) << L_digits);

  rules[ForeignId] << (Rule(766) << L_foreignword);

  rules[ImportLink] << (Rule(365) << Id)
                    << (Rule(366) << Id << '.' << Id)
                    << (Rule(367) << Id << '.' << Id << '-' << '>' << Id)
                    << (Rule(368) << Id << ',' << L_whitespace << ImportLink)
                    << (Rule(369) << Id << '.' << Id << ',' << L_whitespace
                                  << ImportLink)
                    << (Rule(370) << Id << '.' << Id << '-' << '>' << Id << ','
                                  << L_whitespace << ImportLink);

  rules[TranslationLink] << (Rule(769) << L_eol << ':' << 'L' << 'A' << 'N'
                                       << 'G' << ':' << L_blanks << Id
                                       << L_blanks << '\n' << IdTranslationLink)
                         << (Rule(770) << L_eol << CommentLink << ':' << 'L'
                                       << 'A' << 'N' << 'G' << ':' << L_blanks
                                       << Id << L_blanks << '\n'
                                       << IdTranslationLink)
                         << (Rule(771) << L_eol << ':' << 'L' << 'A' << 'N'
                                       << 'G' << ':' << L_blanks << Id
                                       << L_blanks << '\n' << IdTranslationLink
                                       << TranslationLink)
                         << (Rule(772) << L_eol << CommentLink << ':' << 'L'
                                       << 'A' << 'N' << 'G' << ':' << L_blanks
                                       << Id << L_blanks << '\n'
                                       << IdTranslationLink << TranslationLink);

  rules[IdTranslationLink] << (Rule(773) << ':' << ':' << ForeignId << ':'
                                         << L_blanks << Id << L_blanks << '\n')
                           << (Rule(774) << ':' << ':' << ForeignId << ':'
                                         << L_blanks << Id << L_blanks << '\n'
                                         << IdTranslationLink);

  rules[CommentLink] << (Rule(371) << Comment)
                     << (Rule(372) << Comment << CommentLink);

  rules[Comment] << (Rule(373) << L_blanks << '!' << L_blanks << Line << '\n');

  /* The rules for Line / L_line are optimized to be left recursive (twice as
     fast). For that purpose, the next token constraint has to be carried by
     Line, not L_line. */
  Rule rule374(374);
  rule374 << L_line;
  rule374.nextTokenConstraints.taboo << L_hchar;
  rules[Line] << rule374;

  rules[Targets] << (Rule(375) << L_eol << ':' << 'T' << 'A' << 'R' << 'G'
                               << 'E' << 'T' << '>' << L_blanks << TargetLink)
                 << (Rule(376) << L_eol << CommentLink << ':' << 'T' << 'A'
                               << 'R' << 'G' << 'E' << 'T' << '>' << L_blanks
                               << TargetLink);

  rules[TargetLink] << (Rule(377) << Target)
                    << (Rule(378) << Target << L_blanks << TargetLink);

  rules[Target] << (Rule(379) << FieldLink << '=' << VarLink << Comment)
                << (Rule(380) << FieldLink << '=' << VarLink << L_blanks
                              << '\n');

  rules[FieldLink] << (Rule(381) << Id)
                   << (Rule(382) << Id << '.' << FieldLink);

  rules[VarLink] << (Rule(383) << '#' << Id)
                 << (Rule(384) << '#' << Id << ' ' << VarLink);

  rules[StartCategory] << (Rule(385) << ':' << 'S' << 'T' << 'A' << 'R' << 'T'
                                     << '=' << Id << Comment)
                       << (Rule(386) << ':' << 'S' << 'T' << 'A' << 'R' << 'T'
                                     << '=' << Id << L_blanks << '\n');

  rules[EntryLink] << (Rule(387) << L_eol << LitDef)
                   << (Rule(388) << L_eol << CatDef)
                   << (Rule(389) << L_eol << LitDef << EntryLink)
                   << (Rule(390) << L_eol << CatDef << EntryLink);

  rules[LitDef] << (Rule(391) << ':' << CommentLink << LitLink)
                << (Rule(392) << ':' << L_blanks << '\n' << LitLink)
                << (Rule(393) << CommentLink << ':' << CommentLink << LitLink)
                << (Rule(394) << CommentLink << ':' << L_blanks << '\n'
                              << LitLink);

  rules[LitLink] << (Rule(395) << LitProduction)
                 << (Rule(396) << LitProduction << LitLink);

  rules[LitProduction] << (Rule(397) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << '#' << '#' << Id << '='
                                     << Substitution << CommentLink)
                       << (Rule(398) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << '#' << '#' << Id << '='
                                     << Substitution << L_blanks << '\n')
                       << (Rule(399) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << '#' << '#' << Id << '='
                                     << AlternativeLink << CommentLink)
                       << (Rule(400) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << '#' << '#' << Id << '='
                                     << AlternativeLink << '\n')
                       << (Rule(504) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << '#' << '#' << Id << '='
                                     << '#' << '[' << CRangeLink << ']'
                                     << CommentLink)
                       << (Rule(505) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << '#' << '#' << Id << '='
                                     << '#' << '[' << CRangeLink << ']'
                                     << L_blanks << '\n');

  rules[Substitution] << (Rule(401) << CharLink << '&' << '"' << '"')
                      << (Rule(402) << CharLink << '&' << '"' << OutCharLink
                                    << '"');

  rules[CRange] << (Rule(506) << PosInt)
                << (Rule(507) << PosInt << '-' << PosInt);

  rules[CRangeLink] << (Rule(508) << CRange)
                    << (Rule(509) << CRange << ',' << L_blanks << CRangeLink);

  rules[Char] << (Rule(403) << L_litchar);

  rules[CharLink] << (Rule(404) << Char)
                  << (Rule(405) << Char << CharLink);

  rules[OutChar] << (Rule(406) << L_outchar);

  rules[OutCharLink] << (Rule(407) << OutChar)
                     << (Rule(408) << OutChar << OutCharLink);

  rules[Alternative] << (Rule(479) << ElementLink);

  rules[AlternativeLink] << (Rule(409) << Alternative)
                         << (Rule(410) << Alternative << '&' << '|'
                                       << AlternativeLink);

  rules[ElementLink] << (Rule(411) << Element)
                     << (Rule(412) << Element << ElementLink);

  rules[Element] << (Rule(413) << CatVar)
                 << (Rule(414) << CatVar << MatchCase)
                 << (Rule(415) << LitVar)
                 << (Rule(416) << LitVar << MatchCase)
                 << (Rule(417) << Char)
                 << (Rule(418) << Char << MatchCase)
                 << (Rule(485) << LitId)
                 << (Rule(486) << LitId << MatchCase)
                 << (Rule(494) << Function)
                 << (Rule(495) << Function << MatchCase)
                 << (Rule(328) << Blanks)
                 << (Rule(480) << LineBreak)
                 << (Rule(419) << '&' << '[' << AlternativeLink << '&' << ']')
                 << (Rule(420) << '&' << '[' << AlternativeLink << '&' << ']'
                               << MatchCase)
                 << (Rule(421) << '&' << '(' << AlternativeLink << '&' << ')')
                 << (Rule(422) << '&' << '(' << AlternativeLink << '&' << ')'
                               << MatchCase)
                 << (Rule(423) << '&' << '{' << AlternativeLink << '&' << '}')
                 << (Rule(424) << '&' << '{' << AlternativeLink << '&' << '}'
                               << MatchCase)
                 << (Rule(425) << '&' << '<' << AlternativeLink << '&' << '>')
                 << (Rule(426) << '&' << '<' << AlternativeLink << '&' << '>'
                               << MatchCase);

  Rule rule329(329);
  rule329 << ' ' << L_blanks;
  rule329.nextTokenConstraints.taboo << '!';
  rules[Blanks] << rule329;

  rules[LineBreak] << (Rule(353) << '&' << '&' << '\n');

  rules[MatchCase] << (Rule(427) << L_blanks << Maximal)
                   << (Rule(428) << L_blanks << Expect)
                   << (Rule(429) << L_blanks << Taboo)
                   << (Rule(430) << L_blanks << Except);

  rules[Maximal] << (Rule(431) << '&' << '+');

  rules[Expect] << (Rule(432) << '&' << 'E' << Element);

  rules[Taboo] << (Rule(433) << '&' << 'T' << Element);

  rules[Except] << (Rule(434) << '&' << '^' << Element);

  rules[CatVar] << (Rule(487) << '#' << CatVarRec)
                << (Rule(488) << '#' << CatVarName)
                << (Rule(489) << '#' << CatVarId);

  rules[CatVarRec] << (Rule(435) << Id);

  rules[CatVarName] << (Rule(490) << '>' << Id)
                    << (Rule(491) << '>' << '&' << 't' << 'h' << 'i' << 's');

  rules[CatVarId] << (Rule(492) << '=' << Id)
                  << (Rule(493) << '=' << '&' << 't' << 'h' << 'i' << 's');

  rules[LitVar] << (Rule(436) << '#' << '#' << Id);

  rules[LitId] << (Rule(483) << '&' << '=' << '&' << '(' << ElementLink << '&'
                             << ')');

  rules[FunArg] << (Rule(496) << ElementLink);

  rules[FunArgLink] << (Rule(497) << FunArg)
                    << (Rule(498) << FunArg << '&' << ',' << FunArgLink);

  rules[Function] << (Rule(499) << '#' << '!' << Id << L_blanks << '&' << '('
                                << '&' << ')')
                  << (Rule(500) << '#' << '!' << Id << L_blanks << '&' << '('
                                << FunArgLink << '&' << ')');

  rules[CatDef] << (Rule(481) << Id << ':' << ' ' << Id << '+' << '\n'
                              << SpecLink)
                << (Rule(482) << Id << ':' << ' ' << Id << '+' << '\n'
                              << SpecLink << CatLink)
                << (Rule(484) << Id << ':' << ' ' << Id << '+' << '\n'
                              << SpecLink << CatLink << IrrLink)
                << (Rule(756) << Id << ':' << ' ' << Id << '+' << '\n'
                              << CommentLink << SpecLink)
                << (Rule(757) << Id << ':' << ' ' << Id << '+' << '\n'
                              << CommentLink << SpecLink << CatLink)
                << (Rule(758) << Id << ':' << ' ' << Id << '+' << '\n'
                              << CommentLink << SpecLink << CatLink << IrrLink)
                << (Rule(803) << CommentLink << Id << ':' << ' ' << Id << '+'
                              << '\n' << SpecLink)
                << (Rule(804) << CommentLink << Id << ':' << ' ' << Id << '+'
                              << '\n' << SpecLink << CatLink)
                << (Rule(805) << CommentLink << Id << ':' << ' ' << Id << '+'
                              << '\n' << SpecLink << CatLink << IrrLink)
                << (Rule(806) << CommentLink << Id << ':' << ' ' << Id << '+'
                              << '\n' << CommentLink << SpecLink)
                << (Rule(807) << CommentLink << Id << ':' << ' ' << Id << '+'
                              << '\n' << CommentLink << SpecLink << CatLink)
                << (Rule(808) << CommentLink << Id << ':' << ' ' << Id << '+'
                              << '\n' << CommentLink << SpecLink << CatLink
                              << IrrLink)
                << (Rule(437) << Id << ':' << '\n' << SpecLink)
                << (Rule(438) << Id << ':' << '\n' << SpecLink << CatLink)
                << (Rule(439) << Id << ':' << '\n' << SpecLink << CatLink
                              << IrrLink)
                << (Rule(440) << Id << ':' << '\n' << CommentLink << SpecLink)
                << (Rule(441) << Id << ':' << '\n' << CommentLink << SpecLink
                              << CatLink)
                << (Rule(442) << Id << ':' << '\n' << CommentLink << SpecLink
                              << CatLink << IrrLink)
                << (Rule(443) << CommentLink << Id << ':' << '\n' << SpecLink)
                << (Rule(444) << CommentLink << Id << ':' << '\n' << SpecLink
                              << CatLink)
                << (Rule(445) << CommentLink << Id << ':' << '\n' << SpecLink
                              << CatLink << IrrLink)
                << (Rule(446) << CommentLink << Id << ':' << '\n' << CommentLink
                              << SpecLink)
                << (Rule(447) << CommentLink << Id << ':' << '\n' << CommentLink
                              << SpecLink << CatLink)
                << (Rule(448) << CommentLink << Id << ':' << '\n' << CommentLink
                              << SpecLink << CatLink << IrrLink);

  rules[SpecLink] << (Rule(449) << Spec)
                  << (Rule(450) << Spec << SpecLink);

  rules[Spec] << (Rule(451) << AllOfSpec)
              << (Rule(452) << OneOfSpec)
              << (Rule(453) << SomeOfSpec)
              << (Rule(775) << OptionalSpec)
              << (Rule(776) << FixedSpec)
              << (Rule(777) << OnlySpec)
              << (Rule(778) << SomeOfTypeSpec)
              << (Rule(779) << ItselfSpec)
              << (Rule(780) << ArraySpec)
              << (Rule(781) << IndexSpec)
              << (Rule(782) << TemplateSpec)
              << (Rule(783) << NothingElseSpec)
              << (Rule(784) << NothingSpec)
              << (Rule(785) << UnionSpec)
              << (Rule(786) << AtomicSpec)
              << (Rule(787) << CompleteSpec);

  rules[AllOfSpec] << (Rule(788) << 'a' << 'l' << 'l' << 'O' << 'f' << '>'
                                 << L_blanks << EqLink);

  rules[OneOfSpec] << (Rule(789) << 'o' << 'n' << 'e' << 'O' << 'f' << '>'
                                 << L_blanks << EqLink);

  rules[SomeOfSpec] << (Rule(790) << 's' << 'o' << 'm' << 'e' << 'O' << 'f'
                                  << '>' << L_blanks << EqLink);

  rules[OptionalSpec] << (Rule(791) << 'o' << 'p' << 't' << 'i' << 'o' << 'n'
                                    << 'a' << 'l' << '>' << L_blanks << EqLink);

  rules[FixedSpec] << (Rule(792) << 'f' << 'i' << 'x' << 'e' << 'd' << '>'
                                 << L_blanks << EqLink);

  rules[OnlySpec] << (Rule(793) << 'o' << 'n' << 'l' << 'y' << '>' << L_blanks
                                << EqLink);

  rules[SomeOfTypeSpec] << (Rule(794) << 's' << 'o' << 'm' << 'e' << 'O' << 'f'
                                      << 'T' << 'y' << 'p' << 'e' << '>'
                                      << L_blanks << EqLink);

  rules[ItselfSpec] << (Rule(795) << 'i' << 't' << 's' << 'e' << 'l' << 'f'
                                  << '>' << L_blanks << NameLink);

  rules[ArraySpec] << (Rule(796) << 'a' << 'r' << 'r' << 'a' << 'y' << '>'
                                 << L_blanks << EqLink);

  rules[IndexSpec] << (Rule(797) << 'i' << 'n' << 'd' << 'e' << 'x' << '>'
                                 << L_blanks << EqLink);

  rules[TemplateSpec] << (Rule(798) << 't' << 'e' << 'm' << 'p' << 'l' << 'a'
                                    << 't' << 'e' << '>' << L_blanks << Id
                                    << L_blanks << '\n');

  rules[NothingElseSpec] << (Rule(799) << 'n' << 'o' << 't' << 'h' << 'i' << 'n'
                                       << 'g' << 'E' << 'l' << 's' << 'e' << '>'
                                       << L_blanks << '\n');

  rules[NothingSpec] << (Rule(466) << 'n' << 'o' << 't' << 'h' << 'i' << 'n'
                                   << 'g' << '>' << L_blanks << '\n');

  rules[UnionSpec] << (Rule(800) << 'u' << 'n' << 'i' << 'o' << 'n' << '>'
                                 << L_blanks << NameLink);

  rules[AtomicSpec] << (Rule(801) << 'a' << 't' << 'o' << 'm' << 'i' << 'c'
                                  << '>' << L_blanks << NameLink);

  rules[CompleteSpec] << (Rule(802) << 'c' << 'o' << 'm' << 'p' << 'l' << 'e'
                                    << 't' << 'e' << '>' << L_blanks << '\n');

  rules[EqLink] << (Rule(454) << Id << '=' << Id << L_blanks << '\n')
                << (Rule(455) << Id << '=' << Id << Comment)
                << (Rule(456) << '#' << Id << ':' << Id << '=' << Id << L_blanks
                              << '\n')
                << (Rule(457) << '#' << Id << ':' << Id << '=' << Id << Comment)
                << (Rule(458) << Id << '=' << Id << L_blanks << '\n' << L_blanks
                              << EqLink)
                << (Rule(459) << Id << '=' << Id << Comment << L_blanks
                              << EqLink)
                << (Rule(460) << '#' << Id << ':' << Id << '=' << Id << L_blanks
                              << '\n' << L_blanks << EqLink)
                << (Rule(461) << '#' << Id << ':' << Id << '=' << Id << Comment
                              << L_blanks << EqLink);

  rules[NameLink] << (Rule(462) << Id << '\n')
                  << (Rule(463) << '#' << Id << ':' << Id << '\n')
                  << (Rule(464) << Id << ',' << ' ' << NameLink)
                  << (Rule(465) << '#' << Id << ':' << Id << ',' << ' '
                                << NameLink)
                  << (Rule(809) << Id << ',' << L_eol << L_blanks << NameLink)
                  << (Rule(810) << '#' << Id << ':' << Id << ',' << L_eol
                                << L_blanks << NameLink);

  rules[CatLink] << (Rule(467) << CatProduction)
                 << (Rule(468) << CatProduction << CatLink);

  rules[CatProduction] << (Rule(469) << L_blanks << '#' << Id << '>' << ' '
                                     << AlternativeLink << '\n')
                       << (Rule(470) << L_blanks << '#' << Id << '>' << ' '
                                     << AlternativeLink << CommentLink)
                       << (Rule(471) << L_blanks << '#' << Id << '>' << ' '
                                     << '#' << L_blanks << '\n')
                       << (Rule(472) << L_blanks << '#' << Id << '>' << ' '
                                     << '#' << ' ' << CommentLink);

  rules[IrrLink] << (Rule(473) << IrrProduction)
                 << (Rule(474) << IrrProduction << IrrLink);

  rules[IrrProduction] << (Rule(475) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << Id << '=' << AlternativeLink
                                     << '\n')
                       << (Rule(476) << L_blanks << '#' << Id << '>' << '>'
                                     << ' ' << Id << '=' << AlternativeLink
                                     << CommentLink);


  startCat = TypeSheet;

  initCaches();
}
