/* CNT to XML: Parses a typesheet into a record and outputs an XML recordsheet
   Copyright (C) 2011 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015 DAGOPT Optimization Technologies GmbH
                      written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract numbers
   P20631 and P23554 is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#pragma once

#ifndef DYNGENPAR_INTEGER_CATEGORIES
#define DYNGENPAR_INTEGER_CATEGORIES
#endif

#include "dyngenpar.h"
#include "bytetokensource.h"

#include <QStringList>

// nonterminals only, tokens are defined in ByteTokens
enum Cats {
  L_hchar = 258,
  L_char,
  L_letter,
  L_digit,
  L_blanks,
  L_eol_only,
  L_eol,
  L_whitespace,
  L_word_char,
  L_hascii,
  L_utf8s2,
  L_utf8s3,
  L_utf8s4,
  L_utf8cont,
  L_line,
  L_id_word,
  L_id,
  L_digits,
  L_foreignword_char_taboo,
  L_foreignword_char,
  L_foreignword,
  L_outchar_taboo,
  L_outchar,
  L_litchar_taboo,
  L_litchar,
  TypeSheet,
  Header,
  Id,
  PosInt,
  ForeignId,
  ImportLink,
  TranslationLink,
  IdTranslationLink,
  CommentLink,
  Comment,
  Line,
  Targets,
  TargetLink,
  Target,
  FieldLink,
  VarLink,
  StartCategory,
  EntryLink,
  LitDef,
  LitLink,
  LitProduction,
  Substitution,
  CRange,
  CRangeLink,
  Char,
  CharLink,
  OutChar,
  OutCharLink,
  Alternative,
  AlternativeLink,
  ElementLink,
  Element,
  Blanks,
  LineBreak,
  MatchCase,
  Maximal,
  Expect,
  Taboo,
  Except,
  CatVar,
  CatVarRec,
  CatVarName,
  CatVarId,
  LitVar,
  LitId,
  FunArg,
  FunArgLink,
  Function,
  CatDef,
  SpecLink,
  Spec,
  AllOfSpec,
  OneOfSpec,
  SomeOfSpec,
  OptionalSpec,
  FixedSpec,
  OnlySpec,
  SomeOfTypeSpec,
  ItselfSpec,
  ArraySpec,
  IndexSpec,
  TemplateSpec,
  NothingElseSpec,
  NothingSpec,
  UnionSpec,
  AtomicSpec,
  CompleteSpec,
  EqLink,
  NameLink,
  CatLink,
  CatProduction,
  IrrLink,
  IrrProduction
};
Q_DECLARE_TYPEINFO(Cats, Q_PRIMITIVE_TYPE);


inline QStringList getCategoryNames() {
  QStringList result;

  // dummy category
  result << "EPSILON"

  // tokens
  << "SOH" << "STX" << "ETX" << "EOT" << "ENQ" << "ACK" << "BEL" << "BS" << "HT"
  << "LF" << "VT" << "FF" << "CR" << "SO" << "SI" << "DLE" << "DC1" << "DC2"
  << "DC3" << "DC4" << "NAK" << "SYN" << "ETB" << "CAN" << "EM" << "SUB"
  << "ESC" << "FS" << "GS" << "RS" << "US" << "SP";
  for (int i=33; i<127; i++) result << QChar(i);
  result << "DEL";
  for (int i=128; i<256; i++) result << ("\\x" + QString::number(i, 16));
  result << "NUL"

  // dummy category
  << "ERROR"

  // nonterminals
  << "##hchar"
  << "##char"
  << "##letter"
  << "##digit"
  << "##blanks"
  << "##eol_only"
  << "##eol"
  << "##whitespace"
  << "##word_char"
  << "##hascii"
  << "##utf8s2"
  << "##utf8s3"
  << "##utf8s4"
  << "##utf8cont"
  << "##line"
  << "##id_word"
  << "##id"
  << "##digits"
  << "##foreignword_char_taboo"
  << "##foreignword_char"
  << "##foreignword"
  << "##outchar_taboo"
  << "##outchar"
  << "##litchar_taboo"
  << "##litchar"
  << "TypeSheet"
  << "Header"
  << "Id"
  << "PosInt"
  << "ForeignId"
  << "ImportLink"
  << "TranslationLink"
  << "IdTranslationLink"
  << "CommentLink"
  << "Comment"
  << "Line"
  << "Targets"
  << "TargetLink"
  << "Target"
  << "FieldLink"
  << "VarLink"
  << "StartCategory"
  << "EntryLink"
  << "LitDef"
  << "LitLink"
  << "LitProduction"
  << "Substitution"
  << "CRange"
  << "CRangeLink"
  << "Char"
  << "CharLink"
  << "OutChar"
  << "OutCharLink"
  << "Alternative"
  << "AlternativeLink"
  << "ElementLink"
  << "Element"
  << "Blanks"
  << "LineBreak"
  << "MatchCase"
  << "Maximal"
  << "Expect"
  << "Taboo"
  << "Except"
  << "CatVar"
  << "CatVarRec"
  << "CatVarName"
  << "CatVarId"
  << "LitVar"
  << "LitId"
  << "FunArg"
  << "FunArgLink"
  << "Function"
  << "CatDef"
  << "SpecLink"
  << "Spec"
  << "AllOfSpec"
  << "OneOfSpec"
  << "SomeOfSpec"
  << "OptionalSpec"
  << "FixedSpec"
  << "OnlySpec"
  << "SomeOfTypeSpec"
  << "ItselfSpec"
  << "ArraySpec"
  << "IndexSpec"
  << "TemplateSpec"
  << "NothingElseSpec"
  << "NothingSpec"
  << "UnionSpec"
  << "AtomicSpec"
  << "CompleteSpec"
  << "EqLink"
  << "NameLink"
  << "CatLink"
  << "CatProduction"
  << "IrrLink"
  << "IrrProduction";

  return result;
}

class CntParser : public DynGenPar::Parser {
  public:
    CntParser() : Parser(new DynGenPar::TextByteTokenSource) {init();}
    CntParser(const QString &fileName)
      : Parser(new DynGenPar::TextByteTokenSource(fileName)) {init();}
    virtual ~CntParser() {delete inputSource;}
    void setInputFile(const QString &fileName) {
      static_cast<DynGenPar::TextByteTokenSource *>(inputSource)
        ->setInputFile(fileName);
    }
  private:
    void init();
};
Q_DECLARE_TYPEINFO(CntParser, Q_MOVABLE_TYPE);
