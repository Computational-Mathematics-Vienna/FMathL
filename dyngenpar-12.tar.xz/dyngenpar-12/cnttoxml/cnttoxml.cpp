/* CNT to XML: Parses a typesheet into a record and outputs an XML recordsheet
   Copyright (C) 2011-2013 Kevin Kofler <kevin.kofler@chello.at>
   Copyright (C) 2015-2018 DAGOPT Optimization Technologies GmbH
                           written by Kevin Kofler <kofler@dagopt.com>

   Support by the Austrian Science Fund FWF under contract numbers
   P20631 and P23554 is gratefully acknowledged.

   This program is free software: you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation, either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program.  If not, see <http://www.gnu.org/licenses/>. */

#include <QCoreApplication>
#include <QTextStream>
#include <QTextCodec>
#include <QFile>
#include <cstdio>
#include "cnt.h"

using namespace DynGenPar;

static QCoreApplication *app;

QStringList categoryNames;

//#define OUTPUT_DEBUG_TREE
#define OUTPUT_CNR_XML
#define OUTPUT_UNICODE_ERRORS

#ifdef OUTPUT_DEBUG_TREE
/* Printing functions for testing purposes */
static void printLabel(const QVariant &label, QTextStream &stream)
{
  if (!label.isNull())
    stream << " (rule #" << label.toInt() << ')';
}

static void printSubtree(const Node &node, int level, QTextStream &stream)
{
  for (int i=0; i<level; i++) stream << ' ';
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      stream << " ERROR" << endl;
      break;
    case 1: // 1 alternative, normal tree
      stream << categoryNames.at(node.cat);
      printLabel(node.children.first().label(), stream);
      stream << endl;
      foreach (const Node &child, node.children.first())
        printSubtree(child, level+1, stream);
      break;
    default: // multiple alternatives
      stream << categoryNames.at(node.cat) << endl;
      foreach (const DynGenPar::Alternative &alternative, node.children) {
        for (int i=0; i<=level; i++) stream << ' ';
        stream << "ALTERNATIVE";
        printLabel(alternative.label(), stream);
        stream << endl;
        foreach (const Node &child, alternative)
          printSubtree(child, level+2, stream);
      }
      break;
  }
}

static void printParseTree(const Node &tree, const QString &fileName)
{
  if (fileName.isEmpty()) {
    QTextStream stream(stderr);
    printSubtree(tree, 0, stream);
  } else {
    QFile file(fileName);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&file);
    printSubtree(tree, 0, stream);
  }
}
#endif

#ifdef OUTPUT_CNR_XML
/* XML recordsheet output functions for production purposes */
static void printSubtreeAsXml(const Node &node, QTextStream &stream)
{
  switch (node.children.size()) {
    case 0: // no alternatives = error node
      qFatal("error node encountered");
    default: // multiple alternatives
      qWarning("warning: ignoring extra alternatives");
      // fall through
    case 1: // 1 alternative, normal tree
      const DynGenPar::Alternative &alternative = node.children.first();
      int ruleid = alternative.label().toInt();
#define CHILD(i) printSubtreeAsXml(alternative.at((i)), stream)
#define FIELD(field, contents) stream << "<FIELD name=\"" #field "\">"; \
                               contents; stream << "</FIELD>"
#define SUBTYPE(contents) stream << "<SUBTYPE>"; contents; \
                          stream << "</SUBTYPE>"
#define TYPE(type, contents) stream << "<" #type ">"; contents; \
                             stream << "</" #type ">"
      switch (ruleid) {
        case 319:
        case 321 ... 325:
        case 330:
        case 332:
        case 762:
        case 335:
        case 337:
        case 343:
          break;
        case 255:
        case 326 ... 327:
        case 501:
        case 764:
          CHILD(0);
          break;
        case 763:
        case 336:
        case 338:
          CHILD(1);
          break;
        case 331:
        case 333 ... 334:
        case 502:
        case 765:
        case 759:
          CHILD(0);
          CHILD(1);
          break;
        case 37:
        case 344:
          stream << "&amp;";
          break;
        case 256:
        case 341:
          stream << "<![CDATA[" << endl << "]]>";
          break;
        case 1 ... 10:
          stream << "<![CDATA[" << QChar(ruleid - 1) << "]]>";
          break;
        case 11 ... 12:
          stream << "<![CDATA[" << QChar(ruleid) << "]]>";
          break;
        case 13 ... 31:
          stream << "<![CDATA[" << QChar(ruleid + 1) << "]]>";
          break;
        case 32:
        case 34 ... 36:
        case 38 ... 58:
        case 60:
        case 62 ... 254:
          stream << QChar(ruleid + 1);
          break;
        case 33:
          stream << "&quot;";
          break;
        case 59:
          stream << "&lt;";
          break;
        case 61:
          stream << "&gt;";
          break;
        case 257 ... 282:
          stream << QChar(ruleid + ('A'-257));
          break;
        case 283 ... 308:
          stream << QChar(ruleid + ('a'-283));
          break;
        case 309 ... 318:
          stream << QChar(ruleid + ('0'-309));
          break;
        case 320:
          stream << "<![CDATA[ ]]>";
          CHILD(1);
          break;
        case 510 ... 519:
          stream << "<![CDATA[" << QChar(ruleid - 510) << "]]>";
          break;
        case 520 ... 521:
          stream << "<![CDATA[" << QChar(ruleid - 509) << "]]>";
          break;
        case 522 ... 540:
          stream << "<![CDATA[" << QChar(ruleid - 508) << "]]>";
          break;
        case 541:
        case 543 ... 545:
        case 547 ... 567:
        case 569:
        case 571 ... 635:
          stream << QChar(ruleid - 508);
          break;
        case 542:
          stream << "&quot;";
          break;
        case 568:
          stream << "&lt;";
          break;
        case 570:
          stream << "&gt;";
          break;
        case 636 ... 691:
          stream << QChar(ruleid - 444);
          break;
        case 692 ... 755:
          stream << QChar(ruleid - 564);
          break;
        case 760:
          CHILD(0);
          CHILD(1);
          CHILD(2);
          break;
        case 761:
          CHILD(0);
          CHILD(1);
          CHILD(2);
          CHILD(3);
          break;
        case 339:
          stream << '!';
          break;
        case 340:
          stream << '#';
          break;
        case 342:
          stream << "<![CDATA[" << ' ' << "]]>";
          break;
        case 477:
          stream << "<![CDATA[" << '\t' << "]]>";
          break;
        case 478:
          stream << "<![CDATA[" << '\b' << "]]>";
          break;
        case 345:
          stream << "&amp;&amp;";
          break;
        case 346:
          stream << "&amp;&amp;&amp;";
          break;
        case 347:
          stream << "&amp;&amp;&amp;&amp;";
          break;
        case 348:
          stream << "&amp;&amp;&amp;&amp;&amp;";
          break;
        case 349:
          stream << "&amp;&amp;&amp;&amp;&amp;&amp;";
          break;
        case 350:
          stream << "&amp;&amp;&amp;&amp;&amp;&amp;&amp;";
          break;
        case 351:
          stream << "&amp;&amp;&amp;&amp;&amp;&amp;&amp;&amp;";
          break;
        case 352:
          stream << "&amp;&amp;&amp;&amp;&amp;&amp;&amp;&amp;&amp;";
          break;
        case 811:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(entries, CHILD(1));
          );
          break;
        case 354:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(entries, CHILD(2));
          );
          break;
        case 812:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(StartCategory, CHILD(1));
            FIELD(entries, CHILD(2));
          );
          break;
        case 355:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(StartCategory, CHILD(2));
            FIELD(entries, CHILD(3));
          );
          break;
        case 813:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(entries, CHILD(1));
          );
          break;
        case 356:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(entries, CHILD(2));
          );
          break;
        case 814:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(StartCategory, CHILD(1));
            FIELD(entries, CHILD(2));
          );
          break;
        case 357:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(StartCategory, CHILD(2));
            FIELD(entries, CHILD(3));
          );
          break;
        case 815:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(entries, CHILD(1));
            FIELD(postComments, CHILD(3));
          );
          break;
        case 358:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(entries, CHILD(2));
            FIELD(postComments, CHILD(4));
          );
          break;
        case 816:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(StartCategory, CHILD(1));
            FIELD(entries, CHILD(2));
            FIELD(postComments, CHILD(4));
          );
          break;
        case 359:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(StartCategory, CHILD(2));
            FIELD(entries, CHILD(3));
            FIELD(postComments, CHILD(5));
          );
          break;
        case 817:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(entries, CHILD(1));
            FIELD(postComments, CHILD(3));
          );
          break;
        case 360:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(entries, CHILD(2));
            FIELD(postComments, CHILD(4));
          );
          break;
        case 818:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(StartCategory, CHILD(1));
            FIELD(entries, CHILD(2));
            FIELD(postComments, CHILD(4));
          );
          break;
        case 361:
          TYPE(TypeSheet,
            FIELD(Header, CHILD(0));
            FIELD(Targets, CHILD(1));
            FIELD(StartCategory, CHILD(2));
            FIELD(entries, CHILD(3));
            FIELD(postComments, CHILD(5));
          );
          break;
        case 362:
          TYPE(Header,
            FIELD(TypeSystem, CHILD(0));
            FIELD(language, CHILD(2));
            FIELD(authority, CHILD(5));
            FIELD(comments, CHILD(10));
          );
          break;
        case 363:
          TYPE(Header,
            FIELD(TypeSystem, CHILD(0));
            FIELD(language, CHILD(2));
            FIELD(authority, CHILD(5));
            FIELD(comments, CHILD(12));
            FIELD(imports, CHILD(10));
          );
          break;
        case 767:
          TYPE(Header,
            FIELD(TypeSystem, CHILD(0));
            FIELD(language, CHILD(2));
            FIELD(authority, CHILD(5));
            FIELD(comments, CHILD(10));
            FIELD(translations, CHILD(11));
          );
          break;
        case 768:
          TYPE(Header,
            FIELD(TypeSystem, CHILD(0));
            FIELD(language, CHILD(2));
            FIELD(authority, CHILD(5));
            FIELD(comments, CHILD(12));
            FIELD(imports, CHILD(10));
            FIELD(translations, CHILD(13));
          );
          break;
        case 364:
          TYPE(Id, SUBTYPE(TYPE(String, CHILD(0))));
          break;
        case 503:
          TYPE(PosInt, SUBTYPE(TYPE(Integer, CHILD(0))));
          break;
        case 766:
          TYPE(ForeignId, SUBTYPE(TYPE(String, CHILD(0))));
          break;
        case 365:
          TYPE(ImportLink, FIELD(TypeSystem, CHILD(0)));
          break;
        case 366:
          TYPE(ImportLink,
            FIELD(TypeSystem, CHILD(0));
            FIELD(Category, CHILD(2));
          );
          break;
        case 367:
          TYPE(ImportLink,
            FIELD(TypeSystem, CHILD(0));
            FIELD(Category, CHILD(2));
            FIELD(newName, CHILD(5));
          );
          break;
        case 368:
          TYPE(ImportLink,
            FIELD(TypeSystem, CHILD(0));
            FIELD(next, CHILD(3));
          );
          break;
        case 369:
          TYPE(ImportLink,
            FIELD(TypeSystem, CHILD(0));
            FIELD(Category, CHILD(2));
            FIELD(next, CHILD(5));
          );
          break;
        case 370:
          TYPE(ImportLink,
            FIELD(TypeSystem, CHILD(0));
            FIELD(Category, CHILD(2));
            FIELD(newName, CHILD(5));
            FIELD(next, CHILD(8));
          );
          break;
        case 769:
          TYPE(TranslationLink,
            FIELD(language, CHILD(8));
            FIELD(idTranslations, CHILD(11));
          );
          break;
        case 770:
          TYPE(TranslationLink,
            FIELD(language, CHILD(9));
            FIELD(idTranslations, CHILD(12));
            FIELD(preComments, CHILD(1));
          );
          break;
        case 771:
          TYPE(TranslationLink,
            FIELD(language, CHILD(8));
            FIELD(idTranslations, CHILD(11));
            FIELD(next, CHILD(12));
          );
          break;
        case 772:
          TYPE(TranslationLink,
            FIELD(language, CHILD(9));
            FIELD(idTranslations, CHILD(12));
            FIELD(preComments, CHILD(1));
            FIELD(next, CHILD(13));
          );
          break;
        case 773:
          TYPE(IdTranslationLink,
            FIELD(ForeignId, CHILD(2));
            FIELD(Id, CHILD(5));
          );
          break;
        case 774:
          TYPE(IdTranslationLink,
            FIELD(ForeignId, CHILD(2));
            FIELD(Id, CHILD(5));
            FIELD(next, CHILD(8));
          );
          break;
        case 371:
          TYPE(CommentLink, FIELD(Comment, CHILD(0)));
          break;
        case 372:
          TYPE(CommentLink,
            FIELD(Comment, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 373:
          TYPE(Comment, FIELD(text, CHILD(3)));
          break;
        case 374:
          TYPE(Line, SUBTYPE(TYPE(String, CHILD(0))));
          break;
        case 375:
          TYPE(Targets, FIELD(targets, CHILD(10)));
          break;
        case 376:
          TYPE(Targets,
            FIELD(targets, CHILD(11));
            FIELD(preComments, CHILD(1));
          );
          break;
        case 377:
          TYPE(TargetLink, FIELD(Target, CHILD(0)));
          break;
        case 378:
          TYPE(TargetLink,
            FIELD(Target, CHILD(0));
            FIELD(next, CHILD(2));
          );
          break;
        case 379:
          TYPE(Target,
            FIELD(sequence, CHILD(0));
            FIELD(vars, CHILD(2));
            FIELD(comment, CHILD(3));
          );
          break;
        case 380:
          TYPE(Target,
            FIELD(sequence, CHILD(0));
            FIELD(vars, CHILD(2));
          );
          break;
        case 381:
          TYPE(FieldLink, FIELD(field, CHILD(0)));
          break;
        case 382:
          TYPE(FieldLink,
            FIELD(field, CHILD(0));
            FIELD(next, CHILD(2));
          );
          break;
        case 383:
          TYPE(VarLink, FIELD(name, CHILD(1)));
          break;
        case 384:
          TYPE(VarLink,
            FIELD(name, CHILD(1));
            FIELD(next, CHILD(3));
          );
          break;
        case 385:
          TYPE(StartCategory,
            FIELD(start, CHILD(7));
            FIELD(comment, CHILD(8));
          );
          break;
        case 386:
          TYPE(StartCategory, FIELD(start, CHILD(7)));
          break;
        case 387:
          TYPE(EntryLink, FIELD(LitDef, CHILD(1)));
          break;
        case 388:
          TYPE(EntryLink, FIELD(CatDef, CHILD(1)));
          break;
        case 389:
          TYPE(EntryLink,
            FIELD(LitDef, CHILD(1));
            FIELD(next, CHILD(2));
          );
          break;
        case 390:
          TYPE(EntryLink,
            FIELD(CatDef, CHILD(1));
            FIELD(next, CHILD(2));
          );
          break;
        case 391:
          TYPE(LitDef,
            FIELD(productions, CHILD(2));
            FIELD(postComments, CHILD(1));
          );
          break;
        case 392:
          TYPE(LitDef, FIELD(productions, CHILD(3)));
          break;
        case 393:
          TYPE(LitDef,
            FIELD(productions, CHILD(3));
            FIELD(preComments, CHILD(0));
            FIELD(postComments, CHILD(2));
          );
          break;
        case 394:
          TYPE(LitDef,
            FIELD(productions, CHILD(4));
            FIELD(preComments, CHILD(0));
          );
          break;
        case 395:
          TYPE(LitLink, FIELD(production, CHILD(0)));
          break;
        case 396:
          TYPE(LitLink,
            FIELD(production, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 397:
          TYPE(LitProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(8));
            FIELD(Substitution, CHILD(10));
            FIELD(comments, CHILD(11));
          );
          break;
        case 398:
          TYPE(LitProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(8));
            FIELD(Substitution, CHILD(10));
          );
          break;
        case 399:
          TYPE(LitProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(8));
            FIELD(production, CHILD(10));
            FIELD(comments, CHILD(11));
          );
          break;
        case 400:
          TYPE(LitProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(8));
            FIELD(production, CHILD(10));
          );
          break;
        case 504:
          TYPE(LitProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(8));
            FIELD(cClass, CHILD(12));
            FIELD(comments, CHILD(14));
          );
          break;
        case 505:
          TYPE(LitProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(8));
            FIELD(cClass, CHILD(12));
          );
          break;
        case 401:
          TYPE(Substitution, FIELD(input, CHILD(0)));
          break;
        case 402:
          TYPE(Substitution,
            FIELD(input, CHILD(0));
            FIELD(output, CHILD(3));
          );
          break;
        case 506:
          TYPE(CRange, FIELD(start, CHILD(0)));
          break;
        case 507:
          TYPE(CRange,
            FIELD(start, CHILD(0));
            FIELD(end, CHILD(2));
          );
          break;
        case 508:
          TYPE(CRangeLink, FIELD(CRange, CHILD(0)));
          break;
        case 509:
          TYPE(CRangeLink,
            FIELD(CRange, CHILD(0));
            FIELD(next, CHILD(3));
          );
          break;
        case 403:
          TYPE(Char, SUBTYPE(TYPE(String, CHILD(0))));
          break;
        case 404:
          TYPE(CharLink, FIELD(Char, CHILD(0)));
          break;
        case 405:
          TYPE(CharLink,
            FIELD(Char, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 406:
          TYPE(OutChar, SUBTYPE(TYPE(String, CHILD(0))));
          break;
        case 407:
          TYPE(OutCharLink, FIELD(OutChar, CHILD(0)));
          break;
        case 408:
          TYPE(OutCharLink,
            FIELD(OutChar, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 479:
          TYPE(Alternative, SUBTYPE(CHILD(0)));
          break;
        case 409:
          TYPE(AlternativeLink, FIELD(Alternative, CHILD(0)));
          break;
        case 410:
          TYPE(AlternativeLink,
            FIELD(Alternative, CHILD(0));
            FIELD(next, CHILD(3));
          );
          break;
        case 411:
          TYPE(ElementLink, FIELD(element, CHILD(0)));
          break;
        case 412:
          TYPE(ElementLink,
            FIELD(element, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 413:
          TYPE(Element, FIELD(CatVar, CHILD(0)));
          break;
        case 414:
          TYPE(Element,
            FIELD(CatVar, CHILD(0));
            FIELD(match, CHILD(1));
          );
          break;
        case 415:
          TYPE(Element, FIELD(LitVar, CHILD(0)));
          break;
        case 416:
          TYPE(Element,
            FIELD(LitVar, CHILD(0));
            FIELD(match, CHILD(1));
          );
          break;
        case 417:
          TYPE(Element, FIELD(literal, CHILD(0)));
          break;
        case 418:
          TYPE(Element,
            FIELD(literal, CHILD(0));
            FIELD(match, CHILD(1));
          );
          break;
        case 485:
          TYPE(Element, FIELD(LitId, CHILD(0)));
          break;
        case 486:
          TYPE(Element,
            FIELD(LitId, CHILD(0));
            FIELD(match, CHILD(1));
          );
          break;
        case 494:
          TYPE(Element, FIELD(Function, CHILD(0)));
          break;
        case 495:
          TYPE(Element,
            FIELD(Function, CHILD(0));
            FIELD(match, CHILD(1));
          );
          break;
        case 328:
          TYPE(Element, FIELD(Blanks, CHILD(0)));
          break;
        case 480:
          TYPE(Element, FIELD(LineBreak, CHILD(0)));
          break;
        case 419:
          TYPE(Element, FIELD(optional, CHILD(2)));
          break;
        case 420:
          TYPE(Element,
            FIELD(optional, CHILD(2));
            FIELD(match, CHILD(5));
          );
          break;
        case 421:
          TYPE(Element, FIELD(once, CHILD(2)));
          break;
        case 422:
          TYPE(Element,
            FIELD(once, CHILD(2));
            FIELD(match, CHILD(5));
          );
          break;
        case 423:
          TYPE(Element, FIELD(anyTimes, CHILD(2)));
          break;
        case 424:
          TYPE(Element,
            FIELD(anyTimes, CHILD(2));
            FIELD(match, CHILD(5));
          );
          break;
        case 425:
          TYPE(Element, FIELD(multiple, CHILD(2)));
          break;
        case 426:
          TYPE(Element,
            FIELD(multiple, CHILD(2));
            FIELD(match, CHILD(5));
          );
          break;
        case 329:
          TYPE(Blanks, SUBTYPE(TYPE(String,
            stream << "<![CDATA[ ]]>";
            CHILD(1);
          )));
          break;
        case 353:
          TYPE(LineBreak, /* nothing */);
          break;
        case 427 ... 430:
          TYPE(MatchCase, SUBTYPE(CHILD(1)));
          break;
        case 431:
          TYPE(Maximal, SUBTYPE(TYPE(String, stream << "&amp;+")));
          break;
        case 432:
          TYPE(Expect, FIELD(pattern, CHILD(2)));
          break;
        case 433:
          TYPE(Taboo, FIELD(pattern, CHILD(2)));
          break;
        case 434:
          TYPE(Except, FIELD(pattern, CHILD(2)));
          break;
        case 487 ... 489:
          TYPE(CatVar, SUBTYPE(CHILD(1)));
          break;
        case 435:
          TYPE(CatVarRec, FIELD(name, CHILD(0)));
          break;
        case 490:
          TYPE(CatVarName, FIELD(name, CHILD(1)));
          break;
        case 491:
          TYPE(CatVarName, /* nothing */);
          break;
        case 492:
          TYPE(CatVarId, FIELD(name, CHILD(1)));
          break;
        case 493:
          TYPE(CatVarId, /* nothing */);
          break;
        case 436:
          TYPE(LitVar, FIELD(name, CHILD(2)));
          break;
        case 483:
          TYPE(LitId, FIELD(pattern, CHILD(4)));
          break;
        case 496:
          TYPE(FunArg, SUBTYPE(CHILD(0)));
          break;
        case 497:
          TYPE(FunArgLink, FIELD(FunArg, CHILD(0)));
          break;
        case 498:
          TYPE(FunArgLink,
            FIELD(FunArg, CHILD(0));
            FIELD(next, CHILD(3));
          );
          break;
        case 499:
          TYPE(Function, FIELD(name, CHILD(2)));
          break;
        case 500:
          TYPE(Function,
            FIELD(name, CHILD(2));
            FIELD(args, CHILD(6));
          );
          break;
        case 481:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(6));
            FIELD(extends, CHILD(3));
          );
          break;
        case 482:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(6));
            FIELD(extends, CHILD(3));
            FIELD(productions, CHILD(7));
          );
          break;
        case 484:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(6));
            FIELD(extends, CHILD(3));
            FIELD(productions, CHILD(7));
            FIELD(irregular, CHILD(8));
          );
          break;
        case 756:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(7));
            FIELD(extends, CHILD(3));
            FIELD(postComments, CHILD(6));
          );
          break;
        case 757:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(7));
            FIELD(extends, CHILD(3));
            FIELD(productions, CHILD(8));
            FIELD(postComments, CHILD(6));
          );
          break;
        case 758:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(7));
            FIELD(extends, CHILD(3));
            FIELD(productions, CHILD(8));
            FIELD(irregular, CHILD(9));
            FIELD(postComments, CHILD(6));
          );
          break;
        case 803:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(7));
            FIELD(extends, CHILD(4));
            FIELD(preComments, CHILD(0));
          );
          break;
        case 804:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(7));
            FIELD(extends, CHILD(4));
            FIELD(productions, CHILD(8));
            FIELD(preComments, CHILD(0));
          );
          break;
        case 805:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(7));
            FIELD(extends, CHILD(4));
            FIELD(productions, CHILD(8));
            FIELD(irregular, CHILD(9));
            FIELD(preComments, CHILD(0));
          );
          break;
        case 806:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(8));
            FIELD(extends, CHILD(4));
            FIELD(preComments, CHILD(0));
            FIELD(postComments, CHILD(7));
          );
          break;
        case 807:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(8));
            FIELD(extends, CHILD(4));
            FIELD(productions, CHILD(9));
            FIELD(preComments, CHILD(0));
            FIELD(postComments, CHILD(7));
          );
          break;
        case 808:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(8));
            FIELD(extends, CHILD(4));
            FIELD(productions, CHILD(9));
            FIELD(irregular, CHILD(10));
            FIELD(preComments, CHILD(0));
            FIELD(postComments, CHILD(7));
          );
          break;
        case 437:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(3));
          );
          break;
        case 438:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(3));
            FIELD(productions, CHILD(4));
          );
          break;
        case 439:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(3));
            FIELD(productions, CHILD(4));
            FIELD(irregular, CHILD(5));
          );
          break;
        case 440:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(4));
            FIELD(postComments, CHILD(3));
          );
          break;
        case 441:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(4));
            FIELD(productions, CHILD(5));
            FIELD(postComments, CHILD(3));
          );
          break;
        case 442:
          TYPE(CatDef,
            FIELD(Category, CHILD(0));
            FIELD(specifications, CHILD(4));
            FIELD(productions, CHILD(5));
            FIELD(irregular, CHILD(6));
            FIELD(postComments, CHILD(3));
          );
          break;
        case 443:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(4));
            FIELD(preComments, CHILD(0));
          );
          break;
        case 444:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(4));
            FIELD(productions, CHILD(5));
            FIELD(preComments, CHILD(0));
          );
          break;
        case 445:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(4));
            FIELD(productions, CHILD(5));
            FIELD(irregular, CHILD(6));
            FIELD(preComments, CHILD(0));
          );
          break;
        case 446:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(5));
            FIELD(preComments, CHILD(0));
            FIELD(postComments, CHILD(4));
          );
          break;
        case 447:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(5));
            FIELD(productions, CHILD(6));
            FIELD(preComments, CHILD(0));
            FIELD(postComments, CHILD(4));
          );
          break;
        case 448:
          TYPE(CatDef,
            FIELD(Category, CHILD(1));
            FIELD(specifications, CHILD(5));
            FIELD(productions, CHILD(6));
            FIELD(irregular, CHILD(7));
            FIELD(preComments, CHILD(0));
            FIELD(postComments, CHILD(4));
          );
          break;
        case 449:
          TYPE(SpecLink, FIELD(Spec, CHILD(0)));
          break;
        case 450:
          TYPE(SpecLink,
            FIELD(Spec, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 451 ... 453:
        case 775 ... 787:
          TYPE(Spec, SUBTYPE(CHILD(0)));
          break;
        case 788:
          TYPE(AllOfSpec, FIELD(equations, CHILD(7)));
          break;
        case 789:
          TYPE(OneOfSpec, FIELD(equations, CHILD(7)));
          break;
        case 790:
          TYPE(SomeOfSpec, FIELD(equations, CHILD(8)));
          break;
        case 791:
          TYPE(OptionalSpec, FIELD(equations, CHILD(10)));
          break;
        case 792:
          TYPE(FixedSpec, FIELD(equations, CHILD(7)));
          break;
        case 793:
          TYPE(OnlySpec, FIELD(equations, CHILD(6)));
          break;
        case 794:
          TYPE(SomeOfTypeSpec, FIELD(equations, CHILD(12)));
          break;
        case 795:
          TYPE(ItselfSpec, FIELD(names, CHILD(8)));
          break;
        case 796:
          TYPE(ArraySpec, FIELD(equations, CHILD(7)));
          break;
        case 797:
          TYPE(IndexSpec, FIELD(equations, CHILD(7)));
          break;
        case 798:
          TYPE(TemplateSpec, FIELD(name, CHILD(10)));
          break;
        case 799:
          TYPE(NothingElseSpec, /* nothing */);
          break;
        case 466:
          TYPE(NothingSpec, /* nothing */);
          break;
        case 800:
          TYPE(UnionSpec, FIELD(names, CHILD(7)));
          break;
        case 801:
          TYPE(AtomicSpec, FIELD(names, CHILD(8)));
          break;
        case 802:
          TYPE(CompleteSpec, /* nothing */);
          break;
        case 454:
          TYPE(EqLink,
            FIELD(field, CHILD(0));
            FIELD(Category, CHILD(2));
          );
          break;
        case 455:
          TYPE(EqLink,
            FIELD(field, CHILD(0));
            FIELD(Category, CHILD(2));
            FIELD(comment, CHILD(3));
          );
          break;
        case 456:
          TYPE(EqLink,
            FIELD(field, CHILD(3));
            FIELD(Category, CHILD(5));
            FIELD(name, CHILD(1));
          );
          break;
        case 457:
          TYPE(EqLink,
            FIELD(field, CHILD(3));
            FIELD(Category, CHILD(5));
            FIELD(name, CHILD(1));
            FIELD(comment, CHILD(6));
          );
          break;
        case 458:
          TYPE(EqLink,
            FIELD(field, CHILD(0));
            FIELD(Category, CHILD(2));
            FIELD(next, CHILD(6));
          );
          break;
        case 459:
          TYPE(EqLink,
            FIELD(field, CHILD(0));
            FIELD(Category, CHILD(2));
            FIELD(comment, CHILD(3));
            FIELD(next, CHILD(5));
          );
          break;
        case 460:
          TYPE(EqLink,
            FIELD(field, CHILD(3));
            FIELD(Category, CHILD(5));
            FIELD(name, CHILD(1));
            FIELD(next, CHILD(9));
          );
          break;
        case 461:
          TYPE(EqLink,
            FIELD(field, CHILD(3));
            FIELD(Category, CHILD(5));
            FIELD(name, CHILD(1));
            FIELD(comment, CHILD(6));
            FIELD(next, CHILD(8));
          );
          break;
        case 462:
          TYPE(NameLink, FIELD(field, CHILD(0)));
          break;
        case 463:
          TYPE(NameLink,
            FIELD(field, CHILD(3));
            FIELD(name, CHILD(1));
          );
          break;
        case 464:
          TYPE(NameLink,
            FIELD(field, CHILD(0));
            FIELD(next, CHILD(3));
          );
          break;
        case 465:
          TYPE(NameLink,
            FIELD(field, CHILD(3));
            FIELD(name, CHILD(1));
            FIELD(next, CHILD(6));
          );
          break;
        case 809:
          TYPE(NameLink,
            FIELD(field, CHILD(0));
            FIELD(next, CHILD(4));
          );
          break;
        case 810:
          TYPE(NameLink,
            FIELD(field, CHILD(3));
            FIELD(name, CHILD(1));
            FIELD(next, CHILD(7));
          );
          break;
        case 467:
          TYPE(CatLink, FIELD(production, CHILD(0)));
          break;
        case 468:
          TYPE(CatLink,
            FIELD(production, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 469:
          TYPE(CatProduction,
            FIELD(target, CHILD(2));
            FIELD(production, CHILD(5));
          );
          break;
        case 470:
          TYPE(CatProduction,
            FIELD(target, CHILD(2));
            FIELD(production, CHILD(5));
            FIELD(comments, CHILD(6));
          );
          break;
        case 471:
          TYPE(CatProduction, FIELD(target, CHILD(2)));
          break;
        case 472:
          TYPE(CatProduction,
            FIELD(target, CHILD(2));
            FIELD(comments, CHILD(7));
          );
          break;
        case 473:
          TYPE(IrrLink, FIELD(production, CHILD(0)));
          break;
        case 474:
          TYPE(IrrLink,
            FIELD(production, CHILD(0));
            FIELD(next, CHILD(1));
          );
          break;
        case 475:
          TYPE(IrrProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(6));
            FIELD(production, CHILD(8));
          );
          break;
        case 476:
          TYPE(IrrProduction,
            FIELD(target, CHILD(2));
            FIELD(field, CHILD(6));
            FIELD(production, CHILD(8));
            FIELD(comments, CHILD(9));
          );
          break;
        default:
          qFatal("invalid rule %d", ruleid);
      }
#undef CHILD
#undef FIELD
#undef SUBTYPE
#undef TYPE
      break;
  }
}

static void printParseTreeAsXml(const Node &tree, const QString &fileName)
{
  if (fileName.isEmpty()) {
    QTextStream stream(stdout);
    /* We set the codec to Latin1 because we do not want to have to decode the
       UTF-8 in the input. Latin1 as the codec will just pass them through. */
    stream.setCodec(QTextCodec::codecForMib(4)); // Latin1
    stream << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" << endl;
    printSubtreeAsXml(tree, stream);
  } else {
    QFile file(fileName);
    file.open(QIODevice::WriteOnly | QIODevice::Text);
    QTextStream stream(&file);
    stream.setCodec(QTextCodec::codecForMib(4)); // Latin1
    stream << "<?xml version=\"1.0\" encoding=\"UTF-8\"?>" << endl;
    printSubtreeAsXml(tree, stream);
  }
}
#endif

static bool compareLiterals(const QList<Cat> &o1, const QList<Cat> &o2) {
  int l1 = o1.size();
  int l2 = o2.size();
  int l = (l1 < l2) ? l1 : l2;
  for (int i=0; i<l; i++) {
    CatArg t1 = o1.at(i);
    CatArg t2 = o2.at(i);
    if (t1 < t2) return true;
    if (t1 > t2) return false;
  }
  if (l1 < l2) return true;
  return false;
}

#ifdef OUTPUT_UNICODE_ERRORS
#define ELLIPSIS QChar(8230)
#else
#define ELLIPSIS "..."
#endif

static QString tokenToDisplayString(CatArg token) {
#ifdef OUTPUT_UNICODE_ERRORS
  if (token == '\n')
    return QChar(8629);

  if (token == ' ')
    return QChar(9251);
#endif

  return categoryNames.at(token);
}

static void printPredictions(const ConstrainedMultiPredictions &predictions,
                             Parser &parser, CatArg errorToken)
{
  QTextStream stream(stderr);
  foreach (const QList<Cat> &prediction, predictions.uniqueKeys()) {
    stream << "expected: ";
    foreach (CatArg cat, prediction) stream << tokenToDisplayString(cat);
    stream << endl;
    CatArg firstCat = prediction.first();
    QList<ConstrainedMultiPrediction> multiPredictions
     = predictions.values(prediction);
    if (parser.isToken(firstCat)) {
      foreach (const ConstrainedMultiPrediction &multiPrediction,
               multiPredictions) {
        stream << " completes: ";
        foreach (CatArg token, multiPrediction.fullLiteral)
          stream << tokenToDisplayString(token);
        stream << " in: " << categoryNames.at(multiPrediction.cat) << endl
               << " instead of: ";
        int l = multiPrediction.fullLiteral.size() - prediction.size();
        for (int i=0; i<l; i++)
          stream << tokenToDisplayString(multiPrediction.fullLiteral.at(i));
        if (!IS_EPSILON(errorToken))
          stream << tokenToDisplayString(errorToken) << ELLIPSIS;
        stream << endl;
      }
    } else {
      QList<NextTokenConstraints> nextTokenConstraints;
      foreach (const ConstrainedMultiPrediction &multiPrediction,
               multiPredictions)
        nextTokenConstraints.append(multiPrediction.nextTokenConstraints);
      QHash<Cat, QSet<QList<Cat> > > expandedPrediction
       = parser.expandNonterminalPredictionMultiC(firstCat,
                                                  nextTokenConstraints);
      QHashIterator<Cat, QSet<QList<Cat> > > it(expandedPrediction);
      while (it.hasNext()) {
        it.next();
        Cat cat = it.key();
        stream << " expected category: " << categoryNames.at(cat) << endl;
        QList<QList<Cat> > literals = it.value().toList();
        qSort(literals.begin(), literals.end(), compareLiterals);
        foreach (const QList<Cat> &literal, literals) {
          stream << "  expected literal: ";
          foreach (CatArg token, literal) stream << tokenToDisplayString(token);
          stream << endl;
        }
      }
    }
  }
}

int main(int argc, char **argv)
{
  app = new QCoreApplication(argc, argv);
  QStringList args = app->arguments();
  bool accepted = false;

  {
    CntParser cntParser;
#ifdef OUTPUT_DEBUG_TREE
    QString debugOutputFile;
#endif
    if (args.size() > 1) {
      cntParser.setInputFile(args[1]);
#ifdef OUTPUT_DEBUG_TREE
      debugOutputFile = args[1] + ".tree";
#endif
    }
#ifdef OUTPUT_CNR_XML
    QString xmlOutputFile;
    if (args.size() > 2) xmlOutputFile = args[2];
#endif
    int errorPos;
    Cat errorToken;
    QList<StackItem> stacks;
    LexerState lexerState;
    QList<Match> matches = cntParser.parse(&errorPos, &errorToken, 0, &stacks,
                                           0, &lexerState);
    categoryNames = getCategoryNames();
    if (errorPos >= 0) {
      QTextStream stream(stderr);
      TextPosition pos = TextByteTokenSource::textPosition(lexerState);
      stream << "parse error at line " << (pos.line + 1) << " column "
             << (pos.col + 1) << ": unexpected "
             << tokenToDisplayString(errorToken) << endl;
      if (stacks.isEmpty())
        stream << "expected: end of input" << endl;
      else
        printPredictions(cntParser.computeConstrainedMultiPredictions(stacks),
                         cntParser, errorToken);
    } else if (matches.isEmpty()) {
      {
        QTextStream stream(stderr);
        stream << "parse error at end of input: incomplete input" << endl;
      }
      printPredictions(cntParser.computeConstrainedMultiPredictions(stacks),
                       cntParser, ByteTokenEpsilon);
    } else {
      foreach (const Match &m, matches) {
        if (accepted) {
          qWarning("warning: ignoring extra matches");
        } else {
          accepted = true;
#ifdef OUTPUT_DEBUG_TREE
          printParseTree(m.tree, debugOutputFile);
#endif
#ifdef OUTPUT_CNR_XML
          printParseTreeAsXml(m.tree, xmlOutputFile);
#endif
        }
      }
    }
  }

  delete app;
  return !accepted;
}
